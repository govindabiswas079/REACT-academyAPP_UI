import { IThemeSchema, ThemeType } from "./themes";
interface IUseTheme {
    themeSchema: IThemeSchema;
    themeLoaded: boolean;
}
export declare const useTheme: (themeType: ThemeType) => IUseTheme;
export {};
