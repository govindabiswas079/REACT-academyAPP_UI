import { IVerificationPin } from "../../../types";
export declare const Spinner: import("styled-components").StyledComponent<"div", any, IVerificationPin, never>;
