export interface IShakeXProps {
    shake: boolean;
}
