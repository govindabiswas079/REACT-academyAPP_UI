import { IShakeXProps } from "../types/i-shake-props";
export declare const AnimatedShakeX: import("styled-components").StyledComponent<"div", any, IShakeXProps, never>;
