import React from "react";
import { IShakeXProps } from "./types/i-shake-props";
export declare const ShakeX: React.FC<IShakeXProps>;
