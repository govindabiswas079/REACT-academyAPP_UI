import React from "react";
import { ThemeType } from "./theme";
import { IVerificationPin, StatusType } from "./types";
export { StatusType };
declare type inputType = "number" | "text" | "numberAndText";
interface IVerificationPinProps extends IVerificationPin {
    theme?: ThemeType;
    type: inputType;
    inputsNumber: number;
    title?: string;
    subTitle: string;
    autoFocus?: boolean;
    onChange?: (letterOrNumber: string) => void;
    onFinish?: (completeCode: string) => void;
}
export declare const VerificationPin: React.FC<IVerificationPinProps>;
