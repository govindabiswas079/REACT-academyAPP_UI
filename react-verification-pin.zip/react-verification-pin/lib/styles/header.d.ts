export declare const Header: import("styled-components").StyledComponent<"div", any, {}, never>;
