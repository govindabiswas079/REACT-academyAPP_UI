export declare const SubTitle: import("styled-components").StyledComponent<"p", any, {}, never>;
