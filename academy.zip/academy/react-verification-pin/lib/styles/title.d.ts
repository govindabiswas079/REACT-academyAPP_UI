export declare const Title: import("styled-components").StyledComponent<"h3", any, {}, never>;
