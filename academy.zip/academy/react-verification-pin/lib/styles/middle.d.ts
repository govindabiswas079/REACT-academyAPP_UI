export declare const Middle: import("styled-components").StyledComponent<"div", any, {}, never>;
