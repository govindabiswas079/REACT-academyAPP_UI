import { DefaultTheme } from "styled-components";
interface IPalette {
    primary: string;
    secondary: string;
}
export interface IThemeSchema extends DefaultTheme {
    colors: {
        process: IPalette;
        wait: IPalette;
        success: IPalette;
        error: IPalette;
    };
    input: {
        backgroundColor: string;
        hover: {
            backgroundColor: string;
            boxShadow: string;
        };
        focus: {
            borderColor: string;
            boxShadow: string;
            backgroundColor: string;
        };
    };
}
export interface ITheme {
    easyPeasy: IThemeSchema;
}
export declare type ThemeType = "easyPeasy";
export declare const themes: ITheme;
export {};
