import { IVerificationPin } from "../../../types";
export declare const inputError: import("styled-components").FlattenInterpolation<import("styled-components").ThemeProps<any>>;
export declare const inputHover: import("styled-components").FlattenInterpolation<import("styled-components").ThemeProps<any>>;
export declare const inputFocus: import("styled-components").FlattenInterpolation<import("styled-components").ThemeProps<any>>;
export declare const StyledInput: import("styled-components").StyledComponent<"input", any, IVerificationPin, never>;
