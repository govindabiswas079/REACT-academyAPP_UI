import React from "react";
import { IVerificationPin } from "src/types";
declare type internalInputType = "text" | "number";
export interface IInputProps {
    id: string;
    type?: internalInputType;
    width?: string;
    pattern?: RegExp;
    onFocus?: (e: React.FocusEvent<HTMLInputElement>) => void;
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
    onBlur?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}
export declare const Input: React.ForwardRefExoticComponent<IInputProps & IVerificationPin & React.RefAttributes<HTMLInputElement>>;
export {};
