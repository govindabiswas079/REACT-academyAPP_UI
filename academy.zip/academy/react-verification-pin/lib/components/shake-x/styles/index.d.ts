export * from "./animated-shake-x";
