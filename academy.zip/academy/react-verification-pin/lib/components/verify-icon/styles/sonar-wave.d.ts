import { IVerificationPin } from "../../../types";
export declare const SonarWave: import("styled-components").StyledComponent<"div", any, IVerificationPin, never>;
