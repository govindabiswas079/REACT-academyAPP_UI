import { IVerificationPin } from "../../../types";
export declare const Wrapped: import("styled-components").StyledComponent<"div", any, IVerificationPin, never>;
