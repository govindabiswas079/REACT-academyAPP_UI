import React from "react";
import { IVerificationPin } from "../../types";
export declare const VerifyIcon: React.FC<IVerificationPin>;
