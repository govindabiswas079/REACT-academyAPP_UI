import React from 'react';
import { Link } from 'react-router-dom';
import Carousel from 'react-grid-carousel'

const FreeCourses = () => {
   return (
      <div>
         <div>
            <section id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Courses</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px' }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={1} rows={1} gap={5} loop>
               <Carousel.Item>
                  <div>
                     <div>
                        <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNN00iMHCird9GLtlK-uCmktTBz8uDUI3gkQ&usqp=CAU" alt='' />
                     </div>
                  </div>
                  <div style={{ display: 'flex' }}>
                     <div style={{ backgroundColor: 'rgb(89 75 75 / 47%)', borderRadius: '3px', zIndex: '9', display: 'flex', margin: '10px 10px', width: '50px', border: '1px solid grey' }}>
                        <p style={{ margin: '2px 6px 2px 6px', fontWeight: '700', color: '#000000', fontSize: '12px', fontFamily: 'Nunito' }}>HINDI</p>
                     </div>
                     <div style={{ margin: 'auto' }}>
                        <p style={{ fontSize: '15px', fontFamily: 'Nunito', color: 'gray', margin: '2px 6px 2px 6px', }}>NCERT CLASS 12TH SUMMARY</p>
                     </div>
                  </div>

                  <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div>
                     <div>
                        <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://www.opengroup.org/sites/default/files/about-us.jpg" alt='' />
                     </div>
                  </div>
                  <div style={{ display: 'flex' }}>
                     <div style={{ backgroundColor: 'rgb(89 75 75 / 47%)', borderRadius: '3px', zIndex: '9', display: 'flex', margin: '10px 10px', width: '50px', border: '1px solid grey' }}>
                        <p style={{ margin: '2px 6px 2px 6px', fontWeight: '700', color: '#000000', fontSize: '12px', fontFamily: 'Nunito' }}>HINDI</p>
                     </div>
                     <div style={{ margin: 'auto' }}>
                        <p style={{ fontSize: '15px', fontFamily: 'Nunito', color: 'gray', margin: '2px 6px 2px 6px', }}>NCERT CLASS 12TH SUMMARY</p>
                     </div>
                  </div>

                  <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div>
                     <div>
                        <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNN00iMHCird9GLtlK-uCmktTBz8uDUI3gkQ&usqp=CAU" alt='' />
                     </div>
                  </div>
                  <div style={{ display: 'flex' }}>
                     <div style={{ backgroundColor: 'rgb(89 75 75 / 47%)', borderRadius: '3px', zIndex: '9', display: 'flex', margin: '10px 10px', width: '50px', border: '1px solid grey' }}>
                        <p style={{ margin: '2px 6px 2px 6px', fontWeight: '700', color: '#000000', fontSize: '12px', fontFamily: 'Nunito' }}>HINDI</p>
                     </div>
                     <div style={{ margin: 'auto' }}>
                        <p style={{ fontSize: '15px', fontFamily: 'Nunito', color: 'gray', margin: '2px 6px 2px 6px', }}>NCERT CLASS 12TH SUMMARY</p>
                     </div>
                  </div>

                  <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
            </Carousel>
         </div>
         <br />
         <div style={{ backgroundColor: '#252525' }}>
            <section id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ fontFamily: 'Nunito', fontWeight: '700', color: '#FFFFFF' }}>Best classes of all time</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px', }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={1} rows={1} gap={5} loop>
               <Carousel.Item>
                  <div>
                     <div>
                        <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://chronicle.brightspotcdn.com/72/1a/e30a5c504651354605302cabc845/class-engagement.jpg" alt='' />
                        <div style={{ position: 'relative' }}>
                           <div >
                              <div>
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: 'rgb(87 85 85 / 58%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                       <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#000000', fontSize: '13px', fontFamily: 'Nunito' }}>EN</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '20px 10px', lineHeight: '2px' }}>
                     <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>PRACTICE & STRATEGY</p>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito', color: '#FFFFFF' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div>
                     <div>
                        <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://crampete-staticfiles.s3.ap-south-1.amazonaws.com/blogs/Blog-161/Feature.jpg" alt='' />
                        <div style={{ position: 'relative' }}>
                           <div >
                              <div>
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: 'rgb(87 85 85 / 58%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                       <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#000000', fontSize: '13px', fontFamily: 'Nunito' }}>EN</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '20px 10px', lineHeight: '2px' }}>
                     <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>PRACTICE & STRATEGY</p>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito', color: '#FFFFFF' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
            </Carousel>
         </div>
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <section id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Popular subjects</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              {/* <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px' }} to="">SEE ALL</Link> */}
                              {/* <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i> */}
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={1} rows={1} gap={5} loop>
               <Carousel.Item>
                  <section id="features" className="features">
                     <div className="container" data-aos="fade-up">
                        <div className="row" data-aos="zoom-in" data-aos-delay="100">
                           <div className="col-lg-3 col-md-4">
                              <div className="icon-box" style={{ borderRadius: '10px' }}>
                                 <i className="ri-store-line" style={{ color: '#ffbb2c', }}></i>
                                 <h3><Link to="">History</Link></h3>
                              </div>
                           </div>
                           <div className="col-lg-3 col-md-4 mt-4 mt-md-0">
                              <div className="icon-box" style={{ borderRadius: '10px' }}>
                                 <i className="ri-bar-chart-box-line" style={{ color: '#5578ff' }}></i>
                                 <h3><Link to="">Geography</Link></h3>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
               </Carousel.Item>
               <Carousel.Item>
                  <section id="features" className="features">
                     <div className="container" data-aos="fade-up">
                        <div className="row" data-aos="zoom-in" data-aos-delay="100">
                           <div className="col-lg-3 col-md-4">
                              <div className="icon-box" style={{ borderRadius: '10px' }}>
                                 <i className="ri-store-line" style={{ color: '#ffbb2c', }}></i>
                                 <h3><Link to="">History</Link></h3>
                              </div>
                           </div>
                           <div className="col-lg-3 col-md-4 mt-4 mt-md-0">
                              <div className="icon-box" style={{ borderRadius: '10px' }}>
                                 <i className="ri-bar-chart-box-line" style={{ color: '#5578ff' }}></i>
                                 <h3><Link to="">Geography</Link></h3>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
               </Carousel.Item>
            </Carousel>
            <br />
            <br />
            <br />
         </div>
      </div>
   );
};

export default FreeCourses
