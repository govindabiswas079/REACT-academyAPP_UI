import React from 'react';
import Carousel from 'react-grid-carousel'
import { Link, useNavigate } from 'react-router-dom';

const Plus = () => {
   return (
      <div>
         <section id="about" className="about">
            <div className="container" data-aos="fade-up">
               <div className="row">
                  <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                     <div style={{ display: 'flex' }}>
                        <div>
                           <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Batches</h6>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <div>
                           <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                           <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <Carousel cols={2} rows={1} gap={1} loop>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://www.opengroup.org/sites/default/files/about-us.jpg" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: '#000000', borderRadius: '0px 5px 5px 5px', zIndex: '9', position: 'absolute', bottom: '20px' }}>
                                    <p style={{ margin: '6px 12px 6px 12px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}>BATCH</p>
                                 </div>
                              </div>

                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNN00iMHCird9GLtlK-uCmktTBz8uDUI3gkQ&usqp=CAU" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: '#000000', borderRadius: '0px 5px 5px 5px', zIndex: '9', position: 'absolute', bottom: '20px' }}>
                                    <p style={{ margin: '6px 12px 6px 12px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}>BATCH</p>
                                 </div>
                              </div>

                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://www.opengroup.org/sites/default/files/about-us.jpg" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: '#000000', borderRadius: '0px 5px 5px 5px', zIndex: '9', position: 'absolute', bottom: '20px' }}>
                                    <p style={{ margin: '6px 12px 6px 12px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}>BATCH</p>
                                 </div>
                              </div>

                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
         </Carousel>
         <br />
         <br />
         <section id="about" className="about">
            <div className="container" data-aos="fade-up">
               <div className="row">
                  <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                     <div style={{ display: 'flex' }}>
                        <div>
                           <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Special classes</h6>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <div>
                           <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                           <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <Carousel cols={2} rows={1} gap={1} loop>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://leverageedu.com/blog/wp-content/uploads/2019/11/Group-Discussion-Topics.png" alt='' />
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://static.javatpoint.com/tutorial/group-discussion/images/group-discussion-tips.jpg" alt='' />
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://chronicle.brightspotcdn.com/72/1a/e30a5c504651354605302cabc845/class-engagement.jpg" alt='' />
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
         </Carousel>
         <br />
         <br />
         <br />
         <section id="about" className="about">
            <div className="container" data-aos="fade-up">
               <div className="row">
                  <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                     <div style={{ display: 'flex' }}>
                        <div>
                           <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Ongoing</h6>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        {/* <div>
                           <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                           <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                        </div> */}
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <Carousel cols={2} rows={1} gap={1} loop>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://leverageedu.com/blog/wp-content/uploads/2019/12/Non-Technical-Topics-for-Group-Discussions.jpg" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
         </Carousel>
         <br />
         <br />
         <br />
         <section id="about" className="about">
            <div className="container" data-aos="fade-up">
               <div className="row">
                  <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                     <div style={{ display: 'flex' }}>
                        <div>
                           <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Upcoming</h6>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        {/* <div>
                           <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                           <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                        </div> */}
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <Carousel cols={2} rows={1} gap={1} loop>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://crampete-staticfiles.s3.ap-south-1.amazonaws.com/blogs/Blog-161/Feature.jpg" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://d8it4huxumps7.cloudfront.net/bites/wp-content/uploads/2019/07/11083525/How-to-crack-group-discussions-for-placements-01.jpg" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://www.opengroup.org/sites/default/files/about-us.jpg" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
         </Carousel>
         <br />
         <br />
         <br />
         <section id="about" className="about">
            <div className="container" data-aos="fade-up">
               <div className="row">
                  <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                     <div style={{ display: 'flex' }}>
                        <div>
                           <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Completed</h6>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        {/* <div>
                           <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                           <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                        </div> */}
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <Carousel cols={2} rows={1} gap={1} loop>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://thumbs.dreamstime.com/b/business-meeting-group-company-strategy-conference-concept-vector-illustration-team-members-discussion-flat-cartoon-158840270.jpg" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://crampete-staticfiles.s3.ap-south-1.amazonaws.com/blogs/Blog-160/Feature.png" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
            <Carousel.Item>
               <div className="container py-2">
                  <div>
                     <img style={{ width: '100%', height: '25vh', borderRadius: '5px' }} src="https://foru.co.id/wp-content/uploads/2016/12/pemimpin-IA.jpg" alt='' />
                     <div style={{ position: 'relative' }}>
                        <div>
                           <div >
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'rgb(87 85 85 / 38%)', borderRadius: '5px', zIndex: '9', position: 'absolute', bottom: '140px', right: '10px', border: '1px solid #FFFFFF' }}>
                                    <p style={{ margin: '6px 10px 6px 10px', fontWeight: '700', color: '#FFFFFF', fontSize: '13px', fontFamily: 'Nunito' }}><i className="bi bi-lock-fill"></i></p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0 10px', lineHeight: '2px', marginTop: '15px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                  <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
               </div>
            </Carousel.Item>
         </Carousel>
         <br />
      </div>
   );
};

export default Plus
