import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import SwipeableViews from 'react-swipeable-views';
import { useTheme } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { Plus, FreeCourses } from './Pages/Index';

function TabPanel(props) {
   const { children, value, index, ...other } = props;

   return (
      <div
         role="tabpanel"
         hidden={value !== index}
         id={`full-width-tabpanel-${index}`}
         aria-labelledby={`full-width-tab-${index}`}
         {...other}
      >
         {value === index && (
            <Box sx={{ p: 3 }}>
               <Typography>{children}</Typography>
            </Box>
         )}
      </div>
   );
}

TabPanel.propTypes = {
   children: PropTypes.node,
   index: PropTypes.number.isRequired,
   value: PropTypes.number.isRequired,
};

function a11yProps(index) {
   return {
      id: `full-width-tab-${index}`,
      'aria-controls': `full-width-tabpanel-${index}`,
   };
}

const EducatorProfile = () => {
   let navigate = useNavigate();
   const [nav, setNav] = React.useState(false)
   const [tab, setTab] = React.useState(false)
   const theme = useTheme();
   const [value, setValue] = React.useState(0);

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const changeTabPosition = () => {
      if (window.scrollY >= 300) {
         setTab(true);
      } else {
         setTab(false);
      }
   }
   window.addEventListener('scroll', changeTabPosition);

   const handleChange = (event, newValue) => {
      setValue(newValue);
   };

   const handleChangeIndex = (index) => {
      setValue(index);
   };

   const Educators = sessionStorage.getItem('Educators');
   let jsonObject = JSON.parse(Educators);

   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: tab ? '10px' : '0px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     <Link to="/home"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <br />
            <br />
            <div style={{ alignItems: 'center', justifyContent: 'center' }}>{/* display: 'flex', flexDirection: 'column' */}
               <div>
                  <div style={{ borderRadius: '50%', height: '90px', width: '90px' }} className='d-grid gap-2 col-6 mx-auto'>
                     <div style={{ flex: '1' }}></div>
                     <img style={{ borderRadius: '50%', height: '90px', width: '90px', }} src={jsonObject.Image} alt="" />
                     <div style={{ flex: '1' }}></div>
                  </div>
               </div>
               <div style={{ marginTop: '30px' }}>
                  <h3 style={{ fontWeight: '700', textAlign: 'center' }}>{jsonObject.EduName}</h3>
                  <h6 style={{ fontWeight: '700', textAlign: 'center', color: 'gray' }}>{jsonObject.Position}</h6>
               </div>
               <div style={{ display: 'flex', flexDirection: 'row', margin: '30px 20px' }}>
                  <div>
                     <h3 style={{ fontWeight: '600', textAlign: 'center', fontSize: '20px' }}>{jsonObject.WatchMins}</h3>
                     <h6 style={{ fontWeight: '500', textAlign: 'center', color: 'gray' }}>Watch Mins</h6>
                  </div>
                  <div style={{ flex: '1' }}></div>
                  <div>
                     <h3 style={{ fontWeight: '600', textAlign: 'center', fontSize: '20px' }}>{jsonObject.Followers}</h3>
                     <h6 style={{ fontWeight: '500', textAlign: 'center', color: 'gray' }}>Followers</h6>
                  </div>
                  <div style={{ flex: '1' }}></div>
                  <div>
                     <button style={{ color: '#08bd80', borderColor: '#08bd80', fontWeight: '700', fontFamily: "Nunito", }} type="button" className="btn btn-lg">Follow</button>
                  </div>
               </div>
               <div className={tab ? "eduTabPosition eduTabActive" : "eduTabPosition"} >
                  <Tabs
                     value={value}
                     onChange={handleChange}
                     indicatorColor="secondary"
                     textColor="inherit"
                     aria-label="full width tabs example"
                  >
                     <Tab style={{ fontWeight: '700' }} label="Plus" {...a11yProps(0)} />
                     <Tab style={{ fontWeight: '700' }} label="Free courses" {...a11yProps(1)} />
                     <Tab style={{ fontWeight: '700' }} label="About" {...a11yProps(2)} />
                  </Tabs>
               </div>
            </div>
         </div>
         <Box sx={{ bgcolor: 'background.paper', }} style={{ marginTop: '10px' }}>
            {/*  */}
            <SwipeableViews
               axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
               index={value}
               onChangeIndex={handleChangeIndex}
            >
               <div style={{ marginTop: tab ? "70px" : '20px' }} value={value} index={0} dir={theme.direction}>
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <Plus />
                  </div>
               </div>
               <div style={{ marginTop: tab ? "70px" : '20px' }} value={value} index={1} dir={theme.direction}>
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <FreeCourses />
                  </div>
               </div>
               <div style={{ marginTop: tab ? "70px" : '20px' }} value={value} index={2} dir={theme.direction}>
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <h2>Syllabus</h2>
                  </div>
               </div>
            </SwipeableViews>
         </Box>
      </div>
   );
};

export default EducatorProfile
