import React, { useState } from 'react';
import './Navbar.css';
import { Link } from 'react-router-dom';

function Navbar() {
  const [nav, setNav] = useState(false)

  const changeBackground = () => {
    if (window.scrollY >= 50) {
      setNav(true);
    } else {
      setNav(false);
    }
  }
  window.addEventListener('scroll', changeBackground);

  return (
    <>
      <header className={nav ? "header active" : "header"}>
        <div className="container">
          <div className="header-main">
            <div className="logo">
              <Link to="/">Veda Academy</Link>
            </div>
          </div>
        </div>
      </header>
      <section className="home-section">
      </section>
    </>
  );
}

export default Navbar;