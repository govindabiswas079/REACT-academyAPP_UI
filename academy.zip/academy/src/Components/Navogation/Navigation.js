import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom';

import './Navigation.css'


import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import HomeIcon from '@mui/icons-material/Home';
import SchoolIcon from '@mui/icons-material/School';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import FindInPageIcon from '@mui/icons-material/FindInPage';

const Navigation = (props) => {
    const Navigate = useNavigate()
    const [activeTabs, setActiveTabs] = useState(props.name)
    const [color, setColor] = useState(false)

    useEffect(() => {
        switch (activeTabs) {
            case 'home':
                window.location.replace('/home');
                setColor(true);
                break;
            case 'exam':
                window.location.replace('/exam');
                setColor(true);
                break;
            case 'search':
                window.location.replace('/self-study');
                setColor(true);
                break;
            case 'notification':
                window.location.replace('/notification');
                setColor(true);
                break;
            case 'account':
                window.location.replace('/account');
                setColor(true);
                break;
            default:

                break;
        }
    }, [activeTabs, Navigate])

    return (
        <div className='bottom-nav'>
            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                {activeTabs === 'home' ?
                    <>
                        <HomeIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('home')}
                        />
                        <p style={{ fontWeight: '900' }}>Home</p>
                    </> :
                    <>
                        <HomeIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('home')}
                        />
                        <p >Home</p>
                    </>}
            </div>
            <div style={{ flex: '1' }}></div>

            {/* <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                {activeTabs === 'exam' ?
                    <>
                        <SchoolIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('exam')}
                        />
                        <p style={{ fontWeight: '900' }}>Exam</p>
                    </> :
                    <>
                        <SchoolIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('exam')}
                        />
                        <p>Exam</p>
                    </>}
            </div> */}
            <div style={{ flex: '1' }}></div>

            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                {activeTabs === 'search' ?
                    <>
                        <FindInPageIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('search')}
                        />
                        <p style={{ fontWeight: '900' }}>Study</p>

                    </> :
                    <>
                        <FindInPageIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('search')}
                        />
                        <p>Study</p>
                    </>}
            </div>
            <div style={{ flex: '1' }}></div>
            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                {activeTabs === 'notification' ?
                    <>
                        <NotificationsActiveIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('notification')}
                        />
                        <p style={{ fontWeight: '900' }}>Notification</p>
                    </> :
                    <>
                        <NotificationsActiveIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('notification')}
                        />
                        <p>Notification</p>
                    </>}
            </div>
            <div style={{ flex: '1' }}></div>
            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                {activeTabs === 'account' ?
                    <>
                        <AccountCircleIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('account')}
                        />
                        <p style={{ fontWeight: '900' }}>Me</p>
                    </> :
                    <>
                        <AccountCircleIcon
                            size='35'
                            color='#000'
                            onClick={() => setActiveTabs('account')}
                        />
                        <p>Me</p>
                    </>}
            </div>
        </div>
    );
};

export default Navigation




/* import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom';

import './Navigation.css'


import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import HomeIcon from '@mui/icons-material/Home';
import SchoolIcon from '@mui/icons-material/School';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import FindInPageIcon from '@mui/icons-material/FindInPage';

const Navigation = (props) => {
    const Navigate = useNavigate()

    return (
        <div className='bottom-nav'>
            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                <HomeIcon
                    size='35'
                    color='#000'
                    onClick={() => Navigate('/home')}
                />
                <p style={{ fontWeight: '900' }}>Home</p>
            </div>
            <div style={{ flex: '1' }}></div>

            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                <SchoolIcon
                    size='35'
                    color='#000'
                    onClick={() => Navigate('/exam')}
                />
                <p style={{ fontWeight: '900' }}>Exam</p>
            </div>
            <div style={{ flex: '1' }}></div>

            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                <FindInPageIcon
                    size='35'
                    color='#000'
                    onClick={() => Navigate('/home')}
                />
                <p style={{ fontWeight: '900' }}>Study</p>
            </div>
            <div style={{ flex: '1' }}></div>
            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                <NotificationsActiveIcon
                    size='35'
                    color='#000'
                    onClick={() => Navigate('/home')}
                />
                <p style={{ fontWeight: '900' }}>Notification</p>
            </div>
            <div style={{ flex: '1' }}></div>
            <div style={{ display: 'flex', flexDirection: 'column', fontFamily: 'Nunito' }} className='bn-tab'>
                <AccountCircleIcon
                    size='35'
                    color='#000'
                    onClick={() => Navigate('/home')}
                />
                <p style={{ fontWeight: '900' }}>Me</p>
            </div>
        </div>
    );
};

export default Navigation */
