import React from 'react'
import { Link, useNavigate } from 'react-router-dom';
import CameraAltSharp from '@mui/icons-material/CameraAltSharp';
import EditOutlined from '@mui/icons-material/EditOutlined';

const Profile = () => {
   let navigate = useNavigate();
   const [nav, setNav] = React.useState(false);
   const [imagePreview, setImagePreview] = React.useState("");
   const [user, setUser] = React.useState("");

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const userData = sessionStorage.getItem('userData')
   let jsonObject = JSON.parse(userData);

   const message = sessionStorage.getItem('message')
   let messageBio = JSON.parse(message);

   const addBio = () => {
      navigate('/bio')
   };

   const nameupdate = () => {
      navigate('/name-update')
   };
   const emailupdate = () => {
      navigate('/email-update')
   };
   const numberupdate = () => {
      navigate('/number-update')
   };
   const userupdate = () => {
      navigate('/user-update')
   };

   const photoUpload = (event) => {
      let files = event.target.files;
      let reader = new FileReader();
      reader.readAsDataURL(files[0]);

      reader.onload = (e) => {
         setImagePreview(e.target.result)
         sessionStorage.setItem('setimagePreview', e.target.result);
         window.location.reload();
      }
   };
   const setimage = sessionStorage.getItem('setimagePreview');


   return (
      <div style={{ height: '100vh', backgroundColor: '#FFFFFF' }}>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/settings"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Profile</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <br />
            <div style={{ alignItems: 'center', display: 'flex', justifyContent: 'center', position: 'relative' }}>
               <div style={{ position: 'relative' }}>
                  <div style={{ borderRadius: '50%', height: '64px', width: '64px', position: 'relative' }}>
                     {setimage ? <img src={setimage} alt="" style={{ borderRadius: '50%', height: '150%', width: '150%', }} />
                        :
                        <>
                           <div>
                              <label htmlFor="files" style={{ backgroundColor: '#08bd80', color: '#FFFFFF', borderRadius: '50%', height: '64px', width: '64px', }} className="btn btn-light">
                                 <CameraAltSharp style={{ marginTop: '12px' }} />
                              </label>
                           </div>
                           <input id="files" style={{ visibility: "hidden" }} type="file" onChange={photoUpload} accept=".jpef, .png, .jpg, image" capture='environment' />
                        </>
                     }
                     <div style={{ visibility: setimage ? 'block' : 'hidden' }} className="container__docker">
                        <label htmlFor="files" style={{ cursor: 'pointer' }}>
                           <EditOutlined />
                        </label>
                        <input id="files" style={{ visibility: "hidden" }} type="file" onChange={photoUpload} accept=".jpef, .png, .jpg, image" capture='environment' />
                     </div>
                  </div>
               </div>
            </div>
            <br />
            <br />
            <br />
            <div style={{ margin: '20px' }}>
               <div>
                  <h6 style={{ color: 'grey', fontSize: '18px' }}>Name</h6>
                  <div style={{ display: 'flex' }} onClick={(e) => nameupdate(e)}>
                     <h4 style={{ color: '#000000', fontSize: '18px', fontWeight: '700' }}>{jsonObject.Name}</h4>
                     <div style={{ flex: '1' }}></div>
                     <i className="bi bi-chevron-right"></i>
                  </div>
               </div>

               <div>
                  <h6 style={{ color: 'grey', fontSize: '18px', marginTop: '15px' }}>Email Addres</h6>
                  <div style={{ display: 'flex' }} onClick={(e) => emailupdate(e)}>
                     <h4 style={{ color: '#000000', fontSize: '18px', fontWeight: '700' }}>{jsonObject.Email}</h4>
                     <div style={{ flex: '1' }}></div>
                     <i className="bi bi-chevron-right"></i>
                  </div>
               </div>

               <div>
                  <h6 style={{ color: 'grey', fontSize: '18px', marginTop: '15px' }}>Mobile Number</h6>
                  <div style={{ display: 'flex' }} onClick={(e) => numberupdate(e)}>
                     <h4 style={{ color: '#000000', fontSize: '18px', fontWeight: '700' }}>+{jsonObject.Mobile}</h4>
                     <div style={{ flex: '1' }}></div>
                     <i className="bi bi-chevron-right"></i>
                  </div>
               </div>

               <div>
                  <h6 style={{ color: 'grey', fontSize: '18px', marginTop: '15px' }}>Username</h6>
                  <div style={{ display: 'flex' }} onClick={(e) => userupdate(e)}>
                     <h4 style={{ color: '#000000', fontSize: '18px', fontWeight: '700' }}>{jsonObject.username}</h4>
                     <div style={{ flex: '1' }}></div>
                     <i className="bi bi-chevron-right"></i>
                  </div>
               </div>

               <div>
                  <h6 style={{ color: 'grey', fontSize: '18px', marginTop: '15px' }}>Bio</h6>
                  <div style={{ display: 'flex' }} onClick={(e) => addBio(e)}>
                     <h4 style={{ color: '#000000', fontSize: '18px', fontWeight: '700' }}>
                        <div>
                           {message === null ?
                              <>
                                 <h4 style={{ color: '#000000', fontSize: '18px', fontWeight: '700' }}>Add few words about yourself</h4>
                              </> :
                              <>
                                 {messageBio.message}
                              </>}
                        </div>
                     </h4>
                     <div style={{ flex: '1' }}></div>
                     <i className="bi bi-chevron-right"></i>
                  </div>
               </div>
            </div>
            <br />
         </div>
      </div>
   );
};

export default Profile
