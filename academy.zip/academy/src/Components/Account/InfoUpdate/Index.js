export { default as NameUpdate } from './NameUpdate';
export { default as EmailUpdate } from './EmailUpdate';
export { default as NumberUpdate } from './NumberUpdate';
export { default as UserUpdate } from './UserUpdate';
export { default as UpdateOtpVerify } from './UpdateOtpVerify';