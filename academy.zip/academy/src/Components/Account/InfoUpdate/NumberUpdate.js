import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import PhoneInput from 'react-phone-input-2'
import 'react-phone-input-2/lib/style.css';

const NumberUpdate = () => {
   let Navigate = useNavigate();
   const messagedata = sessionStorage.getItem('Mobile')
   const [value, setValue] = React.useState({
      Mobile: messagedata
   });

   const userData = sessionStorage.getItem('userData')
   let userDataJSON = JSON.parse(userData);

   var message = JSON.stringify({
      Name: userDataJSON.Name,
      Email: userDataJSON.Email,
      Mobile: value.Mobile,
      currentDate: userDataJSON.currentDate,
      examMode: userDataJSON.examMode,
      username: userDataJSON.username,
   })

   const onChage = (e) => {
      setValue({ ...value, Mobile: e });
   }

   const onSubmit = () => {
      sessionStorage.setItem("Mobile", value.Mobile)
      sessionStorage.setItem('userData', message);
      /* message.success('send OTP', value.Mobile); */
      Navigate('/update-otp-verify')
   }

   return (
      <div style={{ height: '100vh', backgroundColor: '#FFFFFF' }}>
         <div style={{ height: '100%', flex: '1 1', }} >
            <header className="header">
               <div style={{ marginTop: '10px' }} className="container">
                  <div style={{ display: 'flex' }} className="header-main">
                     <div className="logo">
                        <Link to="/profile"><i className="bi bi-arrow-left"></i></Link>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '0px 20px' }}>
                  <div style={{ marginTop: '0px', }}>
                     <div>
                        <h3 style={{ width: '100%', color: '#000000', fontWeight: 'bolder', fontFamily: 'Nunito', }}>Edit your Mobile</h3>
                        <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontFamily: 'Nunito', fontSize: '14px' }}>We'll send an OTP for verification</h6>
                     </div>
                     <br />



                     <div className="">
                        <div className="row height d-flex justify-content-center align-items-center">
                           <div className="col-md-6">
                              <div className="form">
                                 <PhoneInput country={'in'} value={value.Mobile} onChange={(e) => onChage(e)} inputClass={"form-input"} placeholder="Mobile number" />
                              </div>
                           </div>
                        </div>
                     </div>
                     <br />
                  </div>
               </div>
            </header>
            <div style={{ bottom: '0', position: 'absolute', width: '100%' }}>
               <div style={{ margin: '20px' }} className="d-grid gap-2">

                  <button onClick={(e) => onSubmit(e)} style={{ color: '#FFFFFF', fontWeight: '900', backgroundColor: '#191919', fontSize: '15px' }} className="btn btn-lg" type="button">Continue</button>
               </div>
            </div>
         </div>
      </div>
   );
};

export default NumberUpdate
