import { VerificationPin, } from "react-verification-pin";
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import swal from 'sweetalert';

const UpdateOtpVerify = () => {
    let Navigate = useNavigate();
    const [status, setStatus] = React.useState("process");

    const handleOnFinish = (code) => {
        setStatus("wait");
        if (code === "111111") {
            setTimeout(() => {
                setStatus("success");
                setTimeout(() => {
                    Navigate('/profile')
                }, 500)
            }, 1000);
        } else {
            setTimeout(() => {
                setStatus("error");
                setTimeout(() => {
                    swal('Please Enter 111111')
                }, 500)
            }, 1000);
        }
    };

    const handleResend = () => {
        /* message.success('Resend'); */

        console.log('send otp')
    }

    return (
        <div style={{ height: '100vh', backgroundColor: '#FFFFFF' }}>
            <div >
                <header className="header">
                    <div style={{ marginTop: '10px' }} className="container">
                        <div style={{ display: 'flex' }} className="header-main">
                            <div className="logo">
                                <Link to="/number-update"><i className="bi bi-arrow-left"></i></Link>
                            </div>
                        </div>
                    </div>
                    <div style={{ margin: '0px 20px' }}>
                        <div style={{ marginTop: '0px' }}>
                            <div>
                                <h3 style={{ width: '100%', color: '#000000', fontWeight: 'bolder', fontFamily: 'Nunito', }}>Verify OTP</h3>
                                <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontFamily: 'Nunito', fontSize: '13px' }}>We've sent ot on +91 9511723507</h6>
                            </div>
                            <br />

                            <div style={{ width: '100%', margin: '0 auto', height: '50px', boxSizing: '10px' }}>
                                <VerificationPin
                                    style={{ color: 'red' }}
                                    type="number"
                                    inputsNumber={6}
                                    status={status}
                                    onFinish={handleOnFinish}
                                    key='key'
                                />
                                <div style={{ justifyItems: 'center', }}>
                                    <div style={{ display: 'flex', }}>
                                        <Link style={{ color: 'gray', fontFamily: 'Nunito', fontWeight: '500', fontSize: '14px' }} onClick={(e) => handleResend(e)} to="">Resend OTP in 180s</Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
                <div style={{ bottom: '0', position: 'absolute', width: '100%' }}>
                    <div style={{ margin: '20px' }} className="d-grid gap-2">
                        <div style={{ justifyItems: 'center', }} className="d-grid gap-2 mx-auto">
                            <div style={{ display: 'flex' }}>
                                <Link style={{ color: 'gray', fontFamily: 'Nunito', fontWeight: '700', fontSize: '12px' }} to="">Having trouble? Write to us at <span><Link style={{ color: 'black' }} to="">help@vedaacademy.com</Link></span></Link>
                            </div>
                        </div>
                        <button style={{ color: '#FFFFFF', fontWeight: '900', backgroundColor: '#191919' }} className="btn btn-lg" type="button">Verify</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UpdateOtpVerify;