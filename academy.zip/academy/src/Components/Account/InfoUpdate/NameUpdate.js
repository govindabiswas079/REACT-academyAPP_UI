import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const NameUpdate = () => {
   let navigate = useNavigate();
   const messagedata = sessionStorage.getItem('userData')
   let messageBio = JSON.parse(messagedata);

   const [value, setValue] = React.useState({
      Name: `${messagedata === null ? '' : messageBio.Name}`
   });

   var message = JSON.stringify({
      Name: value.Name,
      Email: messageBio.Email,
      Mobile: messageBio.Mobile,
      currentDate: messageBio.currentDate,
      examMode: messageBio.examMode,
      username: messageBio.username,
   })
   console.log(message)

   const onsubmit = () => {
      sessionStorage.setItem('userData', message);
      navigate('/profile')
   }

   return (
      <div style={{ height: '100vh', backgroundColor: '#FFFFFF' }}>
         <header className="header">
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo">
                     <Link to="/profile"><i className="bi bi-arrow-left"></i></Link>
                  </div>
               </div>
            </div>
            <div style={{ margin: '0px 20px' }}>
               <div style={{ marginTop: '0px', }}>
                  <div>
                     <h3 style={{ width: '100%', color: '#000000', fontWeight: 'bolder', fontFamily: 'Nunito', }}>Edit your Name</h3>
                     <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontFamily: 'Nunito', fontSize: '14px' }}>You can change the name only once, make sure it's correct</h6>
                  </div>
                  <br />
                  <div >
                     <input value={value.Name} onChange={(e) => setValue({ ...value, Name: e.target.value })} style={{ width: '100%', borderRadius: '10px', borderWidth: '1.5px', borderColor: "#000000", color: 'gray', fontWeight: '600', padding: '7px', fontFamily: 'Nunito', }} placeholder="Enter Your Name" />
                  </div>
               </div>
            </div>
            <div style={{ bottom: '0', position: 'fixed', width: '100%' }}>
               <div style={{ margin: '20px' }} className="d-grid gap-2">
                  <button style={{ backgroundColor: '#251f1f', color: '#FFFFFF', fontWeight: '700', fontSize: '15px' }} className="btn btn-lg" type="button" onClick={(e) => onsubmit(e)}>Save</button>
               </div>
            </div>
         </header >
      </div>
   );
};

export default NameUpdate
