import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Switch from '@mui/material/Switch';

const Settings = () => {
   let navigate = useNavigate();
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const profile = () => {
      navigate('/profile')
   };


   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/account"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Settings</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <br />
         <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <p style={{ margin: '10px', fontFamily: 'Nunito', color: 'gray' }}>My Account</p>
                     <div className="icon-box" onClick={(e) => profile(e)}>
                        <br />
                        <i className="bi bi-person-circle" style={{ color: 'grey', }}></i>
                        <div>
                           <h3 style={{ fontFamily: 'Nunito', fontSize: '18px' }}>Profile</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-arrow-right-short" style={{ color: 'grey', }}></i>
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>
         {/* <br /> */}
         {/* <section style={{ backgroundColor: '#FFFFFF', marginTop: '5px' }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <p style={{ margin: '10px', fontFamily: 'Nunito', color: 'gray' }}>System</p>
                     <div className="icon-box">
                        <br />
                        <i className="bi bi-moon-stars-fill" style={{ color: 'grey', }}></i>
                        <div>
                           <h3 style={{ fontFamily: 'Nunito', fontSize: '18px' }}>Night mode</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Switch size="small" />
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section> */}
         {/* <br /> */}
         <section style={{ backgroundColor: '#FFFFFF', marginTop: '5px' }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <p style={{ margin: '10px', fontFamily: 'Nunito', color: 'gray' }}>Feedback</p>
                     <div className="icon-box">
                        <br />
                        <i className="bi bi-star-fill" style={{ color: 'grey', }}></i>
                        <div>
                           <h3 style={{ fontFamily: 'Nunito', fontSize: '18px' }}>Rate the app</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-arrow-right-short" style={{ color: 'grey', }}></i>
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>
         {/* <br /> */}
         <section style={{ backgroundColor: '#FFFFFF', marginTop: '5px' }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <p style={{ margin: '10px', fontFamily: 'Nunito', color: 'gray' }}>Veda Academy</p>
                     <div className="icon-box">
                        <br />
                        <i className="bi bi-file-earmark-ruled" style={{ color: 'grey', }}></i>
                        <div>
                           <h3 style={{ fontFamily: 'Nunito', fontSize: '18px' }}>terms and conditions</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-arrow-right-short" style={{ color: 'grey', }}></i>
                        <br />
                     </div>
                     <div className="icon-box">
                        <br />
                        <i className="bi bi-shield-lock-fill" style={{ color: 'grey', }}></i>
                        <div>
                           <h3 style={{ fontFamily: 'Nunito', fontSize: '18px' }}>Privacy policy</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-arrow-right-short" style={{ color: 'grey', }}></i>
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>
         {/* <br /> */}
         <section style={{ backgroundColor: '#FFFFFF', marginTop: '5px' }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     {/* <p style={{ margin: '10px', fontFamily: 'Nunito', color: 'gray' }}>Feedback</p> */}
                     <div className="icon-box">
                        <br />
                        <i className="bi bi-box-arrow-left" style={{ color: 'grey', }}></i>
                        <div>
                           <h3 style={{ fontFamily: 'Nunito', fontSize: '18px' }}>Sign out</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-arrow-right-short" style={{ color: 'grey', }}></i>
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <br />
         <br />
         <br />
         
      </div>
   );
};

export default Settings
