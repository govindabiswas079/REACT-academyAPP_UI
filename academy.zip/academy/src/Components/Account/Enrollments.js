import React from 'react';
import { Link } from 'react-router-dom';

const Enrollments = () => {
  return (
    <div>
      <header className="header">
        <div style={{ marginTop: '10px' }} className="container">
          <div style={{ display: 'flex' }} className="header-main">
            <div className="logo">
              <Link to="/account"><i className="bi bi-arrow-left"></i></Link>
            </div>
          </div>
        </div>
        <div style={{ margin: '0px 20px' }}>
          <div style={{ marginTop: '0px', }}>
            <div>
              <h3 style={{ width: '100%', color: '#000000', fontWeight: 'bolder', fontFamily: 'Nunito', }}>Enrollments</h3>
              <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontFamily: 'Nunito', fontSize: '14px' }}>Your enrolled classes</h6>
            </div>
          </div>
        </div>
      </header>
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <div style={{ alignItems: 'center', display: 'flex', justifyContent: 'center', flexDirection: 'column' }}>
        <div>
          <i style={{ textAlign: 'center', fontSize: '70px', }} className="bi bi-kanban"></i>

        </div>
        <div style={{ textAlign: 'center' }}>
          <h4 style={{ fontWeight: '900' }}>No enrolled classes</h4>
          <h6 style={{ color: 'gray', fontWeight: '700' }}>Time to enroll into a few classes</h6>
        </div>
        <Link to="/all-free-classes" style={{colo: '#FFFFFF', fontWeight: '700', fontFamily: 'Nunito'}} type="button" className="btn btn-secondary btn-sm">Browse free classes</Link>
      </div>
    </div>
  );
};
export default Enrollments
