import React from 'react';
import { Link } from 'react-router-dom';

const Downloads = () => {
  return (
    <div>
      <header className="header">
        <div style={{ marginTop: '10px' }} className="container">
          <div style={{ display: 'flex' }} className="header-main">
            <div className="logo">
              <Link to="/account"><i className="bi bi-arrow-left"></i></Link>
            </div>
          </div>
        </div>
        <div style={{ margin: '0px 20px' }}>
          <div style={{ marginTop: '0px', }}>
            <div>
              <h3 style={{ width: '100%', color: '#000000', fontWeight: 'bolder', fontFamily: 'Nunito', }}>Downloads</h3>
              <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontFamily: 'Nunito', fontSize: '14px' }}>All downloads session for offline use</h6>
            </div>
          </div>
        </div>
      </header>
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
        <div data-aos="fade-up">
          <div className="row" data-aos="zoom-in" data-aos-delay="100">
            <div className="col-lg-3 col-md-4">
              <div className="icon-box">
                <br />
                <i className="bi bi-file-play" style={{ color: 'blue', }}></i>
                <div>
                  <h3 style={{ fontFamily: 'Nunito', fontSize: '18px' }}>Session</h3>
                  <h3 style={{ fontFamily: 'Nunito', fontSize: '15px', color: 'gray', marginTop: '8px' }}>0 downloads</h3>
                </div>
                <div style={{ flex: '1' }}></div>
                <i className="bi bi-arrow-right-short" style={{ color: '#000000', }}></i>
                <br />
              </div>
            </div>
            <div className="col-lg-3 col-md-4">
              <div className="icon-box">
                <br />
                <i className="bi bi-file-play" style={{ color: 'orangered', }}></i>
                <div>
                  <h3 style={{ fontFamily: 'Nunito', fontSize: '18px' }}>Free live classes</h3>
                  <h3 style={{ fontFamily: 'Nunito', fontSize: '15px', color: 'gray', marginTop: '8px' }}>0 downloads</h3>
                </div>
                <div style={{ flex: '1' }}></div>
                <i className="bi bi-arrow-right-short" style={{ color: '#000000', }}></i>
                <br />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Downloads
