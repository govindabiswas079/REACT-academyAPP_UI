import React from 'react';
import { Link } from 'react-router-dom';

const Faqs = () => {
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/account"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Learn more</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <br />
         <div style={{ margin: '10px' }}>
            <p style={{ fontWeight: '500', color: '#000000', fontSize: '18px', fontFamily: 'Nunito', }}>What is Plus Subscription?</p>

            <p style={{ fontWeight: '400', color: 'gray', fontSize: '18px', fontFamily: 'Nunito', }}>
               The new Group feature is incredible! Kindly help iconic learners connect with students who have similar targets so they can use the group feature to keep motivated. Also please help us find mentors who best suit our background and preparation goals.
            </p>
            <hr />
            <p style={{ fontWeight: '500', color: '#000000', fontSize: '18px', fontFamily: 'Nunito', }}>What is Plus Subscription?</p>

            <p style={{ fontWeight: '400', color: 'gray', fontSize: '18px', fontFamily: 'Nunito', }}>
               The new Group feature is incredible! Kindly help iconic learners connect with students who have similar targets so they can use the group feature to keep motivated. Also please help us find mentors who best suit our background and preparation goals.
            </p>
            <hr />
         </div>
      </div>
   );
};

export default Faqs
