export { default as Enrollments } from './Enrollments';
export { default as Downloads } from './Downloads';
export { default as Faqs } from './Faqs';
export { default as MyEducators } from './MyEducators';
export { default as Settings } from './Settings';
export { default as Updates } from './Updates';
export { default as Profile } from './Profile';
export { default as Bio } from './Bio';