import React from 'react';
import { Link } from 'react-router-dom';

const MyEducators = () => {
  const [nav, setNav] = React.useState(false)

  const changeBackground = () => {
    if (window.scrollY >= 50) {
      setNav(true);
    } else {
      setNav(false);
    }
  }
  window.addEventListener('scroll', changeBackground);

  return (
    <div>
      <header className={nav ? "header active" : "header"}>
        <div style={{ marginTop: '10px' }} className="container">
          <div style={{ display: 'flex' }} className="header-main">
            <div className="logo2">
              {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
              <Link to="/account"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
              <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">My Educators</Link>
            </div>
            <div style={{ flex: '1' }}></div>
          </div>
        </div>
      </header>
      <br />
      <br />
      <br />
      <h6 style={{color: 'gray', margin: '20px', fontSize: '20px', fontWeight: '900'}}>No Followers found</h6>
    </div>
  );
};

export default MyEducators
