import React from 'react'
import { Link } from 'react-router-dom';

const Syllabus = () => {
   const [show, setShow] = React.useState(false);
   const [show1, setShow1] = React.useState(false);
   const [show2, setShow2] = React.useState(false);

   const click = () => setShow(!show);
   const click1 = () => setShow1(!show1);
   const click2 = () => setShow2(!show2);

   return (
      <div style={{ marginTop: '0px', backgroundColor: '#FFFFFF' }}>
         <section id="features" className="features">
            <div className="" data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4 mt-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="http://pngimg.com/uploads/letter_n/letter_n_PNG75.png" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>NCERT Summary</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show ? "true" : "false"} onClick={(e) => click(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/*  */}
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuZJAaCQcn6Mh_wgiHUowL5L0Z9PPXLj2uLQ&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>History</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show1 ? "true" : "false"} onClick={(e) => click1(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show1 ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show1 ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/*  */}
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://image.flaticon.com/icons/png/512/34/34715.png" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Indian Economy</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show2 ? "true" : "false"} onClick={(e) => click2(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show2 ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show2 ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/*  */}
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuZJAaCQcn6Mh_wgiHUowL5L0Z9PPXLj2uLQ&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>History</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show1 ? "true" : "false"} onClick={(e) => click1(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show1 ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show1 ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/*  */}
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://image.flaticon.com/icons/png/512/34/34715.png" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Indian Economy</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show2 ? "true" : "false"} onClick={(e) => click2(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show2 ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show2 ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/*  */}
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuZJAaCQcn6Mh_wgiHUowL5L0Z9PPXLj2uLQ&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>History</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show1 ? "true" : "false"} onClick={(e) => click1(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show1 ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show1 ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/*  */}
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://image.flaticon.com/icons/png/512/34/34715.png" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Indian Economy</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show2 ? "true" : "false"} onClick={(e) => click2(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show2 ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show2 ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/*  */}
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuZJAaCQcn6Mh_wgiHUowL5L0Z9PPXLj2uLQ&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>History</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show1 ? "true" : "false"} onClick={(e) => click1(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show1 ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show1 ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
                  {/*  */}
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://image.flaticon.com/icons/png/512/34/34715.png" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Indian Economy</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <Link to="" aria-expanded={show2 ? "true" : "false"} onClick={(e) => click2(e)}><i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className={show2 ? "bi bi-dash" : "bi bi-plus"}></i></Link>
                     </div>
                     <div className={show2 ? "collapse show" : "collapse"} id="collapseExample">
                        <div style={{ margin: '0px 0px' }} className="col-lg-3 col-md-4">
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Economics - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Geography - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Polity - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>Sci & Tech - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                           <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s',/*  border: '1px solid #eef0ef' */ }} className="icon-box">
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px', lineHeight: 'inherit' }}>History - NCERT Summary</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '13px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   );
};

export default Syllabus
