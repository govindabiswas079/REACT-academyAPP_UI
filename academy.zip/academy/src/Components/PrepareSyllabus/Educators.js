import React from 'react';

const Educators = () => {
   return (
      <div style={{ marginTop: '0px', backgroundColor: '#FFFFFF' }}>
         <section id="features" className="features">
            <div className="" data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4 mt-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Prem Kumar</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Mr. Abhi</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>19k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Mr. Nayak</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Mr. Ramesh Kumar</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Mr. Nayak</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Kumar</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>mr. Mrunal</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Mr. Abhi</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>19k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Mr. Nayak</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Mr. Ramesh Kumar</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Mr. Nayak</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>Kumar</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <img style={{ width: '45px', borderRadius: '50px', marginRight: '15px' }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHHlRhS5_c6i5K2AkR8aPKeF1STQmGFej5_w&usqp=CAU" alt="" />
                        <div>
                           <h3 style={{ fontWeight: '900', fontSize: '18px', lineHeight: 'inherit' }}>mr. Mrunal</h3>
                           <h3 style={{ fontWeight: '600', fontSize: '15px', color: 'gray' }}>1k folowers</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '20px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   );
};

export default Educators
