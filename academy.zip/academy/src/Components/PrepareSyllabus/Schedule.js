import React from 'react';


const Schedule = () => {
  return (
    <>
      <div style={{ marginTop: '0px', backgroundColor: '#FFFFFF' }} className="tabPosition">
        <div >
          <div style={{ marginTop: '10px' }}>
            <div style={{ display: 'flex', margin: '15px', marginTop: '10px' }}>
              <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700', marginTop: '15px' }}>Schedule</h5>
              <div style={{ flex: '1' }}></div>
              <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700', marginTop: '15px' }}>VIEW FULL</h5>
              <i style={{ fontSize: '15px', color: '#000000', fontWeight: '700', marginTop: '15px', marginLeft: '8px' }} className="bi bi-chevron-right"></i>
            </div>
          </div>
          <div style={{ display: 'flex', margin: '15px' }}>
            <i style={{ color: '#000000', marginRight: '20px', fontSize: '15px', }} className="bi bi-brightness-high"></i>
            <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '500' }}>Afternoon classes</h5>
          </div>
          <div style={{ display: 'flex', margin: '15px' }}>
            <i style={{ color: '#000000', marginRight: '20px', fontSize: '15px', }} className="bi bi-play-circle"></i>
            <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '500' }}>564+ live classes • 9 tests</h5>
          </div>
          <div style={{ margin: '15px' }}>
            <hr />
          </div>
          <div style={{ marginTop: '10px' }}>
            <div style={{ display: 'flex', margin: '15px', marginTop: '10px' }}>
              <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700', marginTop: '15px' }}>15 Dec 2021</h5>
              <div style={{ flex: '1' }}></div>
              <h5 style={{ fontSize: '15px', color: 'gray', fontWeight: '500', marginTop: '15px' }}>Yesterday</h5>
            </div>
            <div style={{ display: 'flex', margin: '15px' }}>
              <i style={{ color: 'royalblue ', marginRight: '20px', fontSize: '50px', }} className="bi bi-play-circle-fill"></i>
              <div>
                <h5 style={{ fontSize: '13px', color: 'royalblue', fontWeight: '700' }}>NCERT SUMMARY</h5>
                <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700' }}>History: Our Past (NCERT VI) with Practice Test - I</h5>
                <h5 style={{ fontSize: '13px', color: 'gray', fontWeight: '500' }}>Aartee Mishra</h5>
              </div>
            </div>
          </div>
          {/*  */}
          <div style={{ marginTop: '10px' }}>
            <div style={{ display: 'flex', margin: '15px', marginTop: '10px' }}>
              <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700', marginTop: '15px' }}>16 Dec 2021</h5>
              <div style={{ flex: '1' }}></div>
              <h5 style={{ fontSize: '15px', color: 'gray', fontWeight: '500', marginTop: '15px' }}>Today</h5>
            </div>
            <div style={{ display: 'flex', margin: '15px' }}>
              {/* <i style={{ color: 'royalblue ', marginRight: '20px', fontSize: '50px', }} className="bi bi-play-circle-fill"></i> */}
              <div style={{ backgroundColor: 'rgb(218 211 211 / 36%)', borderRadius: '10px', height: '60px' }}>
                <div style={{ padding: '10px' }}>
                  <h5 style={{ fontWeight: '700', fontSize: '13px' }}>2:30</h5>
                  <h6 style={{ fontWeight: '700', fontSize: '13px', textAlign: 'center', color: 'gray' }}>PM</h6>
                </div>
              </div>
              <div style={{ marginLeft: '15px' }}>
                <h5 style={{ fontSize: '13px', color: 'royalblue', fontWeight: '700' }}>NCERT SUMMARY</h5>
                <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700' }}>History: Our Past (NCERT VI) with Practice Test - I</h5>
                <h5 style={{ fontSize: '13px', color: 'gray', fontWeight: '500' }}>Aartee Mishra</h5>
              </div>
            </div>
          </div>
          {/*  */}
          <div style={{ marginTop: '10px' }}>
            <div style={{ display: 'flex', margin: '15px', marginTop: '10px' }}>
              <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700', marginTop: '15px' }}>17 Dec 2021</h5>
              <div style={{ flex: '1' }}></div>
              <h5 style={{ fontSize: '15px', color: 'gray', fontWeight: '500', marginTop: '15px' }}>Tomorrow</h5>
            </div>
            <div style={{ display: 'flex', margin: '15px' }}>
              {/* <i style={{ color: 'royalblue ', marginRight: '20px', fontSize: '50px', }} className="bi bi-play-circle-fill"></i> */}
              <div style={{ backgroundColor: 'rgb(218 211 211 / 36%)', borderRadius: '10px', height: '60px' }}>
                <div style={{ padding: '10px' }}>
                  <h5 style={{ fontWeight: '700', fontSize: '13px' }}>2:30</h5>
                  <h6 style={{ fontWeight: '700', fontSize: '13px', textAlign: 'center', color: 'gray' }}>PM</h6>
                </div>
              </div>
              <div style={{ marginLeft: '15px' }}>
                <h5 style={{ fontSize: '13px', color: 'royalblue', fontWeight: '700' }}>NCERT SUMMARY</h5>
                <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700' }}>History: Our Past (NCERT VI) with Practice Test - I</h5>
                <h5 style={{ fontSize: '13px', color: 'gray', fontWeight: '500' }}>Aartee Mishra</h5>
              </div>
            </div>
          </div>
          {/*  */}
          <div style={{ marginTop: '10px' }}>
            <div style={{ display: 'flex', margin: '15px', marginTop: '10px' }}>
              <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700', marginTop: '15px' }}>18 Dec 2021</h5>
              <div style={{ flex: '1' }}></div>
              <h5 style={{ fontSize: '15px', color: 'gray', fontWeight: '500', marginTop: '15px' }}>Saturday</h5>
            </div>
            <div style={{ display: 'flex', margin: '15px' }}>
              {/* <i style={{ color: 'royalblue ', marginRight: '20px', fontSize: '50px', }} className="bi bi-play-circle-fill"></i> */}
              <div style={{ backgroundColor: 'rgb(218 211 211 / 36%)', borderRadius: '10px', height: '60px' }}>
                <div style={{ padding: '10px' }}>
                  <h5 style={{ fontWeight: '700', fontSize: '13px' }}>2:30</h5>
                  <h6 style={{ fontWeight: '700', fontSize: '13px', textAlign: 'center', color: 'gray' }}>PM</h6>
                </div>
              </div>
              <div style={{ marginLeft: '15px' }}>
                <h5 style={{ fontSize: '13px', color: 'royalblue', fontWeight: '700' }}>NCERT SUMMARY</h5>
                <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700' }}>History: Our Past (NCERT VI) with Practice Test - I</h5>
                <h5 style={{ fontSize: '13px', color: 'gray', fontWeight: '500' }}>Aartee Mishra</h5>
              </div>
            </div>
          </div>
          {/*  */}
          <div style={{ marginTop: '10px' }}>
            <div style={{ display: 'flex', margin: '15px', marginTop: '10px' }}>
              <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700', marginTop: '15px' }}>20 Dec 2021</h5>
              <div style={{ flex: '1' }}></div>
              <h5 style={{ fontSize: '15px', color: 'gray', fontWeight: '500', marginTop: '15px' }}>Monday</h5>
            </div>
            <div style={{ display: 'flex', margin: '15px' }}>
              {/* <i style={{ color: 'royalblue ', marginRight: '20px', fontSize: '50px', }} className="bi bi-play-circle-fill"></i> */}
              <div style={{ backgroundColor: 'rgb(218 211 211 / 36%)', borderRadius: '10px', height: '60px' }}>
                <div style={{ padding: '10px' }}>
                  <h5 style={{ fontWeight: '700', fontSize: '13px' }}>8:00</h5>
                  <h6 style={{ fontWeight: '700', fontSize: '13px', textAlign: 'center', color: 'gray' }}>AM</h6>
                </div>
              </div>
              <div style={{ marginLeft: '15px' }}>
                <h5 style={{ fontSize: '13px', color: 'blue', fontWeight: '700' }}>ETHICS, INTEGRITY & APTITUDE</h5>
                <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700' }}>History: Our Past (NCERT VI) with Practice Test - I</h5>
                <h5 style={{ fontSize: '13px', color: 'gray', fontWeight: '500' }}>Aartee Mishra</h5>
              </div>
            </div>
            {/*  */}
            <div style={{ display: 'flex', margin: '15px' }}>
              {/* <i style={{ color: 'royalblue ', marginRight: '20px', fontSize: '50px', }} className="bi bi-play-circle-fill"></i> */}
              <div style={{ backgroundColor: 'rgb(218 211 211 / 36%)', borderRadius: '10px', height: '60px' }}>
                <div style={{ padding: '10px' }}>
                  <h5 style={{ fontWeight: '700', fontSize: '13px' }}>2:30</h5>
                  <h6 style={{ fontWeight: '700', fontSize: '13px', textAlign: 'center', color: 'gray' }}>PM</h6>
                </div>
              </div>
              <div style={{ marginLeft: '15px' }}>
                <h5 style={{ fontSize: '13px', color: 'royalblue', fontWeight: '700' }}>NCERT SUMMARY</h5>
                <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700' }}>History: Our Past (NCERT VI) with Practice Test - I</h5>
                <h5 style={{ fontSize: '13px', color: 'gray', fontWeight: '500' }}>Aartee Mishra</h5>
              </div>
            </div>
            {/*  */}
            <div style={{ display: 'flex', margin: '15px' }}>
              {/* <i style={{ color: 'royalblue ', marginRight: '20px', fontSize: '50px', }} className="bi bi-play-circle-fill"></i> */}
              <div style={{ backgroundColor: 'rgb(218 211 211 / 36%)', borderRadius: '10px', height: '60px' }}>
                <div style={{ padding: '10px' }}>
                  <h5 style={{ fontWeight: '700', fontSize: '13px' }}>6:00</h5>
                  <h6 style={{ fontWeight: '700', fontSize: '13px', textAlign: 'center', color: 'gray' }}>PM</h6>
                </div>
              </div>
              <div style={{ marginLeft: '15px' }}>
                <h5 style={{ fontSize: '13px', color: 'royalblue', fontWeight: '700' }}>NCERT SUMMARY</h5>
                <h5 style={{ fontSize: '15px', color: '#000000', fontWeight: '700' }}>History: Our Past (NCERT VI) with Practice Test - I</h5>
                <h5 style={{ fontSize: '13px', color: 'gray', fontWeight: '500' }}>Aartee Mishra</h5>
              </div>
            </div>
          </div>
        </div>
        <br />
      </div>
    </>

  );
};

export default Schedule
