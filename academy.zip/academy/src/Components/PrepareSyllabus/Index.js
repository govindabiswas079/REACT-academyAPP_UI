export { default as Schedule } from './Schedule';
export { default as Educators } from './Educators';
export { default as Syllabus } from './Syllabus';
export { default as About } from './About';