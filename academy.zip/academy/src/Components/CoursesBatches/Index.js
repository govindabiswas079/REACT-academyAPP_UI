export {default as Batches} from './Batches';
export {default as Educators} from './Educators';
export {default as Courses} from './Courses';