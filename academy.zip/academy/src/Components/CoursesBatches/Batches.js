import React from 'react';
import Carousel from 'react-grid-carousel';
import { Link, useNavigate } from 'react-router-dom';

const Batches = ({ title }) => {
  return (
    <div>
      <section id="about" className="about">
        <div className="container" data-aos="fade-up">
          <div className="row">
            <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
              <div style={{ display: 'flex' }}>
                <div>
                  <h6 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>{title}</h6>
                  {/* <h6 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Prepare with<br /> full syllabus batches</h6> */}
                </div>
                <div style={{ flex: '1' }}></div>
                <div>
                  <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px' }} to="">SEE MORE</Link>
                  <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i>
                </div>
              </div>
              <ul>
                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'gray' }} className="bi bi-check-circle"></i> Exceptional education across batches</li>
                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'gray' }} className="bi bi-check-circle"></i> Daily classes to keep you ahead</li>
                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'gray' }} className="bi bi-check-circle"></i> On-time syllabus completion</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      <Carousel cols={2} rows={1} gap={1} loop>
        <Carousel.Item>
          <div className="container py-4">
            <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
              <div style={{ height: '2px', width: '85%', backgroundColor: 'rgb(171 219 226 / 45%)', borderRadius: '10px' }}></div>
            </div>
            <div className="row align-items-md-stretch">
              <div style={{ marginTop: '5px' }} className="col-md-6">
                <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                  <div style={{ height: '2px', width: '94%', backgroundColor: 'rgb(171 219 226 / 45%)', borderRadius: '10px' }}></div>
                </div>
                <div style={{ backgroundColor: 'rgb(171 219 226 / 19%)', marginTop: '5px' }} className="h-100 p-3  border rounded-3">
                  <div style={{ display: 'flex', }}>
                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', zIndex: '9' }}>
                      <p style={{ margin: '4px', fontWeight: '700', fontFamily: 'Nunito', fontSize: '10px' }}>FULL SYLLABUS COMPLETION</p>
                    </div>
                    <div style={{ flex: '1' }}></div>
                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', zIndex: '9' }}>
                      <p style={{ margin: '4px', fontWeight: '700', fontFamily: 'Nunito', fontSize: '10px' }}>HI</p>
                    </div>
                  </div>
                  <section id="about" className="about">
                    <div className="" data-aos="fade-up">
                      <div className="row">
                        <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                          <h5 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Prepare with<br /> full syllabus batches</h5>
                          <ul style={{ textAlign: 'initial' }}>
                            <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-calendar-check"></i> Starts in 4 days. 8 Dec 2021</li>
                            <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-cloud-sun"></i> Early morning classes</li>
                            <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-person"></i> Anshuman Singh, Varun Pachauri, Ishrat jawed Faroo...</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </section>
                  <img style={{ width: '100%', borderRadius: '5px' }} src="https://uk.rs-cdn.com/site_files/cache/9559/images/feature/9a967024cac20554d42f8e611313a3b7_4bd07e3c55a996b45bacfc40df329e9e.jpg" alt="" />
                  <br />
                  <br />
                  <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                    <div style={{ display: 'flex' }}>
                      <i style={{ marginRight: '15px' }} className="bi bi-hr">
                      </i><Link style={{ color: 'black', fontFamily: 'Nunito' }} to="">View full schedule</Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Carousel.Item>
        <Carousel.Item>
          <div className="container py-4">
            <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
              <div style={{ height: '2px', width: '85%', backgroundColor: 'rgb(171 219 226 / 45%)', borderRadius: '10px' }}></div>
            </div>
            <div className="row align-items-md-stretch">
              <div style={{ marginTop: '5px' }} className="col-md-6">
                <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                  <div style={{ height: '2px', width: '94%', backgroundColor: 'rgb(171 219 226 / 45%)', borderRadius: '10px' }}></div>
                </div>
                <div style={{ backgroundColor: 'rgb(171 219 226 / 19%)', marginTop: '5px' }} className="h-100 p-3  border rounded-3">
                  <div style={{ display: 'flex', }}>
                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', zIndex: '9' }}>
                      <p style={{ margin: '4px', fontWeight: '700', fontFamily: 'Nunito', fontSize: '10px' }}>FULL SYLLABUS COMPLETION</p>
                    </div>
                    <div style={{ flex: '1' }}></div>
                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', zIndex: '9' }}>
                      <p style={{ margin: '4px', fontWeight: '700', fontFamily: 'Nunito', fontSize: '10px' }}>HI</p>
                    </div>
                  </div>
                  <section id="about" className="about">
                    <div className="" data-aos="fade-up">
                      <div className="row">
                        <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                          <h5 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Prepare with<br /> full syllabus batches</h5>
                          <ul style={{ textAlign: 'initial' }}>
                            <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-calendar-check"></i> Starts in 4 days. 8 Dec 2021</li>
                            <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-cloud-sun"></i> Early morning classes</li>
                            <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-person"></i> Anshuman Singh, Varun Pachauri, Ishrat jawed Faroo...</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </section>
                  <img style={{ width: '100%', borderRadius: '5px' }} src="https://uk.rs-cdn.com/site_files/cache/9559/images/feature/9a967024cac20554d42f8e611313a3b7_4bd07e3c55a996b45bacfc40df329e9e.jpg" alt="" />
                  <br />
                  <br />
                  <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                    <div style={{ display: 'flex' }}>
                      <i style={{ marginRight: '15px' }} className="bi bi-hr">
                      </i><Link style={{ color: 'black', fontFamily: 'Nunito' }} to="">View full schedule</Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Carousel.Item>
      </Carousel>
    </div>
  );
};

export default Batches
