import React from 'react';
import Carousel from 'react-grid-carousel';
import { Link, useNavigate } from 'react-router-dom';

const Educators = () => {
   return (
      <div>

      </div>
   );
};

export default Educators
