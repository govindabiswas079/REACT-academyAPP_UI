import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Syllabus = () => {
    let navigate = useNavigate();

    const [nav, setNav] = React.useState(false)

    const changeBackground = () => {
        if (window.scrollY >= 50) {
            setNav(true);
        } else {
            setNav(false);
        }
    }
    window.addEventListener('scroll', changeBackground);

    const handleClick = (e) => {
        navigate('/subject')
        console.log(e)
    };

    return (
        <div style={{ backgroundColor: 'rgb(249 249 249)' }}>
            <header className={nav ? "header active" : "header"}>
                <div style={{ marginTop: '10px' }} className="container">
                    <div style={{ display: 'flex' }} className="header-main">
                        <div className="logo2">
                            {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                            <Link to="/self-study"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                            <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Syllabus</Link>
                        </div>
                        <div style={{ flex: '1' }}></div>
                    </div>
                </div>
            </header>
            <br />
            <br />
            <br />
            <div style={{ margin: '20px' }}>
                <div style={{ marginTop: '0px' }}>
                    <div>
                        <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontFamily: 'Nunito', }}>Subscribe and access</h6>
                        <h5 style={{ width: '100%', color: '#000000', fontWeight: 'bolder', fontFamily: 'Nunito', lineHeight: '20px' }}>Complete UPSC CSE - GS</h5>
                        <h5 style={{ width: '100%', color: '#000000', fontWeight: 'bolder', fontFamily: 'Nunito', lineHeight: '20px' }}>Syllabus with <span style={{ color: '#08bd80' }}>Structured <br />Course</span></h5>
                    </div>
                    <br />
                </div>
                <section id="features" className="featuress">
                    <div className="" data-aos="fade-up">
                        <div className="row">
                            <div className="col-lg-3 col-md-4">
                                {/*  <Paper elevation={0} square style={{ backgroundColor: '#FFFFFF', borderRadius: '10px',  }}> */}
                                <div onClick={(e) => handleClick('physics')} className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: 'coral' }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                                        <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}><span style={{ color: '#FFFFFF', backgroundColor: 'coral', borderRadius: '50px', padding: '3px', fontSize: '13px' }}>123 Upcoming</span> 45 courses</h6>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                                </div>
                                {/*  </Paper> */}
                            </div>
                        </div>
                    </div>
                    <div className="" data-aos="fade-up">
                        <div className="row">
                            <div className="col-lg-3 col-md-4 mt-3">
                                {/*  <Paper elevation={0} square style={{ backgroundColor: '#FFFFFF', borderRadius: '10px',  }}> */}
                                <div onClick={(e) => handleClick('physics')} className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#6495ED' }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                                        <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}><span style={{ color: '#FFFFFF', backgroundColor: 'coral', borderRadius: '50px', padding: '3px', fontSize: '13px' }}>123 Upcoming</span> 45 courses</h6>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                                </div>
                                {/*  </Paper> */}
                            </div>
                        </div>
                    </div>
                    <div className="" data-aos="fade-up">
                        <div className="row">
                            <div className="col-lg-3 col-md-4 mt-3">
                                {/*  <Paper elevation={0} square style={{ backgroundColor: '#FFFFFF', borderRadius: '10px',  }}> */}
                                <div onClick={(e) => handleClick('physics')} className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#8B008B' }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                                        <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}><span style={{ color: '#FFFFFF', backgroundColor: 'coral', borderRadius: '50px', padding: '3px', fontSize: '13px' }}>123 Upcoming</span> 45 courses</h6>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                                </div>
                                {/*  </Paper> */}
                            </div>
                        </div>
                    </div>
                    <div className="" data-aos="fade-up">
                        <div className="row">
                            <div className="col-lg-3 col-md-4 mt-3">
                                {/*  <Paper elevation={0} square style={{ backgroundColor: '#FFFFFF', borderRadius: '10px',  }}> */}
                                <div onClick={(e) => handleClick('physics')} className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#006400' }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                                        <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}><span style={{ color: '#FFFFFF', backgroundColor: 'coral', borderRadius: '50px', padding: '3px', fontSize: '13px' }}>123 Upcoming</span> 45 courses</h6>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                                </div>
                                {/*  </Paper> */}
                            </div>
                        </div>
                    </div>
                    <div className="" data-aos="fade-up">
                        <div className="row">
                            <div className="col-lg-3 col-md-4 mt-3">
                                {/*  <Paper elevation={0} square style={{ backgroundColor: '#FFFFFF', borderRadius: '10px',  }}> */}
                                <div onClick={(e) => handleClick('physics')} className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#2F4F4F' }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                                        <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}><span style={{ color: '#FFFFFF', backgroundColor: 'coral', borderRadius: '50px', padding: '3px', fontSize: '13px' }}>123 Upcoming</span> 45 courses</h6>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                                </div>
                                {/*  </Paper> */}
                            </div>
                        </div>
                    </div>
                    <br />
                </section>
            </div >
            {/* <div style={{ margin: '20px' }}>
                
            </div> */}

            <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
                <div data-aos="fade-up">
                    <div className="row" data-aos="zoom-in" data-aos-delay="100">
                        <div className="col-lg-3 col-md-4">
                            <div className="icon-box">
                                <br />
                                <div>
                                    <h6 style={{ color: 'gray', fontWeight: '500' }}>Access more than</h6>
                                    <h5 style={{ color: 'coral', fontWeight: '900' }}>4,894+ courses</h5>
                                    <h5 style={{ color: 'gray', fontWeight: '900' }}>for UPSC CSE - GS</h5>
                                </div>
                                <div style={{ flex: '1' }}></div>
                                <img style={{ width: '30%' }} src="https://www.eurolaser.com/fileadmin/eurolaser/Service/EUROLASER-ACADEMY---Advance-training-in-laser-technology-topics.png" alt="" />
                                <br />
                            </div>

                            <div style={{ margin: '10px 10px' }} className="d-grid gap-2 d-md-block">
                                <button style={{ fontWeight: '600', backgroundColor: '#08bd80', fontFamily: 'Nunito', color: '#FFFFFF' }} className="btn btn-lg" type="button">Get subscription</button>
                            </div>
                            <br />
                        </div>
                    </div>
                </div>
            </section>
        </div >
    )
}

export default Syllabus
