import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';

const GetInTouch = () => {
   let Navigate = useNavigate();
   const number = sessionStorage.getItem('Mobile')
   const userData = sessionStorage.getItem('userData')
   let jsonObject = JSON.parse(userData);


   const submit = (e) => {
      e.preventDefault();
      // swal("Thank You");

      Navigate('/home')


   }

   return (
      <div className='GetInTouchbgImg'>
         <div >
            <div style={{ padding: '15px', position: 'relative' }}>
               <Link to="/home"><i style={{ fontSize: '25px', fontWeight: 'bolder', color: '#000000' }} className="bi bi-x-lg"></i></Link>
            </div>
         </div>

         <Box className='icon-boxxxx'>
            <Paper elevation={3}>
               <div style={{ margin: '20px', marginTop: '0px' }}>
                  <br />
                  <div style={{ marginTop: '20px' }}>
                     <h3 style={{ fontFamily: 'Nunito', fontWeight: '900', fontSize: '20px', marginTop: '20px' }}>Where can we reach out to you?</h3>
                  </div>
                  <br />
                  <label style={{ fontSize: '18px', fontWeight: '600' }}>Your name<span style={{ color: 'red', fontSize: '22px', fontWeight: '' }}>*</span></label>
                  <TextField aria-readonly id="standard-basic" variant="standard" value={jsonObject.Name} fullWidth />
                  <br />
                  <br />
                  <label style={{ fontSize: '18px', fontWeight: '600' }}>Your mobile number<span style={{ color: 'red', fontSize: '22px', fontWeight: '' }}>*</span></label>
                  <TextField aria-readonly id="standard-basic" variant="standard" value={`+${number}`} fullWidth />
                  <br />
                  <br />
                  <div className="d-grid gap-2">
                     <button className="btn btn-lg" style={{ fontSize: '15px', backgroundColor: '#08bd80', color: '#FFFFFF', fontFamily: 'Nunito' }} type="button" onClick={(e) => submit(e)}>Confirm</button>
                  </div>
                  <div className="d-gridd gap-2">
                     {/* <br />
                     <br />
                     <br /> */}
                  </div>
               </div>
            </Paper>
         </Box>
         {/* <br />
         <br />
         <br /> */}
      </div>
   );
};
export default GetInTouch;