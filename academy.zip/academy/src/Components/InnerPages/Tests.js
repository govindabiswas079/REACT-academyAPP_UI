import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Carousel from 'react-grid-carousel';
import Avatar from '@mui/material/Avatar';
import AvatarGroup from '@mui/material/AvatarGroup';

const Tests = () => {
   let navigate = useNavigate();
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const Subscription = () => {
      navigate('/subscription')
   }

   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/self-study"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Tests & Practice</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <div style={{ backgroundColor: '#FFFFFF', }}>
            <br />
            <div style={{ margin: '20px' }}>
               <div >
                  <div>
                     <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontFamily: 'Nunito', }}>Subscribe and access</h6>
                     <h5 style={{ width: '100%', color: '#08bd80', fontWeight: 'bolder', fontFamily: 'Nunito', }}>Live Test & Unlimited Question</h5>
                     <h5 style={{ width: '100%', color: '#000000', fontWeight: '700', fontFamily: 'Nunito', }}>to evaluate your preparation</h5>
                  </div>
                  <br />
               </div>
            </div>
            <section id="features" className="features">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4">
                        <div className="icon-box" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '18px' }}>Combat</h3>
                              <p style={{ fontWeight: '500', color: 'gray', marginTop: '10px', fontSize: '12px' }}>The most comperitive & gamified<br /> UPSC CSE battle is here</p>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img src="https://static.uacdn.net/web-cms/about_5a13152701.svg" alt="" />
                        </div>
                     </div>
                  </div>
               </div>
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-box" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '18px' }}>Live Quiz</h3>
                              <p style={{ fontWeight: '500', color: 'gray', marginTop: '10px', fontSize: '12px' }}>Join or Host a live quiz.<br /> Compete with other learners</p>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img src="https://static.uacdn.net/web-cms/syllabus_710041a346.svg" alt="" />
                        </div>
                     </div>
                  </div>
               </div>
               <br />
            </section>
            <section id="features" className="features">
               <div style={{ marginTop: '0px' }} className="container" data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div style={{ display: 'flex', }}>
                           <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '80px', backgroundColor: '#FFFFFF' }} className="icon-box">
                              <div style={{ display: 'flex', float: 'left' }}>
                                 <i className="bi bi-joystick"></i>
                                 <div style={{ flex: '1' }}></div>
                                 <p style={{ marginTop: '8px', fontSize: '15px', fontWeight: '700' }}>Practice</p>
                              </div>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '80px', backgroundColor: '#FFFFFF' }} className="icon-box">
                              <div style={{ display: 'flex', float: 'left' }}>
                                 <i className="bi bi-cloud-arrow-down-fill"></i>
                                 <div style={{ flex: '1' }}></div>
                                 <p style={{ marginTop: '8px', fontSize: '15px', fontWeight: '700' }}>Test series</p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <br />
            </section>
         </div>

         <div style={{ backgroundColor: '#FFFFFF', marginTop: '5px' }}>
            <br />
            <div style={{ display: 'flex' }}>

               <h6 style={{ fontWeight: '900', marginLeft: '20px' }}>Upcoming Combat</h6>
               <div style={{ flex: '1' }}></div>
               <Link style={{ fontWeight: '900', marginRight: '20px', fontSize: '12px' }} to="">See all</Link>
            </div>
            <br />
            <section id="features" className="features">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4">
                        <div id='my-icon-box' className="icon-box" style={{ borderRadius: '10px 10px 0px 0px', }}>
                           <div style={{ flexDirection: 'column' }}>
                              <br />
                              <h3 style={{ fontWeight: '900', fontSize: '20px' }}>UPSC CSE Combat</h3>
                              <p style={{ fontWeight: '500', color: 'gray', marginTop: '10px' }}>Starts in 6 days</p>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img src="https://static.uacdn.net/web-cms/about_5a13152701.svg" alt="" />
                           <br />
                        </div>
                        <div className="icon-box" style={{ backgroundColor: '#FFFFFF', borderRadius: '0px 0px 10px 10px' }}>
                           <div>
                              <div>
                                 <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Dec 12, 11:00 AM</h3>
                                 <p style={{ fontWeight: '500', color: 'gray', marginTop: '10px', fontSize: '12px' }}>7 Rounds • 60mins</p>
                                 <div style={{ display: 'flex' }}>
                                    <AvatarGroup>
                                       <Avatar alt="Remy Sharp" src="https://www.diethelmtravel.com/wp-content/uploads/2016/04/bill-gates-wealthiest-person.jpg" />
                                       <Avatar alt="Travis Howard" src="https://www.diethelmtravel.com/wp-content/uploads/2016/04/bill-gates-wealthiest-person.jpg" />
                                       <Avatar alt="Cindy Baker" src="https://www.diethelmtravel.com/wp-content/uploads/2016/04/bill-gates-wealthiest-person.jpg" />
                                       <Avatar alt="Agnes Walker" src="https://www.diethelmtravel.com/wp-content/uploads/2016/04/bill-gates-wealthiest-person.jpg" />
                                       <Avatar alt="Trevor Henderson" src="https://www.diethelmtravel.com/wp-content/uploads/2016/04/bill-gates-wealthiest-person.jpg" />
                                    </AvatarGroup>
                                    <h3 style={{ marginTop: '15px', color: 'grey' }}>+3 Educators</h3>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <br />
            </section>
         </div>
         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <section id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Test Series</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '10px' }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '10px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={2} rows={1} gap={1} loop>
               <Carousel.Item>
                  <div className="container py-1">
                     <div className='TestSeries'>{/* style={{borderTopWidth: '10px', borderTopColor: 'coral'}} */}
                        <div>
                           <div>
                              <div style={{ marginLeft: '15px', marginTop: '15px' }} className="h-100 p-1">
                                 <p style={{ fontWeight: '700', fontFamily: 'Nunito', fontSize: '15px' }}>T20 Daily Current Affairs Test Series <br />- December</p>
                                 <div>
                                    <Link to="" style={{ backgroundColor: 'coral', fontWeight: '700', fontFamily: 'Nunito', padding: '5px', borderRadius: '10px', color: '#FFFFFF', fontSize: '10px' }}>FREE</Link>
                                 </div>
                                 <br />
                                 <br />
                                 <div style={{ display: 'flex' }}>
                                    <p style={{ fontWeight: '700', fontFamily: 'Nunito', fontSize: '13px', color: 'gray' }}>Test 4 on Dec 6, 7:30 PM</p>
                                    <div style={{ flex: '1', }} />
                                    <i style={{ marginRight: '20px', fontSize: '13px' }} className="bi bi-terminal-plus"></i>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div className="container py-1">
                     <div className='TestSeries'>{/* style={{borderTopWidth: '10px', borderTopColor: 'coral'}} */}
                        <div>
                           <div>
                              <div style={{ marginLeft: '15px', marginTop: '15px' }} className="h-100 p-1">
                                 <p style={{ fontWeight: '700', fontFamily: 'Nunito', fontSize: '15px' }}>T20 Daily Current Affairs Test Series <br />- December</p>
                                 <div>
                                    <Link to="" style={{ backgroundColor: 'coral', fontWeight: '700', fontFamily: 'Nunito', padding: '5px', borderRadius: '10px', color: '#FFFFFF', fontSize: '10px' }}>FREE</Link>
                                 </div>
                                 <br />
                                 <br />
                                 <div style={{ display: 'flex' }}>
                                    <p style={{ fontWeight: '700', fontFamily: 'Nunito', fontSize: '13px', color: 'gray' }}>Test 4 on Dec 6, 7:30 PM</p>
                                    <div style={{ flex: '1', }} />
                                    <i style={{ marginRight: '20px', fontSize: '13px' }} className="bi bi-terminal-plus"></i>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </Carousel.Item>
            </Carousel>

            <section id="features" className="features">
               <div data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div className="icon-box">
                           <br />
                           <div>
                              <h6 style={{ color: 'gray', fontWeight: '500' }}>Access more than</h6>
                              <h5 style={{ color: 'coral', fontWeight: '900' }}>4,894+ Test</h5>
                              <h5 style={{ color: 'gray', fontWeight: '900' }}>for UPSC CSE - GS</h5>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img style={{ width: '30%' }} src="https://www.eurolaser.com/fileadmin/eurolaser/Service/EUROLASER-ACADEMY---Advance-training-in-laser-technology-topics.png" alt="" />
                           <br />
                        </div>
                     </div>
                  </div>
               </div>
            </section>

            <br />
            <div style={{ margin: '0 10px' }} className="d-grid gap-2 d-md-block">
               <button onClick={(e) => Subscription(e)} style={{ fontWeight: '700', backgroundColor: '#08bd80', fontFamily: 'Nunito', color: '#FFFFFF', fontSize: '15px' }} className="btn btn-lg" type="button">Get subscription</button>
            </div>
            <br />
            <br />
         </div>
      </div>
   );
};

export default Tests


/*  */

/* background-color: #330033;
background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 800 800'%3E%3Cg fill='none' stroke='%23404' stroke-width='1'%3E%3Cpath d='M769 229L1037 260.9M927 880L731 737 520 660 309 538 40 599 295 764 126.5 879.5 40 599-197 493 102 382-31 229 126.5 79.5-69-63'/%3E%3Cpath d='M-31 229L237 261 390 382 603 493 308.5 537.5 101.5 381.5M370 905L295 764'/%3E%3Cpath d='M520 660L578 842 731 737 840 599 603 493 520 660 295 764 309 538 390 382 539 269 769 229 577.5 41.5 370 105 295 -36 126.5 79.5 237 261 102 382 40 599 -69 737 127 880'/%3E%3Cpath d='M520-140L578.5 42.5 731-63M603 493L539 269 237 261 370 105M902 382L539 269M390 382L102 382'/%3E%3Cpath d='M-222 42L126.5 79.5 370 105 539 269 577.5 41.5 927 80 769 229 902 382 603 493 731 737M295-36L577.5 41.5M578 842L295 764M40-201L127 80M102 382L-261 269'/%3E%3C/g%3E%3Cg fill='%23505'%3E%3Ccircle cx='769' cy='229' r='5'/%3E%3Ccircle cx='539' cy='269' r='5'/%3E%3Ccircle cx='603' cy='493' r='5'/%3E%3Ccircle cx='731' cy='737' r='5'/%3E%3Ccircle cx='520' cy='660' r='5'/%3E%3Ccircle cx='309' cy='538' r='5'/%3E%3Ccircle cx='295' cy='764' r='5'/%3E%3Ccircle cx='40' cy='599' r='5'/%3E%3Ccircle cx='102' cy='382' r='5'/%3E%3Ccircle cx='127' cy='80' r='5'/%3E%3Ccircle cx='370' cy='105' r='5'/%3E%3Ccircle cx='578' cy='42' r='5'/%3E%3Ccircle cx='237' cy='261' r='5'/%3E%3Ccircle cx='390' cy='382' r='5'/%3E%3C/g%3E%3C/svg%3E"); */