import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { JoinQuize } from './Index'

const LiveQuiz = () => {
   let navigate = useNavigate();
   const [nav, setNav] = React.useState(false)
   const [open, setOpen] = React.useState(false);
   const [exam, setExam] = React.useState(1);

   const handleClickOpen = () => {
      setExam(exam + 1)
      sessionStorage.setItem('exam', exam);
      setOpen(true);
   };

   const handleClose = () => {
      setOpen(false);
   };

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const HostQuiz = () => {
      navigate('/host-quiz')
   }

   const getcount = sessionStorage.getItem('exam')

   return (
      <div style={{ backgroundColor: '#FFFFFF' }}>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/home"><i className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px' }} to="">Live Quiz</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <br />
         <section id="features" className="features">
            <div className="container" data-aos="fade-up">
               <div className="row">
                  <div className="col-lg-3 col-md-4">
                     <div className='quizIconBoxSec1' style={{ borderRadius: '10px 10px 0px 0px' }}>
                        <div style={{ display: 'flex', }}>
                           <div style={{ flexDirection: 'column' }}>
                              <p style={{ fontWeight: '500', color: 'gray', marginTop: '10px', fontFamily: 'Nunito' }}>Last quiz started</p>
                              <h5 style={{ fontWeight: '900', fontFamily: 'Nunito', lineHeight: '1px' }}>2m 11s ago</h5>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <button style={{ marginTop: '30px', fontWeight: 'bold', backgroundColor: '#08bd80', color: '#FFFFFF', fontFamily: 'Nunito' }} type="button" className="btn  btn-sm">Join quiz</button>
                           </div>
                        </div>
                     </div>
                     <div className='quizIconBoxSec2' style={{ backgroundColor: '#FFFFFF', borderRadius: '0px 0px 10px 10px' }}>
                        <div>
                           <div style={{ flexDirection: 'column', }}>
                              <h6 style={{ fontWeight: '500', color: 'gray', fontFamily: 'Nunito' }}>Topic</h6>
                              <h6 style={{ fontWeight: '900', fontFamily: 'Nunito' }}>General</h6>
                           </div>
                           <div style={{ display: 'flex' }}>
                              <div>
                                 <p style={{ fontFamily: 'Nunito', lineHeight: '10px' }}>Questions</p>
                                 <h6 style={{ fontWeight: '700', fontFamily: 'Nunito', lineHeight: '5px' }}>50</h6>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <div>
                                 <p style={{ fontFamily: 'Nunito', lineHeight: '10px' }}>Time per ques.</p>
                                 <h6 style={{ fontWeight: '700', fontFamily: 'Nunito', lineHeight: "5px" }}>60 secs</h6>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <br />
         </section>
         <div>
            <section id="features" className="features">
               <div style={{ marginTop: '10px' }} className="container" data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div style={{ display: 'flex', }}>
                           <div style={{ flexDirection: 'column' }}>
                              <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', }} className="icon-box">
                                 <div>
                                    <img src="https://static.uacdn.net/thumbnail/learner_hat_icon/brown-hat.png" alt="" style={{ width: '30%', lineHeight: '30px' }} />
                                    <p style={{ lineHeight: '50px', color: 'gray', fontFamily: 'Nunito' }}>Credits earned</p>
                                    <p style={{ fontWeight: '600', fontFamily: 'Nunito' }}>0</p>
                                 </div>
                              </div>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div style={{ flexDirection: 'column' }}>
                              <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', }} className="icon-box">
                                 <div>
                                    <img src="https://static.uacdn.net/web-cms/Asset4_7d0b0e4c32.png" alt="" style={{ width: '70%', lineHeight: '30px' }} />
                                    <p style={{ lineHeight: '50px', color: 'gray', fontFamily: 'Nunito' }}>Attempted</p>
                                    <p style={{ fontWeight: '900', fontFamily: 'Nunito' }}>{getcount ? getcount : 0}</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </div>
         <div className="d-grid gap-2 col-6 mx-auto">
            <Link to="" className="btn btn-link" type="button" style={{ fontWeight: '900', fontSize: '20px', textDecoration: 'none', fontFamily: 'Nunito' }}>See all quizzes</Link>
         </div>
         <br />
         <br />
         <div style={{ margin: '20px' }} className="d-flex ">
            <button onClick={(e) => HostQuiz(e)} className="btn btn-outline-secondary btn-lg" style={{ color: '#08bd80', fontWeight: '500' }} type="button">Host Quiz</button>
            <div style={{ flex: '1' }}></div>
            {/* <button className="btn btn-lg" style={{ backgroundColor: '#08bd80', fontWeight: '500' }} type="button">Join quiz</button> */}
            <JoinQuize handleClickOpen={handleClickOpen} handleClose={handleClose} open={open} />
         </div>
         <br />
      </div>
   );
};

export default LiveQuiz

