import React from 'react';
import { Link } from 'react-router-dom';

const Practice = () => {
    const [nav, setNav] = React.useState(false)

    const changeBackground = () => {
        if (window.scrollY >= 50) {
            setNav(true);
        } else {
            setNav(false);
        }
    }
    window.addEventListener('scroll', changeBackground);

    return (
        <div style={{ backgroundColor: '#FFFFFF', }}>
            <header className={nav ? "header active" : "header"}>
                <div style={{ marginTop: '10px' }} className="container">
                    <div style={{ display: 'flex' }} className="header-main">
                        <div className="logo2">
                            {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                            <Link to="/self-study"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                            <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Practice</Link>
                        </div>
                        <div style={{ flex: '1' }}></div>
                    </div>
                </div>
            </header>
            <br />
            <br />
            <br />
            <section id="features" className="features">
                <div data-aos="fade-up">
                    <div className="row" data-aos="zoom-in" data-aos-delay="100">
                        <div className="col-lg-3 col-md-4">
                            <div className="icon-box">
                                <br />
                                <div>
                                    <h6 style={{ color: 'gray', fontWeight: '500' }}>Access more than</h6>
                                    <h5 style={{ color: 'coral', fontWeight: '900' }}>4,894+ courses</h5>
                                    <h5 style={{ color: 'gray', fontWeight: '900' }}>for UPSC CSE - GS</h5>
                                </div>
                                <div style={{ flex: '1' }}></div>
                                <img style={{ width: '30%' }} src="https://www.eurolaser.com/fileadmin/eurolaser/Service/EUROLASER-ACADEMY---Advance-training-in-laser-technology-topics.png" alt="" />
                                <br />
                            </div>

                            <div style={{ margin: '10px 10px' }} className="d-grid gap-2 d-md-block">
                                <button style={{ fontWeight: '700', backgroundColor: '#08bd80', fontFamily: 'Nunito', color: '#FFFFFF', fontSize: '15px' }} className="btn btn-lg" type="button">Get subscription</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <br />
            <div>
                <h3 style={{ marginLeft: '20px ' }}>Topics</h3>
                <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
                    <div style={{ marginTop: '10px' }} className="container" data-aos="fade-up">
                        <div className="row" data-aos="zoom-in" data-aos-delay="100">
                            <div className="col-lg-3 col-md-4">
                                <div style={{ display: 'flex', }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', background: 'linear-gradient(#e66465, #9198e5)' }} className="icon-box">
                                            <div style={{ display: 'flex', float: 'left' }}>
                                                {/* <i style={{ marginTop: "50px" }} className="bi bi-joystick"></i> */}
                                                <img style={{ width: '120px' }} src="https://scsp.apcfss.in/images/exp2.png" alt="" />
                                            </div>
                                        </div>
                                        <p style={{ fontWeight: '700', marginTop: '8px', fontSize: '13px' }}>Indian Ecinomy</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ flexDirection: 'column' }}>
                                        <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', background: 'linear-gradient(#e66465, #9198e5)' }} className="icon-box">
                                            <div style={{ display: 'flex', float: 'left' }}>
                                                <img style={{ width: '120px' }} src="https://cdn-icons-png.flaticon.com/512/2997/2997187.png" alt="" />
                                            </div>
                                        </div>
                                        <p style={{ fontWeight: '700', marginTop: '8px', fontSize: '13px' }}>Indian Ecinomy</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3 col-md-4 mt-3">
                                <div style={{ display: 'flex', }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', background: 'linear-gradient(#e66465, #9198e5)' }} className="icon-box">
                                            <div style={{ display: 'flex', float: 'left' }}>
                                                {/* <i style={{ marginTop: "50px" }} className="bi bi-joystick"></i> */}
                                                <img style={{ width: '120px' }} src="https://static.thenounproject.com/png/3191256-200.png" alt="" />
                                            </div>
                                        </div>
                                        <p style={{ fontWeight: '700', marginTop: '8px', fontSize: '13px' }}>Science & Techonology</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ flexDirection: 'column' }}>
                                        <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', background: 'linear-gradient(#e66465, #9198e5)' }} className="icon-box">
                                            <div style={{ display: 'flex', float: 'left' }}>
                                                <img style={{ width: '120px' }} src="https://cdn3.iconfinder.com/data/icons/security-testing/128/protection-security_testing-lock-privacy-protection-quality_asurance-512.png" alt="" />
                                            </div>
                                        </div>
                                        <p style={{ fontWeight: '700', marginTop: '8px', fontSize: '13px' }}>Indian Society</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3 col-md-4 mt-3">
                                <div style={{ display: 'flex', }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', background: 'linear-gradient(#e66465, #9198e5)' }} className="icon-box">
                                            <div style={{ display: 'flex', float: 'left' }}>
                                                {/* <i style={{ marginTop: "50px" }} className="bi bi-joystick"></i> */}
                                                <img style={{ width: '120px' }} src="https://static.thenounproject.com/png/3191256-200.png" alt="" />
                                            </div>
                                        </div>
                                        <p style={{ fontWeight: '700', marginTop: '8px', fontSize: '13px' }}>Science & Techonology</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ flexDirection: 'column' }}>
                                        <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', background: 'linear-gradient(#e66465, #9198e5)' }} className="icon-box">
                                            <div style={{ display: 'flex', float: 'left' }}>
                                                <img style={{ width: '120px' }} src="https://cdn3.iconfinder.com/data/icons/security-testing/128/protection-security_testing-lock-privacy-protection-quality_asurance-512.png" alt="" />
                                            </div>
                                        </div>
                                        <p style={{ fontWeight: '700', marginTop: '8px', fontSize: '13px' }}>Indian Society</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3 col-md-4 mt-3">
                                <div style={{ display: 'flex', }}>
                                    <div style={{ flexDirection: 'column' }}>
                                        <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', background: 'linear-gradient(#e66465, #9198e5)' }} className="icon-box">
                                            <div style={{ display: 'flex', float: 'left' }}>
                                                {/* <i style={{ marginTop: "50px" }} className="bi bi-joystick"></i> */}
                                                <img style={{ width: '120px' }} src="https://static.thenounproject.com/png/3191256-200.png" alt="" />
                                            </div>
                                        </div>
                                        <p style={{ fontWeight: '700', marginTop: '8px', fontSize: '13px' }}>Science & Techonology</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ flexDirection: 'column' }}>
                                        <div style={{ borderRadius: '10px', flexDirection: 'column', width: '160px', height: '160px', background: 'linear-gradient(#e66465, #9198e5)' }} className="icon-box">
                                            <div style={{ display: 'flex', float: 'left' }}>
                                                <img style={{ width: '120px' }} src="https://cdn3.iconfinder.com/data/icons/security-testing/128/protection-security_testing-lock-privacy-protection-quality_asurance-512.png" alt="" />
                                            </div>
                                        </div>
                                        <p style={{ fontWeight: '700', marginTop: '8px', fontSize: '13px' }}>Indian Society</p>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>

                    <br />
                </section>
            </div>
        </div>
    );
};

export default Practice
