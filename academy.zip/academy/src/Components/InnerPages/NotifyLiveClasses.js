import React from 'react';
import Carousel from 'react-grid-carousel';
import { Link, useNavigate } from 'react-router-dom';
// import HistoryofIndia from '../../PDF/HistoryofIndia.pdf';
import modrenHistory from '../../Video/modrenHistory.mp4'

const HistoryofIndia = 'https://drive.google.com/file/d/1IQ52g9QrTKmcITF1ew2CyUfOUSEjZQuy/view'

const NotifyLiveClasses = () => {
   let navigate = useNavigate()
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);



   const History = (e) => {
      // HistoryofIndia
      console.log('HistoryofIndia')
   };

   const WatchClass = (e) => {
      navigate('/VideoPlayer')
   }

   return (
      <>
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <header className={nav ? "header active" : "header"}>
               <div style={{ marginTop: '10px' }} className="container">
                  <div style={{ display: 'flex' }} className="header-main">
                     <div className="logo2">
                        <Link to="/notify"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     </div>
                     <div style={{ flex: '1' }}></div>
                     <Link to="/self-study"><i style={{ fontSize: '20px', color: '#000000' }} className="bi bi-share"></i></Link>
                  </div>
               </div>
            </header>
            <br />
            <br />
            <br />
            <div style={{ margin: '0px 15px' }}>
               <div className="bgImg">
                  <div style={{ borderRadius: '10px' }} className="freeClasses">{/* onClick={(e) => livecalsses(e)} */}
                     <div>
                        <div>
                           <div className="h-100 p-1">
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', margin: '5px 5px', display: 'flex', height: '23px', width: '63px', justifyContent: 'center' }}>
                                    <i className="bi bi-eye" style={{ fontSize: '15px', fontWeight: '700', marginTop: '1px', marginRight: '4px' }}></i>
                                    <h5 style={{ fontSize: '15px', fontWeight: '700', marginTop: '3px' }}>206</h5>
                                 </div>
                                 <div style={{ flex: '1' }}></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '20px 10px', lineHeight: '2px' }}>
                  <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>HISTORY</p>
                  <h5 style={{ fontWeight: '900', fontFamily: 'Nunito' }}>MODERN HISTORY WITH MCQ</h5>
                  <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>9 Dec</h6>
               </div>
               <br />
            </div>
            <div style={{ margin: '0 15px' }} className="d-grid gap-2">
               <div style={{ display: 'flex' }}>
                  <button type="button" onClick={(e) => WatchClass(e)} className="btn btn-primary btn-lg" style={{ cursor: 'pointer', fontFamily: 'Nunito', backgroundColor: 'transparent', color: '#000000', borderWidth: '1.5px', borderColor: 'grey', fontWeight: '700', }}>
                     <i style={{ marginRight: '15px', }} className="bi bi-play-circle-fill"></i>
                     Watch Class
                  </button>
                  <div style={{ flex: '1' }}></div>
                  <button type="button" onClick={(e) => History(e)} className="btn btn-primary btn-lg" style={{ cursor: 'pointer', fontFamily: 'Nunito', backgroundColor: 'transparent', color: '#000000', borderWidth: '1.5px', borderColor: 'grey', fontWeight: '700', }}>
                     <a href={modrenHistory} download><i className="bi bi-cloud-arrow-down" onClick={(e) => History(e)}></i></a>
                  </button>
                  <div style={{ flex: '1' }}></div>
                  <button type="button" onClick={(e) => History(e)} className="btn btn-primary btn-lg" style={{ cursor: 'pointer', fontFamily: 'Nunito', backgroundColor: 'transparent', color: '#000000', borderWidth: '1.5px', borderColor: 'grey', fontWeight: '700', }} onClick={(e) => History(e)} >
                     <a href={HistoryofIndia} download><i style={{ cursor: 'pointer' }} className="bi bi-file-earmark-pdf" ></i></a>
                  </button>
               </div>
            </div>
            <br />
         </div>

         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            {/* <a href={HistoryofIndia}>HistoryofIndia</a> */}
            <section id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div style={{ marginTop: '10px' }}>
                     <h5 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Courses on all subjects</h5>
                  </div>
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Upcoming</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={2} rows={1} gap={1} loop>
               <Carousel.Item>
                  <div className="container py-4">
                     <div className="Upcoming">
                        <div>
                           <div>
                              <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>STARTS 8 DEC, 2:00 PM</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                     <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                     <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                     <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div className="container py-4">
                     <div className="Upcoming">
                        <div>
                           <div>
                              <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>STARTS 8 DEC, 2:00 PM</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                     <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                     <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                     <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
                  </div>
               </Carousel.Item>
            </Carousel>

            {/* <section style={{ marginTop: '30px' }} id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Recently started</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={2} rows={1} gap={1} loop>
               <Carousel.Item>
                  <div className="container py-1">
                     <div className="Upcoming">
                        <div>
                           <div>
                              <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>5 DEC, 5:30 PM</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                     <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                     <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                     <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div className="container py-1">
                     <div className="Upcoming">
                        <div>
                           <div>
                              <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>5 DEC, 5:30 PM</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                     <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                     <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                     <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                  </div>
               </Carousel.Item>
            </Carousel> */}


            {/* <section style={{ marginTop: '30px' }} id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Completed</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={2} rows={1} gap={1} loop>
               <Carousel.Item>
                  <div className="container py-4">
                     <div className="Upcoming">
                        <div>
                           <div>
                              <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>Completed 8 DEC, 2:00 PM</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                     <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                     <h4 style={{ fontWeight: '500', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                     <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div className="container py-4">
                     <div className="Upcoming">
                        <div>
                           <div>
                              <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>Completed 8 DEC, 2:00 PM</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                       <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                     <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                     <h4 style={{ fontWeight: '500', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                     <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                  </div>
               </Carousel.Item>
            </Carousel> */}
            <br />
         </div>
         <br />

      </>
   );
};

export default NotifyLiveClasses
