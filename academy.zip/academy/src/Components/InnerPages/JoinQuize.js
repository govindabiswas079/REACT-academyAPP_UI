import React from 'react';
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import CloseIcon from '@mui/icons-material/Close';
import Slide from '@mui/material/Slide';
import { useNavigate } from 'react-router-dom';

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const JoinQuize = ({ open, handleClickOpen, handleClose }) => {
    let navigate = useNavigate();

    const handleClick = () => {
        navigate('/exam-page')
    };

    return (
        <div>
            {/* <Button variant="outlined" onClick={handleClickOpen}>
                Open full-screen dialog
            </Button> */}
            <button onClick={handleClickOpen} className="btn btn-lg" style={{ backgroundColor: '#08bd80', fontWeight: '500' }} type="button">
                Join quiz
            </button>
            <Dialog
                fullScreen
                open={open}
                onClose={handleClose}
                TransitionComponent={Transition}
            >
                <AppBar sx={{ position: 'relative' }} color="inherit">
                    <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={handleClose} aria-label="close">
                            <CloseIcon />
                        </IconButton>
                        <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                            you've an ongoing quiz
                        </Typography>
                    </Toolbar>
                </AppBar>
                <br />
                <br />
                <section id="features" className="features">
                    <div className="container" data-aos="fade-up">
                        <div className="row">
                            <div className="col-lg-3 col-md-4">
                                <div className='quizJoinBoxSec1' style={{ borderRadius: '10px 10px 0px 0px' }}>
                                    <h1 style={{ textAlign: 'center', color: '#FFFFFF', fontWeight: "900", fontSize: '60px' }}>799030</h1>
                                    <h6 style={{ textAlign: 'center', color: '#FFFFFF', fontWeight: "600", }}>Invite learners to join with this Quiz ID</h6>
                                    <div className="d-grid gap-2 col-6 mx-auto">
                                        <div style={{ display: 'flex' }}>
                                            <button className="btn btn-primary" type="button"><i style={{ marginLeft: '10px', marginRight: '10px' }} className="bi bi-clipboard-check"></i>Copy</button>
                                            <button style={{ marginLeft: '10px' }} className="btn btn-primary" type="button"><i className="bi bi-share"></i></button>
                                        </div>
                                    </div>
                                    {/* <div style={{ display: 'flex', }}>
                                        <div style={{ flexDirection: 'column' }}>
                                            <p style={{ fontWeight: '500', color: 'gray', marginTop: '10px', fontFamily: 'Nunito' }}>Last quiz started</p>
                                            <h5 style={{ fontWeight: '900', fontFamily: 'Nunito', lineHeight: '1px' }}>2m 11s ago</h5>
                                        </div>
                                        <div style={{ flex: '1' }}></div>
                                        <div>
                                            <button style={{ marginTop: '30px', fontWeight: 'bold', backgroundColor: '#08bd80', color: '#FFFFFF', fontFamily: 'Nunito' }} type="button" class="btn  btn-sm">Join quiz</button>
                                        </div>
                                    </div> */}
                                </div>
                                <div className='quizJoinBoxSec2' style={{ backgroundColor: '#FFFFFF', borderRadius: '0px 0px 10px 10px' }}>
                                    <div>
                                        <div style={{ flexDirection: 'column', }}>
                                            <h6 style={{ fontWeight: '500', color: 'gray', fontFamily: 'Nunito' }}>Topic</h6>
                                            <h6 style={{ fontWeight: '900', fontFamily: 'Nunito' }}>General</h6>
                                        </div>
                                        <div style={{ display: 'flex' }}>
                                            <div>
                                                <p style={{ fontFamily: 'Nunito', lineHeight: '40px' }}>Questions</p>
                                                <h6 style={{ fontWeight: '700', fontFamily: 'Nunito', lineHeight: '5px' }}>50</h6>
                                            </div>
                                            <div style={{ flex: '1' }}></div>
                                            <div>
                                                <p style={{ fontFamily: 'Nunito', lineHeight: '40px' }}>Time per ques.</p>
                                                <h6 style={{ fontWeight: '700', fontFamily: 'Nunito', lineHeight: "5px" }}>60 sec</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                </section>
                <div style={{ margin: '10px' }} className="d-grid gap-2">
                    <button onClick={(e) => handleClick(e)} style={{ color: '#FFFFFF', fontWeight: '500', backgroundColor: 'blue' }} className="btn btn-lg" type="button">Start quiz</button>
                </div>
            </Dialog>
        </div>
    );
};

export default JoinQuize
