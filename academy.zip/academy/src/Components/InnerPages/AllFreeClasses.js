import React from 'react';
import { Link } from 'react-router-dom';
import Carousel from 'react-grid-carousel'

const AllFreeClasses = () => {
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/home"><i style={{ fontSize: '20px' }} className="bi bi-chevron-left"></i></Link>
                     {/* <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Practice</Link> */}
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
               <h3 style={{ color: '#000000', fontWeight: '900', fontSize: '28px' }}>Watch classes for free</h3>
               <p style={{ color: 'gray', }}>Classes by top educators for you</p>
            </div>
         </header>
         <br />
         <br />
         <br />
         <br />
         <br />
         <br />
         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <section id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Live Now</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px' }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={1} rows={1} gap={5} loop>
               <Carousel.Item>
                  <div className="freeClasses">
                     <div>
                        <div>
                           <div style={{ marginTop: '5px' }} className="h-100 p-1">
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'red', borderRadius: '5px', zIndex: '9' }}>
                                    <p style={{ margin: '4px', fontWeight: '700', color: '#FFFFFF', fontSize: '10px', fontFamily: 'Nunito' }}>• LIVE <i className="bi bi-eye"></i> 125</p>
                                 </div>
                                 <div style={{ flex: '1' }}></div>
                                 <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                    <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '20px 10px', lineHeight: '2px' }}>
                     <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>PRACTICE & STRATEGY</p>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div className="freeClasses">
                     <div>
                        <div>
                           <div style={{ marginTop: '5px' }} className="h-100 p-1">
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'red', borderRadius: '5px', zIndex: '9' }}>
                                    <p style={{ margin: '4px', fontWeight: '700', color: '#FFFFFF', fontSize: '10px', fontFamily: 'Nunito' }}>• LIVE <i className="bi bi-eye"></i> 125</p>
                                 </div>
                                 <div style={{ flex: '1' }}></div>
                                 <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                    <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '20px 10px', lineHeight: '2px' }}>
                     <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>PRACTICE & STRATEGY</p>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
            </Carousel>
         </div>

         <div style={{ backgroundColor: '#252525' }}>
            <section id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ fontFamily: 'Nunito', fontWeight: '700', color: '#FFFFFF' }}>Best classes of all time</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px', }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={1} rows={1} gap={5} loop>
               <Carousel.Item>
                  <div className="freeClasses">
                     <div>
                        <div>
                           <div style={{ marginTop: '5px' }} className="h-100 p-1">
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'red', borderRadius: '5px', zIndex: '9' }}>
                                    {/* <p style={{ margin: '4px', fontWeight: '700', color: '#FFFFFF', fontSize: '10px', fontFamily: 'Nunito' }}>• LIVE <i className="bi bi-eye"></i> 125</p> */}
                                 </div>
                                 <div style={{ flex: '1' }}></div>
                                 <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                    <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '20px 10px', lineHeight: '2px' }}>
                     <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>PRACTICE & STRATEGY</p>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito', color: '#FFFFFF' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div className="freeClasses">
                     <div>
                        <div>
                           <div style={{ marginTop: '5px' }} className="h-100 p-1">
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: 'red', borderRadius: '5px', zIndex: '9' }}>
                                    {/* <p style={{ margin: '4px', fontWeight: '700', color: '#FFFFFF', fontSize: '10px', fontFamily: 'Nunito' }}>• LIVE <i className="bi bi-eye"></i> 125</p> */}
                                 </div>
                                 <div style={{ flex: '1' }}></div>
                                 <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                    <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '20px 10px', lineHeight: '2px' }}>
                     <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>PRACTICE & STRATEGY</p>
                     <h5 style={{ fontWeight: '500', fontFamily: 'Nunito', color: '#FFFFFF' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                     <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                  </div>
               </Carousel.Item>
            </Carousel>
         </div>
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <section id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Popular subjects</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              {/* <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px' }} to="">SEE ALL</Link> */}
                              {/* <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i> */}
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={1} rows={1} gap={5} loop>
               <Carousel.Item>
                  <section id="features" className="features">
                     <div className="container" data-aos="fade-up">
                        <div className="row" data-aos="zoom-in" data-aos-delay="100">
                           <div className="col-lg-3 col-md-4">
                              <div className="icon-box" style={{ borderRadius: '10px' }}>
                                 <i className="ri-store-line" style={{ color: '#ffbb2c', }}></i>
                                 <h3><Link to="">History</Link></h3>
                              </div>
                           </div>
                           <div className="col-lg-3 col-md-4 mt-4 mt-md-0">
                              <div className="icon-box" style={{ borderRadius: '10px' }}>
                                 <i className="ri-bar-chart-box-line" style={{ color: '#5578ff' }}></i>
                                 <h3><Link to="">Geography</Link></h3>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
               </Carousel.Item>
               <Carousel.Item>
                  <section id="features" className="features">
                     <div className="container" data-aos="fade-up">
                        <div className="row" data-aos="zoom-in" data-aos-delay="100">
                           <div className="col-lg-3 col-md-4">
                              <div className="icon-box" style={{ borderRadius: '10px' }}>
                                 <i className="ri-store-line" style={{ color: '#ffbb2c', }}></i>
                                 <h3><Link to="">History</Link></h3>
                              </div>
                           </div>
                           <div className="col-lg-3 col-md-4 mt-4 mt-md-0">
                              <div className="icon-box" style={{ borderRadius: '10px' }}>
                                 <i className="ri-bar-chart-box-line" style={{ color: '#5578ff' }}></i>
                                 <h3><Link to="">Geography</Link></h3>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
               </Carousel.Item>
            </Carousel>
            <br />
            <br />
            <br />
         </div>

      </div>

   );
};

export default AllFreeClasses
