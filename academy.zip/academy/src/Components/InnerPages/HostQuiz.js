import React from 'react';
import { Link } from 'react-router-dom';

const HostQuiz = () => {
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   return (
      <div>
         <header style={{ backgroundColor: 'blue' }} className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     <Link to="/live-quiz"><i style={{ fontSize: '20px', color: '#FFFFFF' }} className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px', fontSize: '20px', color: '#FFFFFF' }} to="">Choose a topic</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <br />
         <div style={{ margin: '20px' }}>
            <section id="features" className="featuress">
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: 'coral' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#6495ED' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#8B008B' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#006400' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#2F4F4F' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#2F4F4F' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#2F4F4F' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#2F4F4F' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <div className="" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-3 col-md-4 mt-3">
                        <div className="icon-boxx" style={{ backgroundColor: '#FFFFFF', borderRadius: '10px', borderLeftWidth: '8px', borderLeftColor: '#2F4F4F' }}>
                           <div style={{ flexDirection: 'column' }}>
                              <h3 style={{ fontWeight: '900', fontSize: '15px' }}>Physics</h3>
                              <h6 style={{ color: 'gray', marginTop: '10px', fontSize: '13px' }}>5 Sub Topics</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                        </div>
                     </div>
                  </div>
               </div>
               <br />
            </section>
         </div >
      </div>
   );
};

export default HostQuiz
