import React from 'react'
import { Link, useNavigate } from 'react-router-dom';
import CameraAltSharp from '@mui/icons-material/CameraAltSharp';


const Doubt = () => {
   let navigate = useNavigate();
   const [imagePreview, setImagePreview] = React.useState("");
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const photoUpload = (event) => {
      let files = event.target.files;
      let reader = new FileReader();
      reader.readAsDataURL(files[0]);

      reader.onload = (e) => {
         setImagePreview(e.target.result)
         sessionStorage.setItem('setimagePreview', e.target.result);
         window.location.reload();
      }
   };


   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/home"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Doubts & solutions</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <div style={{ display: 'flex', alignItems: 'center', padding: '20px', transition: '0.3s', }} className="icon-box">
               <br />
               <div>
                  <h3 style={{ fontWeight: '700', color: '#000000', fontFamily: 'Nunito', fontSize: '20px', }}>Ask a new doubt</h3>
                  <h3 style={{ fontWeight: '500', color: 'gray', fontFamily: 'Nunito', fontSize: '15px', marginTop: '10px' }}>Submit a picture of your doubt & find solutions from top educators</h3>
               </div>
               <div style={{ flex: '1' }}></div>
               <img style={{ width: '30%' }} src="https://cdn.pixabay.com/photo/2014/04/10/17/59/doubt-321144_960_720.png" alt="" />
               <br />
            </div>
            <div style={{ margin: '10px' }} className="d-grid gap-2">
               <label style={{ fontWeight: '600' }} htmlFor="files" className="btn btn-primary btn-lg"><CameraAltSharp style={{ marginRight: '15px' }} />Click a picture</label>
               <input id="files" style={{ visibility: "hidden" }} type="file" onChange={(event) => photoUpload(event.target)} accept=".jpef, .png, .jpg" capture='environment' />
            </div>
         </div>
         <br />
         <br />
         <section style={{ backgroundColor: 'rgb(171 219 226 / 45%)', }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <br />
                        <div>
                           <h3 style={{ fontWeight: '700', color: '#000000', fontSize: '20px', fontFamily: 'Nunito', lineHeight: '20px' }}>Want a new solution from an educator?</h3>
                           <p style={{ fontWeight: '300', color: 'gray', fontSize: '13px', fontFamily: 'Nunito', lineHeight: '20px', marginTop: '10px' }}>With Veda Academy subscription, you can ask educators your unsolved doubts</p>{/*  get personalised guidance trhough 1:1 live mentorship and a lot */}
                           <Link to="/subscription" type="button" style={{ marginTop: '3px', backgroundColor: '#08bd80', color: '#FFFFFF', fontWeight: '500', fontFamily: 'Nunito', }} className="btn btn-lg">Get subscription</Link>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <img style={{ width: '30%' }} src="https://static.uacdn.net/production/_next/static/images/goal/iconic_1.png?q=75&w=256" alt="" />
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>


      </div>
   );
};

export default Doubt