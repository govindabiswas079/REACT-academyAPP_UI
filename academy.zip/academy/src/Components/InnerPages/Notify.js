import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Carousel from 'react-grid-carousel'

const Notify = () => {
   let navigate = useNavigate();
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const Subscription = () => {
      navigate('/subscription')
   };

   const livecalsses = () => {
      navigate('/notify-live-classes')
   };

   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/notification"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     {/* <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Notify</Link> */}
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <section style={{ marginTop: '30px' }} id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Recently started</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={2} rows={1} gap={1} loop>
               <Carousel.Item>
                  <div onClick={(e) => livecalsses(e)}>
                     <div className="container py-1">
                        <div className="Upcoming">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>5 DEC, 5:30 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                        <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                        <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                        <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                     </div>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div onClick={(e) => livecalsses(e)}>
                     <div className="container py-1">
                        <div className="Upcoming">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>5 DEC, 5:30 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                        <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                        <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                        <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                     </div>
                  </div>
               </Carousel.Item>
            </Carousel>


            <section style={{ marginTop: '30px' }} id="about" className="about">
               <div className="container" data-aos="fade-up">
                  <div className="row">
                     <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                        <div style={{ display: 'flex' }}>
                           <div>
                              <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Completed</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div>
                              <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                              <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <Carousel cols={2} rows={1} gap={1} loop>
               <Carousel.Item>
                  <div onClick={(e) => livecalsses(e)}>
                     <div className="container py-4">
                        <div className="Upcoming">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>Completed 8 DEC, 2:00 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                        <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                        <h4 style={{ fontWeight: '500', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                        <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                     </div>
                  </div>
               </Carousel.Item>
               <Carousel.Item>
                  <div onClick={(e) => livecalsses(e)}>
                     <div className="container py-4">
                        <div className="Upcoming">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>Completed 8 DEC, 2:00 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                        <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                        <h4 style={{ fontWeight: '500', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                        <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                     </div>
                  </div>
               </Carousel.Item>
            </Carousel>
            <br />
            <div style={{ margin: '0 10px' }} className="d-grid gap-2 d-md-block">
               <button style={{ fontWeight: '600', backgroundColor: '#08bd80', fontFamily: 'Nunito', color: '#FFFFFF' }} className="btn btn-lg" type="button" onClick={(e) => Subscription(e)}>Get subscription</button>
            </div>
            <br />
            <div style={{ justifyItems: 'center', }} className="d-grid gap-2 mx-auto">
               <div style={{ display: 'flex' }}>
                  <Link style={{ color: 'black', fontWeight: '900', fontFamily: 'Nunito', fontSize: '10px' }} to="/subscription-work">SEE HOW SUBSCRIPTION WORKS</Link>
                  <i style={{ marginLeft: '10px', fontSize: '10px' }} className="bi bi-chevron-compact-right"></i>
               </div>
            </div>
            <br />
         </div>
         <br />
      </div>
   );
};

export default Notify;
