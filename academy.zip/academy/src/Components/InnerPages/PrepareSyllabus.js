import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import SwipeableViews from 'react-swipeable-views';
import { useTheme } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { Schedule, Educators, Syllabus, About } from '../PrepareSyllabus/Index';

function TabPanel(props) {
   const { children, value, index, ...other } = props;

   return (
      <div
         role="tabpanel"
         hidden={value !== index}
         id={`full-width-tabpanel-${index}`}
         aria-labelledby={`full-width-tab-${index}`}
         {...other}
      >
         {value === index && (
            <Box sx={{ p: 3 }}>
               <Typography>{children}</Typography>
            </Box>
         )}
      </div>
   );
}

TabPanel.propTypes = {
   children: PropTypes.node,
   index: PropTypes.number.isRequired,
   value: PropTypes.number.isRequired,
};

function a11yProps(index) {
   return {
      id: `full-width-tab-${index}`,
      'aria-controls': `full-width-tabpanel-${index}`,
   };
}

const PrepareSyllabus = () => {
   let navigate = useNavigate();
   const [nav, setNav] = React.useState(false)
   const [tab, setTab] = React.useState(false)
   const theme = useTheme();
   const [value, setValue] = React.useState(0);

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const changeTabPosition = () => {
      if (window.scrollY >= 500) {
         setTab(true);
      } else {
         setTab(false);
      }
   }
   window.addEventListener('scroll', changeTabPosition);

   const handleChange = (event, newValue) => {
      setValue(newValue);
   };

   const handleChangeIndex = (index) => {
      setValue(index);
   };

   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: tab ? '10px' : '0px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/home"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     {/* <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Notify</Link> */}
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <br />
            <div style={{ margin: '0px 15px' }}>
               <div className="">{/* bgImg */}
                  <img src='	https://uk.rs-cdn.com/site_files/cache/9559/images…8e611313a3b7_4bd07e3c55a996b45bacfc40df329e9e.jpg' alt="" />
                  <div style={{ borderRadius: '10px' }} className="freeClasses">{/* onClick={(e) => livecalsses(e)} */}
                     <div>
                        <div>
                           <div className="h-100 p-1">
                              <div style={{ display: 'flex', }}>
                                 <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', margin: '5px 5px', display: 'flex', height: '23px', padding: '2px 5px 5px 5px', justifyContent: 'center' }}>{/* width: '70px', */}
                                    <i className="bi bi-play-fill" style={{ fontSize: '13px', fontWeight: '700', marginTop: '1px', marginRight: '4px' }}></i>
                                    <h5 style={{ fontSize: '13px', fontWeight: '900', marginTop: '3px' }}>PREVIEW</h5>
                                 </div>
                                 <div style={{ flex: '1' }}></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div style={{ margin: '20px 10px', lineHeight: '2px' }}>
                  <h5 style={{ fontWeight: '900', fontFamily: 'Nunito' }}>Expedition 2023: Batch Course for UPSC-CSE GS (English) - 15th December</h5>
               </div>
               <section style={{ margin: '0px 10px', }} id="about" className="about">
                  <div className="" data-aos="fade-up">
                     <div className="row">
                        <div className="col-lg-6 pt-lg-0 order-2 order-lg-1 content">{/* pt-4  */}
                           <ul style={{ textAlign: 'initial' }}>
                              <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'blue', }} className="bi bi-calendar-check-fill"></i> Starts in 4 days. 8 Dec 2021</li>
                              <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'yellow', }} className="bi bi-app-indicator"></i>Classes in English</li>
                              <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'green', }} className="bi bi-mortarboard-fill"></i> Anshuman Singh, Varun Pachauri</li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </section>
            </div>
            {/* <div>
               <Tabs
                  value={value}
                  onChange={handleChange}
                  indicatorColor="secondary"
                  textColor="inherit"
                  aria-label="full width tabs example"
               >
                  <Tab style={{ fontWeight: '700' }} label="Schedule" {...a11yProps(0)} />
                  <Tab style={{ fontWeight: '700' }} label="Educators" {...a11yProps(1)} />
                  <Tab style={{ fontWeight: '700' }} label="Syllabus" {...a11yProps(2)} />
                  <Tab style={{ fontWeight: '700' }} label="About" {...a11yProps(3)} />
               </Tabs>
            </div> */}
         </div>
         <Box sx={{ bgcolor: 'background.paper', }}>
            <div className={tab ? "tabPosition tabActive" : "tabPosition"} >
               <Tabs
                  value={value}
                  onChange={handleChange}
                  indicatorColor="secondary"
                  textColor="inherit"
                  aria-label="full width tabs example"
               >
                  <Tab style={{ fontWeight: '700' }} label="Schedule" {...a11yProps(0)} />
                  <Tab style={{ fontWeight: '700' }} label="Educators" {...a11yProps(1)} />
                  <Tab style={{ fontWeight: '700' }} label="Syllabus" {...a11yProps(2)} />
                  <Tab style={{ fontWeight: '700' }} label="About" {...a11yProps(3)} />
               </Tabs>
            </div>
            <SwipeableViews
               axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
               index={value}
               onChangeIndex={handleChangeIndex}
            >
               <div style={{ marginTop: tab ? "140px" : '0px' }} value={value} index={0} dir={theme.direction}>
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <Schedule />
                  </div>
               </div>
               <div style={{ marginTop: tab ? "140px" : '0px' }} value={value} index={1} dir={theme.direction}>
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <Educators />
                  </div>
               </div>
               <div style={{ marginTop: tab ? "140px" : '0px' }} value={value} index={2} dir={theme.direction}>
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <Syllabus />
                  </div>
               </div>
               <div style={{ marginTop: tab ? "140px" : '0px' }} value={value} index={3} dir={theme.direction}>
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <About />
                  </div>
               </div>
            </SwipeableViews>
         </Box>
      </div>
   );
};

export default PrepareSyllabus
