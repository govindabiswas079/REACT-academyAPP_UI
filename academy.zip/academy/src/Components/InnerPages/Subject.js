import React from 'react';
import { Link } from 'react-router-dom';

const Subject = () => {
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   return (
      <div>
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/syllabus"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Subject</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <br />
         <br />
         <section id="features" className="features">
            <div className="container" data-aos="fade-up" style={{ backgroundColor: '#FFFFFF' }}>
               <br />
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box" style={{ borderRadius: '10px 10px 0px 0px' }}>
                        <div>
                           <h3 style={{ fontWeight: '700', fontSize: '15px' }}>Modern History</h3>
                           <p style={{ fontSize: '15px', color: 'coral', marginTop: '4px', fontWeight: '600' }}>4 Course starting today</p>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-chevron-right" style={{ color: '#000000', fontSize: '18px' }}></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-md-0">
                     <div className="icon-box">
                        <div>
                           <h3 style={{ fontWeight: '700', fontSize: '15px' }}>Ancient History</h3>
                           <p style={{ fontSize: '15px', color: 'coral', marginTop: '4px', fontWeight: '600' }}>1 Course starting today</p>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-chevron-right" style={{ color: '#000000', fontSize: '18px' }}></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-md-0">
                     <div className="icon-box">
                        <div>
                           <h3 style={{ fontWeight: '700', fontSize: '15px' }}>Practice & Strategy</h3>
                           <p style={{ fontSize: '15px', color: 'coral', marginTop: '4px', fontWeight: '600' }}>1 Course starting today</p>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-chevron-right" style={{ color: '#000000', fontSize: '18px' }}></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-lg-0">
                     <div className="icon-box">
                        <h3 style={{ fontWeight: '700', fontSize: '15px' }}>Mediaval History</h3>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-chevron-right" style={{ color: "#000000", fontSize: '18px' }}></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-lg-0">
                     <div className="icon-box">
                        <h3 style={{ fontWeight: '700', fontSize: '15px' }}>World History</h3>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-chevron-right" style={{ color: "#000000", fontSize: '18px' }}></i>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-lg-0">
                     <div className="icon-box" style={{ borderRadius: '0px 0px 10px 10px' }}>
                        <div>
                           <h3 style={{ fontWeight: '700', fontSize: '15px' }}>Post-Independence History</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i className="bi bi-chevron-right" style={{ color: "#000000", fontSize: '18px' }}></i>
                     </div>
                  </div>
               </div>
               <br />
            </div>
         </section>
         <section id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <br />
                        <div>
                           <h5 style={{ color: 'coral', fontWeight: '900' }}>12+ courses</h5>
                           <h5 style={{ color: '#000000', fontWeight: '900' }}>starting this month</h5>
                           <h6 style={{ color: 'gray', fontWeight: '500' }}>in History</h6>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <img style={{ width: '30%' }} src="https://www.eurolaser.com/fileadmin/eurolaser/Service/EUROLASER-ACADEMY---Advance-training-in-laser-technology-topics.png" alt="" />
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>

         <br />
         <div style={{ margin: '0 10px' }} className="d-grid gap-2 d-md-block">
            <button style={{ fontWeight: '700', backgroundColor: '#08bd80', fontFamily: 'Nunito', color: '#FFFFFF', fontSize: '15px' }} className="btn btn-lg" type="button">Get subscription</button>
         </div>
         <br />
         <br />
      </div>
   );
};

export default Subject
