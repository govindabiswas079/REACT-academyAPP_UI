import React from 'react';
import PropTypes from 'prop-types';
import SwipeableViews from 'react-swipeable-views';
import { useTheme } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { Link, useNavigate } from 'react-router-dom';
import { Batches, Courses, Educators } from '../CoursesBatches/Index';

function TabPanel(props) {
   const { children, value, index, ...other } = props;

   return (
      <div
         role="tabpanel"
         hidden={value !== index}
         id={`full-width-tabpanel-${index}`}
         aria-labelledby={`full-width-tab-${index}`}
         {...other}
      >
         {value === index && (
            <Box sx={{ p: 3 }}>
               <Typography>{children}</Typography>
            </Box>
         )}
      </div>
   );
}

TabPanel.propTypes = {
   children: PropTypes.node,
   index: PropTypes.number.isRequired,
   value: PropTypes.number.isRequired,
};

function a11yProps(index) {
   return {
      id: `full-width-tab-${index}`,
      'aria-controls': `full-width-tabpanel-${index}`,
   };
}

export default function CoursesBatches() {
   const theme = useTheme();
   const [value, setValue] = React.useState(0);

   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const handleChange = (event, newValue) => {
      setValue(newValue);
   };

   const handleChangeIndex = (index) => {
      setValue(index);
   };

   return (
      <div >{/* style={{ backgroundColor: 'rgba(229, 232, 235, 0.336)' }} */}
         <header className={nav ? "header active" : "header"}>{/* style={{ position: 'relative' }} */}
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                     <Link to="/self-study"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                     <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Courses Batches</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
               <div>
                  <Tabs
                     value={value}
                     onChange={handleChange}
                     indicatorColor="secondary"
                     textColor="inherit"
                     aria-label="full width tabs example"
                  >
                     <Tab style={{ fontWeight: '700' }} label="Courses" {...a11yProps(0)} />
                     <Tab style={{ fontWeight: '700' }} label="Batches" {...a11yProps(1)} />
                     <Tab style={{ fontWeight: '700' }} label="Educators" {...a11yProps(2)} />
                  </Tabs>
               </div>
            </div>
         </header>{/* style={{ position: 'fixed', zIndex: '5', backgroundColor: '#FFFFFF', width: '100%' }} */}

         <Box sx={{ bgcolor: 'background.paper', }}>{/* width: 500 */}
            <AppBar color="inherit" position="static" >{/* position="static" */}
               <Tabs
                  value={value}
                  onChange={handleChange}
                  indicatorColor="secondary"
                  textColor="inherit"
                  //variant="fullWidth"
                  aria-label="full width tabs example"
               >
                  <Tab style={{ fontWeight: '700' }} label="Courses" {...a11yProps(0)} />
                  <Tab style={{ fontWeight: '700' }} label="Batches" {...a11yProps(1)} />
                  <Tab style={{ fontWeight: '700' }} label="Educators" {...a11yProps(2)} />
               </Tabs>
            </AppBar>
            <br />
            <br />
            <br />
            <SwipeableViews
               axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
               index={value}
               onChangeIndex={handleChangeIndex}
            >
               <div style={{ marginTop: "20px" }} value={value} index={0} dir={theme.direction}>
                  <Courses />
               </div>
               <div style={{ marginTop: "0px" }} value={value} index={1} dir={theme.direction}>
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <Batches title={'Upcoming batches'} />
                  </div>
                  <br />
                  <div style={{ backgroundColor: '#FFFFFF' }}>
                     <Batches title={'Ongoing batches'} />
                  </div>

               </div>
               <div style={{ marginTop: "20px" }} value={value} index={2} dir={theme.direction}>
                  <Educators />
               </div>
            </SwipeableViews>
         </Box>
      </div>
   );
}
