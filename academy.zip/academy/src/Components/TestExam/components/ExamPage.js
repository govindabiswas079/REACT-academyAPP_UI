import React, { useState, useEffect } from 'react';
import '../styles/ExamPage.css';
import { Questions } from '../Question/Questions';
import { useNavigate } from 'react-router-dom';
import swal from 'sweetalert';
import { Link } from 'react-router-dom';

const ExamPage = (props) => {
    const [show, setShow] = useState(false);
    const [textShow, setTextShow] = useState(false);
    const handleShow = () => setShow(true);
    const handlehide = () => setShow(false);

    const { initialMinute = 29, initialSeconds = 60 } = props;
    const [minutes, setMinutes] = useState(initialMinute);
    const [seconds, setSeconds] = useState(initialSeconds);

    let navigate = useNavigate();
    const [value, setValue] = useState({
        Mobile: ''
    });
    const [deafultset, setDefaultSet] = useState();
    const [mobile, setMobile] = useState(false);
    const [disable, setDisable] = useState(true);
    const [nextQueDisable, setNextQueDisable] = useState(true);
    const [nextDisable, setNextDisable] = useState(false);
    const [Answerdisable, setAnswerdisable] = useState(false);
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [showScore, setShowScore] = useState(false);
    const [score, setScore] = useState(0);
    const [selected, setSelected] = useState();
    const [skipCount, setSkipCount] = useState(0);
    const [attempCount, setAttempCount] = useState(0);
    const [negativeMark, setNegativeMark] = useState(0);

    const [nav, setNav] = React.useState(false)

    const changeBackground = () => {
        if (window.scrollY >= 50) {
            setNav(true);
        } else {
            setNav(false);
        }
    }
    window.addEventListener('scroll', changeBackground);
    sessionStorage.setItem('result', score);

    const attempQue = sessionStorage.getItem('attempQue');
    const negative = sessionStorage.getItem('negativeMark');
    const skipQue = sessionStorage.getItem('skipQue');


    const userData = sessionStorage.getItem('userData')
    let jsonObject = JSON.parse(userData);

    const handleSelect = (i) => {
        sessionStorage.setItem('selected', selected);
        if (selected === i) return "select";
        else if (selected === i) return "select";
    };

    useEffect(() => {
        let myInterval = setInterval(() => {
            if (seconds > 0) {
                setSeconds(seconds - 1);
            }
            if (seconds === 0) {
                if (minutes === 0) {
                    clearInterval(myInterval)
                    handleShow(true)
                } else {
                    setMinutes(minutes - 1);
                    setSeconds(59);
                }
            }
        }, 1000)
        return () => {
            clearInterval(myInterval);
        };
    });

    const onChangeMobile = (e) => {
        const re = /^[0-9\b]/;
        if (e.target.value.trim().length >= 0) {
            if (e.target.value === '' || re.test(e.target.value)) {
                setValue({ ...value, Mobile: e.target.value });
            }
            setMobile(false);
        } else {
            if (e.target.value === '' || re.test(e.target.value)) {
                setValue({ ...value, Mobile: e.target.value });
            }
        };
    };


    const handleAnswerOptionClick = (isCorrect, i) => {
        setNextQueDisable(false)
        handleSelect()
        setSelected(i);
        setDisable(false)
        if (isCorrect) {
            setScore(score + 1);
        } else {
            /* setScore(score - 1);
            setNegativeMark(negativeMark + 1)
            sessionStorage.setItem("negativeMark", negativeMark + 1) */
        }
        /* const disableNo = sessionStorage.getItem('selected')
        setDefaultSet(disableNo);
        console.log(deafultset) */
    };
    const nextQue = () => {
        setSelected();
        const nextQuestion = currentQuestion + 1;
        setAnswerdisable(true)
        if (nextQuestion < Questions.length) {
            setAnswerdisable(false)
            setCurrentQuestion(nextQuestion);
            setAttempCount(attempCount + 1);
            sessionStorage.setItem("attempQue", attempCount + 1);
            setNextQueDisable(true)
        } else {
            setShowScore(false);

        }
    }

    React.useEffect(() => {
        if (currentQuestion == 0) {
            setDisable(true)
        } else {
            setDisable(false)
        }
    })

    React.useEffect(() => {
        if (currentQuestion == 50) {
            setTextShow(true)
        } else {
            setTextShow(false)
        }
    })

    React.useEffect(() => {
        if (currentQuestion == 50) {
            setNextDisable(true)
        } else {
            setNextDisable(false)
        }
    })

    const checkStringNullEmpty = (str) => {
        if (str != null && str !== '') {
            return false;
        } else {
            return true;
        };
    };

    var validation = '';
    const validatee = () => {
        if (checkStringNullEmpty(value.Mobile)) {
            validation += '<li>Enter Your Confrim Password</li>';
            setMobile(true)
        }
        if (validation !== '') {
            return null;
        }
        else {

        };
    };

    const mobileNumber = jsonObject.Mobile;
    const countryCode = mobileNumber.length - 10;
    const IDDCC = mobileNumber.substr(0, countryCode);
    const NN = mobileNumber.substr(countryCode, mobileNumber.length);

    const handleEndClick = () => {
        validatee()
        if (validation === '') {
            if (jsonObject.Mobile == `${IDDCC}${value.Mobile}`) {
                window.location.replace('/result')
                // setShowScore(true);
            } else {
                // setShowScore(false);
                swal("wrong number")
            }
        } else {
            return null;
        }
    }

    const handleNextClick = () => {
        setAnswerdisable(false)
        const nextQuestion = currentQuestion + 1;
        setSkipCount(skipCount + 1)
        if (nextQuestion < Questions.length) {
            setCurrentQuestion(nextQuestion);
            setSelected();
            sessionStorage.setItem('skipQue', skipCount + 1)
        } else {
            setShowScore(false);

        };
    };



    const handleBackClick = () => {
        /*
        const disableNo = sessionStorage.getItem('selected')
            setDefaultSet(disableNo);
            console.log(deafultset) 
         */

        setAnswerdisable(true)
        const nextQuestion = currentQuestion - 1;
        if (nextQuestion < Questions.length) {
            setCurrentQuestion(nextQuestion);
        } else {
            setShowScore(false);
        };
    };

    const livequiz = () => {
        sessionStorage.removeItem("attempQue")
        sessionStorage.removeItem("result")
        // sessionStorage.removeItem("userData")
        sessionStorage.removeItem("skipQue")
        sessionStorage.removeItem("negativeMark")
        window.location.replace('/live-quiz')
    }

    return (
        <>
            <header className={nav ? "header active" : "header"}>
                <div style={{ marginTop: '10px' }} className="container">
                    <div style={{ display: 'flex' }} className="header-main">
                        <div className="logo2">
                            {/* <Link to="/self-study"><i className="bi bi-chevron-right"></i></Link> */}
                            <Link onClick={(e) => livequiz(e)} to="/live-quiz"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                            <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Quiz</Link>
                        </div>
                        <div style={{ flex: '1' }}></div>
                    </div>
                </div>
            </header>
            <br />
            <br />
            {/* <div style={{ marginTop: '0px', backgroundColor: '#5fcf80' }} className="cards" >
                <div style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '20px', color: '#000000' }} className="card-header">
                    Student Info:
                </div>
                <ul className="list-group list-group-flush">
                    <li style={{ fontFamily: 'Nunito', fontWeight: '600', backgroundColor: '#4fcf60', color: '#FFFFFF' }} className="list-group-item"><span style={{ fontFamily: 'Nunito', fontWeight: 'bold' }}>Name:</span> {jsonObject.Name}</li>
                    <li style={{ fontFamily: 'Nunito', fontWeight: '600', backgroundColor: '#4fcf60', color: '#FFFFFF' }} className="list-group-item"><span style={{ fontFamily: 'Nunito', fontWeight: 'bold' }}>Mobile:</span> {NN}</li>
                    <li style={{ fontFamily: 'Nunito', fontWeight: '600', backgroundColor: '#4fcf60', color: '#FFFFFF' }} className="list-group-item"><span style={{ fontFamily: 'Nunito', fontWeight: 'bold' }}>Date:</span> {(new Date(jsonObject.currentDate)).toLocaleDateString()}</li>
                </ul>
            </div> */}
            <div style={{ backgroundColor: '#FFFFFF' }} className="container py-4">
                {showScore ? (
                    <div >
                    </div>
                ) : (
                    <>
                        <main>
                            <div className="container py-4">
                                <header className="pb-3 mb-4 border-bottom">
                                    <div className="d-flex align-items-center text-dark text-decoration-none">

                                        <span style={{ fontFamily: 'Nunito', fontWeight: 'bold' }} className="fs-4">Question No. {textShow ?
                                            <span style={{ fontFamily: 'Nunito', fontWeight: 'bold' }} className="fs-4">50</span>
                                            : currentQuestion + 1}</span>/{Questions.length - 1}
                                        <div style={{ flex: '1' }}></div>
                                        <div>
                                            {minutes === 0 && seconds === 0
                                                ? <h5 style={{ fontFamily: 'Nunito', color: 'red' }}>Time Off</h5>
                                                : <h5 style={{ fontFamily: 'Nunito', color: 'green' }}>Time: {minutes}:{seconds < 10 ? `0${seconds}` : seconds}</h5>
                                            }
                                        </div>

                                    </div>
                                </header>

                                <div className="row align-items-md-stretch" style={{ backgroundClip: '#FFFFFF' }}>
                                    <div className="col-md-6" style={{ backgroundClip: '#FFFFFF' }}>
                                        <div style={{ backgroundClip: '#FFFFFF' }} className="h-98 p-2  border rounded-3">{/* bg-light */}
                                            {textShow ? <h3 style={{ fontFamily: 'Nunito', color: 'green' }}>Your quiz is Completed, Please End The quiz</h3> : <h2 style={{ fontFamily: 'Nunito', fontWeight: '900' }}> {currentQuestion + 1}. {Questions[currentQuestion].questionText}</h2>}
                                            {Questions[currentQuestion].answerOptions.map((answerOption, i) => (
                                                <>{/*   */}
                                                    <button style={{ marginTop: '15px', color: 'black', fontFamily: 'Nunito', }} className={`button ${selected && handleSelect(i)}`} disabled={Answerdisable} onClick={() => handleAnswerOptionClick(answerOption.isCorrect, i)} key={i}>{i + 1}. {answerOption.answerText}</button>

                                                </>
                                            ))}
                                            <div className={textShow ? "d-grid gap-2" : "d-flex gap-2"}>
                                                <button onClick={(e) => handleShow(e)} style={{ marginTop: '25px', color: 'black', fontFamily: 'Nunito' }} type="button" className="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                                    End quiz
                                                </button>
                                                <div style={{ flex: '1' }}></div>
                                                {textShow ? null :
                                                    <button onClick={(e) => nextQue(e)} style={{ marginTop: '25px', color: 'black', fontFamily: 'Nunito' }} type="button" disabled={nextQueDisable} className="btn btn-success btn-sm">
                                                        Next quiz
                                                    </button>}
                                            </div>

                                            <div className={show ? "modal fade show" : "modal fade"} id="exampleModal" style={{ display: show ? "block" : "none" }} tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div className="modal-dialog">
                                                    <div className="modal-content">
                                                        <div className="modal-header">
                                                            <h5 style={{ fontFamily: 'Nunito' }} className="modal-title" id="exampleModalLabel">Are you sure</h5>
                                                            <button type="button" onClick={(e) => handlehide(e)} className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div className="modal-body">
                                                            <div className="form-row">
                                                                <div style={{ margin: '0 5px' }} className="form-group col">
                                                                    <label>Enter Mobile Number: </label>
                                                                    <input type="text" name="Name" maxLength="10" value={value.Mobile} onChange={(e) => onChangeMobile(e)} className={mobile ? "form-control is-invalid" : "form-control"} />
                                                                    <div className="invalid-feedback">
                                                                        {mobile ? <div>Mobile is required</div> : ''}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="modal-footer">
                                                            <button type="button" className="btn btn-secondary" onClick={(e) => handlehide(e)} data-bs-dismiss="modal">Close</button>
                                                            <button type="button" className="btn btn-primary" onClick={(e) => handleEndClick(e)}>End quiz</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div style={{ marginTop: '21px', padding: '0px 30px' }}>
                                                <ul>
                                                    <li style={{ color: '#2E8B57', fontFamily: 'Nunito', fontSize: '20px', listStyle: 'decimal' }}>Attempt quiz</li>
                                                    <li style={{ color: '#FF4500', fontFamily: 'Nunito', fontSize: '20px', listStyle: 'decimal' }}>Skip quiz</li>
                                                    {/* <li style={{ color: 'red', fontFamily: 'Nunito', fontSize: '20px', listStyle: 'decimal' }}>Negative Mark</li> */}
                                                </ul>
                                            </div>
                                            <div style={{ display: 'flex', marginTop: '20px' }}>
                                                <div style={{ backgroundColor: '#2E8B57', width: '40px', height: '40px', borderRadius: '10px' }}>
                                                    <h5 style={{ color: '#FFFFFF', fontFamily: 'Nunito', textAlign: 'center', marginTop: '5px', fontSize: '25px' }}>
                                                        {attempQue ? attempQue : 0}
                                                    </h5>
                                                </div>
                                                <div style={{ marginLeft: '15px', backgroundColor: '#FF4500', width: '40px', height: '40px', borderRadius: '10px' }}>
                                                    <h5 style={{ fontFamily: 'Nunito', textAlign: 'center', marginTop: '5px', color: '#FFFFFF', fontSize: '25px' }}>
                                                        {skipQue ? skipQue : 0}
                                                    </h5>
                                                </div>
                                                {/* <div style={{ marginLeft: '15px', backgroundColor: 'red', width: '40px', height: '40px', borderRadius: '10px' }}>
                                                    <h5 style={{ fontFamily: 'Nunito', textAlign: 'center', marginTop: '5px', color: '#FFFFFF', fontSize: '25px' }}>
                                                        {negative ? negative : 0}
                                                    </h5>
                                                </div> */}
                                            </div>

                                            <div className="d-grid gap-2 mt-2">
                                                <button type="button" className="btn btn-info" onClick={(e) => handleNextClick(e)} disabled={nextDisable} >Skip<i style={{ margin: '5px' }} className="bi bi-arrow-right-circle"></i></button>
                                            </div>
                                        </div>
                                        <div style={{ display: 'flex', marginTop: '5px' }}>
                                            {/* <button type="button" disabled={disable} className="btn btn-primary btn-sm" onClick={(e) => handleBackClick(e)}><i style={{ margin: '5px' }} className="bi bi-arrow-left-circle"></i>Back</button> */}
                                            <div style={{ flex: '1', margin: '10px' }}></div>
                                            {/* <button type="button" className="btn btn-success btn-sm" onClick={(e) => handleNextClick(e)} disabled={nextDisable} >Skip<i style={{ margin: '5px' }} className="bi bi-arrow-right-circle"></i></button> */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </main>
                    </>
                )}
            </div>

        </>
    );
};

export default ExamPage






















/* <main>
                <div class="container py-4">
                    <header class="pb-3 mb-4 border-bottom">
                        <a href="/" class="d-flex align-items-center text-dark text-decoration-none">
                            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="32" class="me-2" viewBox="0 0 118 94" role="img"><title>Bootstrap</title><path fill-rule="evenodd" clip-rule="evenodd" d="M24.509 0c-6.733 0-11.715 5.893-11.492 12.284.214 6.14-.064 14.092-2.066 20.577C8.943 39.365 5.547 43.485 0 44.014v5.972c5.547.529 8.943 4.649 10.951 11.153 2.002 6.485 2.28 14.437 2.066 20.577C12.794 88.106 17.776 94 24.51 94H93.5c6.733 0 11.714-5.893 11.491-12.284-.214-6.14.064-14.092 2.066-20.577 2.009-6.504 5.396-10.624 10.943-11.153v-5.972c-5.547-.529-8.934-4.649-10.943-11.153-2.002-6.484-2.28-14.437-2.066-20.577C105.214 5.894 100.233 0 93.5 0H24.508zM80 57.863C80 66.663 73.436 72 62.543 72H44a2 2 0 01-2-2V24a2 2 0 012-2h18.437c9.083 0 15.044 4.92 15.044 12.474 0 5.302-4.01 10.049-9.119 10.88v.277C75.317 46.394 80 51.21 80 57.863zM60.521 28.34H49.948v14.934h8.905c6.884 0 10.68-2.772 10.68-7.727 0-4.643-3.264-7.207-9.012-7.207zM49.948 49.2v16.458H60.91c7.167 0 10.964-2.876 10.964-8.281 0-5.406-3.903-8.178-11.425-8.178H49.948z" fill="currentColor"></path></svg>
                            <span class="fs-4">Question No. {currentQuestion + 1}</span>/{questions.length}
                        </a>
                    </header>

                    <div class="row align-items-md-stretch">
                        <div class="col-md-6">
                            <div class="h-100 p-5 bg-light border rounded-3">
                                <h2>{currentQuestion + 1}. {questions[currentQuestion].questionText}</h2>
                                {questions[currentQuestion].answerOptions.map((answerOption) => (
                                    <>
                                        <button onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
                                    </>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </main> */