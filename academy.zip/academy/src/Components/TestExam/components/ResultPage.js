import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/ResultPage.css';

const ResultPage = () => {
    let Navigate = useNavigate()
    const result = sessionStorage.getItem('result')
    const NegativeMark = sessionStorage.getItem('negativeMark')

    const userData = sessionStorage.getItem('userData')
    let jsonObject = JSON.parse(userData);

    const onClickBack = () => {
        sessionStorage.removeItem("attempQue")
        sessionStorage.removeItem("result")
        // sessionStorage.removeItem("userData")
        sessionStorage.removeItem("skipQue")
        sessionStorage.removeItem("negativeMark")
        Navigate('/home')
    }

    return (
        <div>
            <br />
            <div className="text-center">
                <main style={{ margin: '0px 20px' }} className="form-signin">
                    <form >
                        <h1 style={{ fontFamily: 'Nunito', fontSize: '30px', fontWeight: '900', color: 'blue' }} >Result Hostig</h1>
                        <div style={{ backgroundColor: "#00000075" }}>
                            <h5 style={{ fontFamily: 'Nunito', color: "#FFFFFF" }} >Online web platform To Host Exam Result Online</h5>
                        </div>
                        <h1 style={{ fontFamily: 'Nunito', fontSize: '30px', fontWeight: '900' }} >Veda Academy</h1>
                        <h6 style={{ fontFamily: 'Nunito', fontWeight: '900' }} >
                            Affiliated to CBSE, Affiliation No. ABGYJ079.
                            A108 Adam Street
                            New York, NY 535022
                            United States
                        </h6>
                        <h1 style={{ marginTop: '30px', fontFamily: 'Nunito' }} className="h3 mb-3 fw-normal">Session 2020-2021</h1>
                    </form>
                </main>
            </div>

            <section id="why-us" className="why-us">
                <div className="container" data-aos="fade-up">
                    <div className="row">
                        <div className="col-lg-8  align-items-stretch" data-aos="zoom-in" data-aos-delay="100">{/* d-flex */}
                            <div className="icon-boxes  flex-column justify-content-center">{/* d-flex */}
                                <div className="row">
                                    <div className="col-xl-4  align-items-stretch">{/* d-flex */}
                                        <div className=" resultbox">
                                            <h2 style={{ fontFamily: 'Nunito', fontWeight: 'bold', color: '#000000', fontSize: '30px', margin: '5px' }}>Student Info: </h2>
                                            <div style={{ width: '100%', height: '2px', backgroundColor: '#000000' }}></div>
                                            <div style={{ display: 'flex', margin: '7px', fontFamily: 'Nunito', }}>
                                                <h5 style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Name: </h5>{" "}
                                                <h5 style={{ marginLeft: '7px', fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>{jsonObject.Name}</h5>
                                                <div style={{ flex: 1 }}></div>
                                                <h5 style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: 'red' }}>Roll No: </h5>
                                                <h5 style={{ marginLeft: '7px', fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px', color: 'red' }}>1234</h5>
                                            </div>
                                            <div style={{ display: 'flex', margin: '7px', fontFamily: 'Nunito', }}>
                                                <h5 style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Email: </h5>{" "}
                                                <h5 style={{ marginLeft: '7px', fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>{jsonObject.Email}</h5>
                                            </div>

                                            <div style={{ display: 'flex', margin: '7px', fontFamily: 'Nunito', }}>
                                                <h5 style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Mobile: </h5>{" "}
                                                <h5 style={{ marginLeft: '7px', fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>+{jsonObject.Mobile}</h5>
                                            </div>

                                            <div style={{ display: 'flex', margin: '7px', fontFamily: 'Nunito', }}>
                                                <h5 style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>User name: </h5>{" "}
                                                <h5 style={{ marginLeft: '7px', fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>{jsonObject.username}</h5>
                                            </div>

                                            <div style={{ display: 'flex', margin: '7px' }}>
                                                <h5 style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Addmission No: </h5>{" "}
                                                <h5 style={{ marginLeft: '7px', fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>1234</h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xl-4  align-items-stretch">{/* d-flex */}
                                        <div className=" resultbox">
                                            <table className="table ">
                                                <thead>
                                                    <tr>
                                                        <th scope="col" style={{ fontFamily: 'Nunito', fontWeight: 'bold', color: '#000000', fontSize: '30px' }}>Exam Info :</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Exam Date:</td>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>{(new Date(jsonObject.currentDate)).toLocaleDateString()}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Exam Time:</td>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>{(new Date(jsonObject.currentDate)).toLocaleTimeString()}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Exam Time Duration:</td>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>30 MIN</td>
                                                    </tr>
                                                    <tr>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Exam Mode:</td>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>{jsonObject.examMode}</td>
                                                    </tr>
                                                    <tr>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Score Result:</td>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>{result}/50</td>
                                                    </tr>
                                                    {/* <tr>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '22px', color: '#000000' }}>Negative Mark:</td>
                                                        <td style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '18px' }}>{NegativeMark ? NegativeMark : 0}/50</td>
                                                    </tr> */}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <br />
            <button style={{ flex: '1', marginLeft: '10px' }} type="button" className="btn btn-success" onClick={(e) => onClickBack(e)}>Back To Home<i style={{ margin: '5px' }} className="bi bi-arrow-right-circle"></i></button>
            <br />
            <br />
        </div>
    );
};

export default ResultPage
/* <Link style={{ flex: '1', marginLeft: '10px' }} type="button" className="btn btn-success" to="/">Back To Home<i style={{ margin: '5px' }} className="bi bi-arrow-right-circle"></i></Link> */