import React from 'react';
import { Link } from 'react-router-dom';

const ExamPreview = () => {
   const userData = sessionStorage.getItem('userData')
   let jsonObject = JSON.parse(userData);
   const skipQue = sessionStorage.getItem('skipQue');
   const attempQue = sessionStorage.getItem('attempQue');
   return (
      <div>
         <div style={{ marginTop: '0px', backgroundColor: '#5fcf80' }} className="cards" >
            <div style={{ fontFamily: 'Nunito', fontWeight: 'bold', fontSize: '20px', color: '#000000' }} className="card-header">
               Student INfo:
            </div>
            <ul className="list-group list-group-flush">
               <li style={{ fontFamily: 'Nunito', fontWeight: '300', backgroundColor: '#4fcf60', color: '#FFFFFF' }} className="list-group-item"><span style={{ fontFamily: 'Nunito', fontWeight: 'bold' }}>Name:</span> {jsonObject.Name}</li>
               <li style={{ fontFamily: 'Nunito', fontWeight: '300', backgroundColor: '#4fcf60', color: '#FFFFFF' }} className="list-group-item"><span style={{ fontFamily: 'Nunito', fontWeight: 'bold' }}>Email:</span> {jsonObject.Email}</li>
               <li style={{ fontFamily: 'Nunito', fontWeight: '300', backgroundColor: '#4fcf60', color: '#FFFFFF' }} className="list-group-item"><span style={{ fontFamily: 'Nunito', fontWeight: 'bold' }}>Date:</span> {(new Date(jsonObject.currentDate)).toLocaleDateString()}</li>
            </ul>
         </div>
         <div style={{ margin: '30px 10px' }}>
            <p style={{ fontFamily: 'Nunito', fontWeight: '900', fontSize: '19px', color: 'green' }}>you have successfully completed the test exam.</p>
            <h4 style={{ fontFamily: 'Nunito', fontWeight: '900', fontSize: '25px', color: "blue" }}>You have a {attempQue ? attempQue : 0} Question Attempt.</h4>
            <h4 style={{ fontFamily: 'Nunito', fontWeight: '900', fontSize: '25px', color: "red" }}>You have a {skipQue ? skipQue : 0} Question Skip.</h4>
            <Link style={{ flex: '1', marginLeft: '10px', marginTop: '25px' }} type="button" className="btn btn-success" to="/result">See Your Result<i style={{ margin: '5px' }} className="bi bi-arrow-right-circle"></i></Link>
            {/* You scored {score} out of {Questions.length} */}
         </div>
         <br />
         <br />
         <br />
         <br />
         <br />
         <br />
      </div>
   );
};

export default ExamPreview;
