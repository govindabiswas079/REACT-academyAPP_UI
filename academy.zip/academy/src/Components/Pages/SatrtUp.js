import React from 'react';
import { Link } from 'react-router-dom';

const SatrtUp = () => {
    return (
        <div style={{ backgroundColor: '#7f53ac', height: '100vh', backgroundImage: 'linear-gradient(315deg, #7f53ac 0%, #647dee 74%)' }}>
            <img style={{ width: '100%' }} src="https://static.uacdn.net/production/_next/static/images/home/k12-learning.svg?q=75&w=640" alt="" />

            <div style={{ bottom: '0', position: 'absolute', width: '100%' }}>{/* marginTop: '95px', */}
                <div style={{ margin: '20px' }}>
                    <h1 style={{ width: '100%', color: '#FFFFFF', fontWeight: 'bolder', fontFamily: 'Nunito', fontSize: '32px' }}>Start learning on <br />VedaAcademy</h1>
                    <h6 style={{ width: '100%', color: '#FFFFFF', fontWeight: '700', fontFamily: 'Nunito', }}>India's largest learning platform</h6>
                </div>
                <div>
                    <div style={{ margin: '20px' }} className="d-grid gap-2">
                        <Link to="/sign-in" style={{ color: '#FFFFFF', fontWeight: '900', backgroundColor: '#00FA9A', }} className="btn btn-lg" type="button">Get started</Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SatrtUp;
/* background-color: #7f53ac;
background-image: linear-gradient(315deg, #7f53ac 0%, #647dee 74%); */