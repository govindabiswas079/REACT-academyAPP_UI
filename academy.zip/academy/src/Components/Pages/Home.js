import React from 'react';
import Navbar from '../Navogation/Navbar';
import '../Navogation/Navbar.css';
import Carousel from 'react-grid-carousel'
import { Link, useNavigate } from 'react-router-dom';
import Navigation from '../Navogation/Navigation';



const Home = (props) => {
   let navigate = useNavigate();
   const userData = sessionStorage.getItem('userData')
   let jsonObject = JSON.parse(userData);

   const onClick = () => {
      navigate('/tests')
   }

   const LiveQuiz = () => {
      navigate('/live-quiz')
   }

   const handleClick = () => {
      navigate('/all-free-classes')
   }

   const Doubt = () => {
      navigate('/doubt')
   }

   const Subscription = () => {
      navigate('/subscription')
   };

   const livecalsses = () => {
      navigate('/live-calsses')
   };

   const GetInTouch = () => {
      navigate('/get-in-touch')
   };

   const preparesyllabus = () => {
      window.location.replace('/prepare-syllabus')
   };

   const educatorprofile = (e) => {
      window.location.replace('/educator-profile')
      sessionStorage.setItem('Educators', JSON.stringify(e))
   };

   return (
      <>
         <Navigation />

         <Navbar />
         <div>
            <br />
            <br />
            <header style={{ width: '100%', zIndex: '9', justifyContent: 'space-around', alignItems: 'center', boxSizing: 'border-box', backgroundColor: '#FFFFFF', marginTop: '25px' }}>
               <div style={{ margin: '15px' }}>
                  <br />
                  <h2 style={{ fontWeight: '900', fontFamily: 'Nunito' }}>Hi, {jsonObject.Name}</h2>{/* {jsonObject.Name} */}
                  <p style={{ fontFamily: 'Nunito' }}>Let's start learning</p>
               </div>
               {/*  */}
               <div id="carouselExampleDark" className="carousel carousel-dark slide" data-bs-ride="carousel">

                  <div className="carousel-inner">
                     <div className="carousel-item active" data-bs-interval="10000">
                        <div className="freeClasses" onClick={(e) => livecalsses(e)}>
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', margin: '10px 10px' }}>
                                       <div style={{ backgroundColor: 'red', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#FFFFFF', fontSize: '10px', fontFamily: 'Nunito' }}>• LIVE <i className="bi bi-eye"></i> 125</p>
                                       </div>
                                       <i className="bi bi-collection-play-fill" style={{ color: 'red', marginLeft: '10px' }}></i>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           {/* <div style={{ margin: '0px 10px' }}>
                              <i className="bi bi-collection-play-fill" style={{ color: 'red', fontSize: '20px', }}></i>
                           </div> */}
                        </div>
                        <div style={{ margin: '20px 10px', lineHeight: '2px' }} >
                           <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>SCIENCE & TECHNOLOGY</p>
                           <h5 style={{ fontWeight: '500', fontFamily: 'Nunito' }}>Indian Power Sector Challenge and Solutions</h5>
                           <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Pratik kumar</h6>
                        </div>
                     </div>
                     <div className="carousel-item" data-bs-interval="2000">
                        <div className="freeClasses1" onClick={(e) => livecalsses(e)}>
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', margin: '10px 10px' }}>
                                       <div style={{ backgroundColor: 'red', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#FFFFFF', fontSize: '10px', fontFamily: 'Nunito' }}>• LIVE <i className="bi bi-eye"></i> 125</p>
                                       </div>
                                       <i className="bi bi-collection-play-fill" style={{ color: 'red', marginLeft: '10px' }}></i>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           {/* <div style={{ margin: '0px 10px' }}>
                              <i className="bi bi-collection-play-fill" style={{ color: 'red', fontSize: '20px', }}></i>
                           </div> */}
                        </div>
                        <div style={{ margin: '20px 10px', lineHeight: '2px' }} >
                           <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>PRACTICE & STRATEGY</p>
                           <h5 style={{ fontWeight: '500', fontFamily: 'Nunito' }}>(Prelims) Current Affaires Prime Time & Editorials-4th Dec</h5>
                           <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                        </div>
                     </div>
                     <div className="carousel-item">
                        <div className="freeClasses2" onClick={(e) => livecalsses(e)}>
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', margin: '10px 10px' }}>
                                       <div style={{ backgroundColor: 'red', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#FFFFFF', fontSize: '10px', fontFamily: 'Nunito' }}>• LIVE <i className="bi bi-eye"></i> 125</p>
                                       </div>
                                       <i className="bi bi-collection-play-fill" style={{ color: 'red', marginLeft: '10px' }}></i>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           {/* <div style={{ margin: '0px 10px' }}>
                              <i className="bi bi-collection-play-fill" style={{ color: 'red', fontSize: '20px', }}></i>
                           </div> */}
                        </div>
                        <div style={{ margin: '20px 10px', lineHeight: '2px' }} >
                           <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', }}>CURRENT AFFAIRS</p>
                           <h5 style={{ fontWeight: '500', fontFamily: 'Nunito' }}>Achiever Current Affairs and <br /> Static GK 14</h5>
                           <h6 style={{ fontWeight: '300', fontFamily: 'Nunito', color: 'gray' }}>Prem Kumar</h6>
                        </div>
                     </div>
                  </div>
                  <div style={{ position: 'inherit' }} className="carousel-indicators">
                     <button style={{ backgroundColor: '#000000', height: '4px', width: '60px', }} type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
                     <button style={{ backgroundColor: '#000000', height: '4px', width: '60px', }} type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                     <button style={{ backgroundColor: '#000000', height: '4px', width: '60px', }} type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
                  </div>
               </div>

               {/*  */}
               <div style={{ margin: '0 10px' }} className="d-grid gap-2 d-md-block">
                  <button onClick={(e) => handleClick()} style={{ fontWeight: '700', fontFamily: 'Nunito', color: '#000000', fontSize: '15px' }} className="btn btn-outline-secondary btn-lg " type="button">See all free classes</button>
               </div>
               <br />
               <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
                  <div data-aos="fade-up">
                     <div className="row" data-aos="zoom-in" data-aos-delay="100">

                        <div className="col-lg-3 col-md-4">
                           <p style={{ margin: '10px', fontFamily: 'Nunito', color: 'gray' }}>You could also</p>
                           <div className="icon-box" onClick={(e) => LiveQuiz(e)}>
                              <br />
                              <i className="bi bi-check-circle" style={{ color: 'blue', }}></i>
                              <div>
                                 <h3 style={{ fontFamily: 'Nunito', fontSize: '15px' }}>Take a quick quiz</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i className="bi bi-arrow-right-short" style={{ color: '#ffbb2c', }}></i>
                              <br />
                           </div>
                        </div>
                        <div className="col-lg-3 col-md-4">
                           <div className="icon-box" onClick={(e) => onClick(e)}>
                              <br />
                              <i className="bi bi-symmetry-horizontal" style={{ color: 'orangered', }}></i>
                              <div>
                                 <h3 style={{ fontFamily: 'Nunito', fontSize: '15px' }}>Try a mock test</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i className="bi bi-arrow-right-short" style={{ color: '#ffbb2c', }}></i>
                              <br />
                           </div>
                        </div>
                        <div className="col-lg-3 col-md-4">
                           <div className="icon-box" onClick={(e) => Doubt(e)}>
                              <br />
                              <i className="bi bi-chat-dots-fill" style={{ color: '#ffbb2c', }}></i>
                              <div>
                                 <h3 style={{ fontFamily: 'Nunito', fontSize: '15px' }}>Ask a doubt</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i className="bi bi-arrow-right-short" style={{ color: '#ffbb2c', }}></i>
                              <br />
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <br />
               <section id="about" className="about">
                  <div className="container" data-aos="fade-up">
                     <div className="row">
                        <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                           <div style={{ display: 'flex' }}>
                              <div>
                                 <h6 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Prepare with<br /> full syllabus batches</h6>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <div>
                                 <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px' }} to="">SEE MORE</Link>
                                 <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i>
                              </div>
                           </div>
                           <ul>
                              <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'gray' }} className="bi bi-check-circle"></i> Exceptional education across batches</li>
                              <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'gray' }} className="bi bi-check-circle"></i> Daily classes to keep you ahead</li>
                              <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'gray' }} className="bi bi-check-circle"></i> On-time syllabus completion</li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </section>
               <Carousel cols={2} showDots rows={1} gap={1} loop>
                  <Carousel.Item>
                     <div className="container py-4" onClick={(e) => preparesyllabus(e)}>
                        <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                           <div style={{ height: '2px', width: '85%', backgroundColor: 'rgb(171 219 226 / 45%)', borderRadius: '10px' }}></div>
                        </div>
                        <div className="row align-items-md-stretch">
                           <div style={{ marginTop: '5px' }} className=""> {/* col-md-6 */}
                              <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                                 <div style={{ height: '2px', width: '94%', backgroundColor: 'rgb(171 219 226 / 45%)', borderRadius: '10px' }}></div>
                              </div>
                              <div style={{ backgroundColor: 'rgb(171 219 226 / 19%)', marginTop: '5px' }} className="h-100 p-3  border rounded-3">
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', fontFamily: 'Nunito', fontSize: '10px' }}>FULL SYLLABUS COMPLETION</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', fontFamily: 'Nunito', fontSize: '10px' }}>HI</p>
                                    </div>
                                 </div>
                                 <section id="about" className="about">
                                    <div className="" data-aos="fade-up">
                                       <div className="row">
                                          <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                                             <h5 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Prepare with<br /> full syllabus batches</h5>
                                             <ul style={{ textAlign: 'initial' }}>
                                                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-calendar-check"></i> Starts in 4 days. 8 Dec 2021</li>
                                                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-cloud-sun"></i> Early morning classes</li>
                                                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-person"></i> Anshuman Singh, Varun Pachauri, Ishrat jawed Faroo...</li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </section>
                                 <img style={{ width: '100%', borderRadius: '5px', height: '140px' }} src="https://www.opengroup.org/sites/default/files/about-us.jpg" alt="" />
                                 <br />
                                 <br />
                                 <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                                    <div style={{ display: 'flex' }}>
                                       <i style={{ marginRight: '15px' }} className="bi bi-hr">
                                       </i><Link style={{ color: 'black', fontFamily: 'Nunito' }} to="">View full schedule</Link>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </Carousel.Item>
                  <Carousel.Item>
                     <div className="container py-4" onClick={(e) => preparesyllabus(e)}>
                        <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                           <div style={{ height: '2px', width: '85%', backgroundColor: 'rgb(171 219 226 / 45%)', borderRadius: '10px' }}></div>
                        </div>
                        <div className="row align-items-md-stretch">
                           <div style={{ marginTop: '5px' }} className=""> {/* col-md-6 */}
                              <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                                 <div style={{ height: '2px', width: '94%', backgroundColor: 'rgb(171 219 226 / 45%)', borderRadius: '10px' }}></div>
                              </div>
                              <div style={{ backgroundColor: 'rgb(171 219 226 / 19%)', marginTop: '5px' }} className="h-100 p-3  border rounded-3">
                                 <div style={{ display: 'flex', }}>
                                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', fontFamily: 'Nunito', fontSize: '10px' }}>FULL SYLLABUS COMPLETION</p>
                                    </div>
                                    <div style={{ flex: '1' }}></div>
                                    <div style={{ backgroundColor: '#FFFFFF', borderRadius: '5px', zIndex: '9' }}>
                                       <p style={{ margin: '4px', fontWeight: '700', fontFamily: 'Nunito', fontSize: '10px' }}>HI</p>
                                    </div>
                                 </div>
                                 <section id="about" className="about">
                                    <div className="" data-aos="fade-up">
                                       <div className="row">
                                          <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                                             <h5 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Prepare with<br /> full syllabus batches</h5>
                                             <ul style={{ textAlign: 'initial' }}>
                                                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-calendar-check"></i> Starts in 4 days. 8 Dec 2021</li>
                                                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-cloud-sun"></i> Early morning classes</li>
                                                <li style={{ fontFamily: 'Nunito' }}><i style={{ color: 'black' }} className="bi bi-person"></i> Anshuman Singh, Varun Pachauri, Ishrat jawed Faroo...</li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </section>
                                 <img style={{ width: '100%', borderRadius: '5px', height: '140px' }} src="https://uk.rs-cdn.com/site_files/cache/9559/images/feature/9a967024cac20554d42f8e611313a3b7_4bd07e3c55a996b45bacfc40df329e9e.jpg" alt="" />
                                 <br />
                                 <br />
                                 <div style={{ justifyItems: 'center' }} className="d-grid gap-2 mx-auto">
                                    <div style={{ display: 'flex' }}>
                                       <i style={{ marginRight: '15px' }} className="bi bi-hr">
                                       </i><Link style={{ color: 'black', fontFamily: 'Nunito' }} to="">View full schedule</Link>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </Carousel.Item>
               </Carousel>

               <div style={{ margin: '0 10px' }} className="d-grid gap-2 d-md-block">
                  <button style={{ fontWeight: '600', backgroundColor: '#08bd80', color: '#FFFFFF', fontFamily: 'Nunito' }} className="btn btn-lg" type="button" onClick={(e) => Subscription(e)}>Get subscription</button>
               </div>
               <br />
               <div style={{ justifyItems: 'center', }} className="d-grid gap-2 mx-auto">
                  <div style={{ display: 'flex' }}>

                     <Link style={{ color: 'black', fontFamily: 'Nunito', fontWeight: '700', fontSize: '10px' }} to="/subscription-work">SEE HOW SUBSCRIPTION WORKS</Link>
                     <i style={{ marginLeft: '10px', fontSize: '10px' }} className="bi bi-arrow-right"></i>
                  </div>
               </div>
               <br />
            </header>
            <br />
            <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
               <div data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div className="icon-box">
                           <br />
                           <div>
                              <h2 style={{ fontWeight: '700', color: '#000000', fontFamily: 'Nunito', fontSize: '20px' }}>Offers only for you</h2>
                              <h3 style={{ color: 'gray', fontFamily: 'Nunito', fontSize: '15px' }}>Get upto 3 months free with<br /> your subscription</h3>
                              <button type="button" style={{ marginTop: '20px', fontFamily: 'Nunito', fontWeight: '700', color: '#000000' }} className="btn btn-outline-secondary btn-sm">see all offers</button>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img style={{ width: '30%' }} src="https://static.uacdn.net/production/_next/static/images/goal/iconic_1.png?q=75&w=256" alt="" />
                           <br />
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <br />
            <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
               <h5 style={{ fontWeight: '700', color: '#000000', margin: '20px' }}>What's new</h5>
               <div className="container" data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div style={{ borderRadius: '10px' }} className="icon-box">
                           <br />
                           <div>
                              <h5 style={{ fontWeight: '700', color: 'blue' }}>vedaacademy<br /> combat</h5>
                              <h3 style={{ fontWeight: '700', color: '#000000', marginTop: '8px' }}>UPSC CSE - GS</h3>
                              <h5 style={{ color: 'gray', marginTop: '8px', fontSize: '14px' }}>Next Combat on <span style={{ color: 'blue', fontWeight: '900', }}>5 Dec 2021 • 11:00 am</span> </h5>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img style={{ width: '20%' }} src="https://static.uacdn.net/production/_next/static/images/goal/iconic_1.png?q=75&w=256" alt="" />
                           <br />
                        </div>
                     </div>
                  </div>
               </div>
               <br />
            </section>
            <br />
            <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
               <section id="about" className="about">
                  <div className="container" data-aos="fade-up">
                     <div className="row">
                        <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                           <div style={{ display: 'flex' }}>
                              <div>
                                 <h5 style={{ fontFamily: 'Nunito', fontWeight: '900' }}>Meet our<br /> exceptional educator</h5>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <div>
                                 <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '12px' }} to="">SEE MORE</Link>
                                 <i style={{ marginLeft: '10px', fontSize: '12px' }} className="bi bi-chevron-compact-right"></i>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <Carousel cols={3} showDots rows={1} gap={1} loop>
                  <Carousel.Item>
                     <div style={{ display: 'flex' }}>
                        <div style={{ margin: '0px', width: '47%', }} onClick={() => educatorprofile({ EduName: 'Mrunal Patel', WatchMins: '54M', Followers: '305k', EduAbout: '', Position: 'Indian Economy', Image: 'https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png' })}>
                           <div style={{ borderRadius: '10px', backgroundColor: '#80808042' }} className="container py-2">
                              <img style={{ width: '100%', borderRadius: '10px', height: '200px' }} src="https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png" alt="" />
                           </div>
                           <div style={{ lineHeight: '5px', marginTop: '8px', marginLeft: '10px' }}>
                              <h6 style={{ fontWeight: '700', fontFamily: 'Nunito' }}>Mrunal Patel</h6>
                              <p style={{ fontFamily: 'Nunito', color: 'gray' }}>Indian Economy</p>
                              <p style={{ color: 'green', fontFamily: 'Nunito' }}>305k follower</p>
                           </div>
                        </div>
                        <div style={{ margin: '0px', width: '47%', marginLeft: '12px' }} onClick={() => educatorprofile({ EduName: 'Parit nayak', WatchMins: '34M', Followers: '302k', EduAbout: '', Position: 'Geography', Image: 'https://www.seekpng.com/png/full/14-146665_man-person-avatar-face-head-portrait-glass-person.png' })}>
                           <div style={{ borderRadius: '10px', backgroundColor: '#80808042' }} className="container py-2">
                              <img style={{ width: '100%', borderRadius: '10px', height: '200px' }} src="https://www.seekpng.com/png/full/14-146665_man-person-avatar-face-head-portrait-glass-person.png" alt="" />
                           </div>
                           <div style={{ lineHeight: '5px', marginTop: '8px', marginLeft: '10px' }}>
                              <h6 style={{ fontWeight: '700', fontFamily: 'Nunito' }}>Parit nayak</h6>
                              <p style={{ fontFamily: 'Nunito', color: 'gray' }}>Geography</p>
                              <p style={{ color: 'green', fontFamily: 'Nunito' }}>302k follower</p>
                           </div>
                        </div>
                     </div>
                  </Carousel.Item>
                  <Carousel.Item>
                     <div style={{ display: 'flex' }}>
                        <div style={{ margin: '0px', width: '47%', }} onClick={() => educatorprofile({ EduName: 'Mr. Abhi', WatchMins: '45M', Followers: '305k', EduAbout: '', Position: 'Current Affairs', Image: 'https://www.seekpng.com/png/full/14-146665_man-person-avatar-face-head-portrait-glass-person.png' })}>
                           <div style={{ borderRadius: '10px', backgroundColor: '#80808042' }} className="container py-2">
                              <img style={{ width: '100%', borderRadius: '10px', height: '200px' }} src="https://www.seekpng.com/png/full/14-146665_man-person-avatar-face-head-portrait-glass-person.png" alt="" />
                           </div>
                           <div style={{ lineHeight: '5px', marginTop: '8px', marginLeft: '10px' }}>
                              <h6 style={{ fontWeight: '700', fontFamily: 'Nunito' }}>Mr. Abhi</h6>
                              <p style={{ fontFamily: 'Nunito', color: 'gray' }}>Current Affairs</p>
                              <p style={{ color: 'green', fontFamily: 'Nunito' }}>305k follower</p>
                           </div>
                        </div>
                        <div style={{ margin: '0px', width: '47%', marginLeft: '12px' }} onClick={() => educatorprofile({ EduName: 'Arti Choudhary', WatchMins: '43M', Followers: '91k', EduAbout: '', Position: 'History', Image: 'https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png' })}>
                           <div style={{ borderRadius: '10px', backgroundColor: 'gray' }} className="container py-2">
                              <img style={{ width: '100%', borderRadius: '10px', height: '200px' }} src="https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png" alt="" />
                           </div>
                           <div style={{ lineHeight: '5px', marginTop: '8px', marginLeft: '10px' }}>
                              <h6 style={{ fontWeight: '700', fontFamily: 'Nunito' }}>Arti Choudhary</h6>
                              <p style={{ fontFamily: 'Nunito', color: 'gray' }}>History</p>
                              <p style={{ color: 'green', fontFamily: 'Nunito' }}>91k follower</p>
                           </div>
                        </div>
                     </div>
                  </Carousel.Item>
               </Carousel>
            </section>
            <br />

            <div style={{ backgroundColor: '#FFFFFF' }}>
               <section id="about" className="about">
                  <div className="container" data-aos="fade-up">
                     <div style={{ marginTop: '10px' }}>
                        <h5 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Courses on all subjects</h5>
                     </div>
                     <div className="row">
                        <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                           <div style={{ display: 'flex' }}>
                              <div>
                                 <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Upcoming</h6>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <div>
                                 <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                                 <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <Carousel cols={2} rows={1} gap={1} loop>
                  <Carousel.Item>
                     <div className="container py-4">
                        <div className="Upcoming">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>STARTS 8 DEC, 2:00 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                        <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                        <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                        <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
                     </div>
                  </Carousel.Item>
                  <Carousel.Item>
                     <div className="container py-4">
                        <div className="Upcoming">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>STARTS 8 DEC, 2:00 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                        <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                        <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                        <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
                     </div>
                  </Carousel.Item>
               </Carousel>

               <section style={{ marginTop: '30px' }} id="about" className="about">
                  <div className="container" data-aos="fade-up">
                     <div className="row">
                        <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                           <div style={{ display: 'flex' }}>
                              <div>
                                 <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Recently started</h6>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <div>
                                 <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                                 <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <Carousel cols={2} rows={1} gap={1} loop>
                  <Carousel.Item>
                     <div className="container py-1">
                        <div className="Upcoming1">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>5 DEC, 5:30 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                        <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                        <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                        <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                     </div>
                  </Carousel.Item>
                  <Carousel.Item>
                     <div className="container py-1">
                        <div className="Upcoming1">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>5 DEC, 5:30 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                        <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                        <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                        <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                     </div>
                  </Carousel.Item>
               </Carousel>


               <section style={{ marginTop: '30px' }} id="about" className="about">
                  <div className="container" data-aos="fade-up">
                     <div className="row">
                        <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                           <div style={{ display: 'flex' }}>
                              <div>
                                 <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Completed</h6>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <div>
                                 <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                                 <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <Carousel cols={2} rows={1} gap={1} loop>
                  <Carousel.Item>
                     <div className="container py-4">
                        <div className="Upcoming2">
                           <div>
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>Completed 8 DEC, 2:00 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                        <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                        <h4 style={{ fontWeight: '500', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                        <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                     </div>
                  </Carousel.Item>
                  <Carousel.Item>
                     <div className="container py-4">
                        <div className="Upcoming2">
                           <div >
                              <div>
                                 <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                    <div style={{ display: 'flex', }}>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>Completed 8 DEC, 2:00 PM</p>
                                       </div>
                                       <div style={{ flex: '1' }}></div>
                                       <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                          <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                        <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                        <h4 style={{ fontWeight: '500', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                        <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                     </div>
                  </Carousel.Item>
               </Carousel>
               <br />
               <div style={{ margin: '0 10px' }} className="d-grid gap-2 d-md-block">
                  <button style={{ fontWeight: '600', backgroundColor: '#08bd80', fontFamily: 'Nunito', color: '#FFFFFF' }} className="btn btn-lg" type="button" onClick={(e) => Subscription(e)}>Get subscription</button>
               </div>
               <br />
               <div style={{ justifyItems: 'center', }} className="d-grid gap-2 mx-auto">
                  <div style={{ display: 'flex' }}>
                     <Link style={{ color: 'black', fontWeight: '900', fontFamily: 'Nunito', fontSize: '10px' }} to="/subscription-work">SEE HOW SUBSCRIPTION WORKS</Link>
                     <i style={{ marginLeft: '10px', fontSize: '10px' }} className="bi bi-chevron-compact-right"></i>
                  </div>
               </div>
               <br />
            </div>
            <br />
            <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
               <div data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div className="icon-box">
                           <br />
                           <div>
                              <h3 style={{ fontWeight: '700', color: '#000000', fontFamily: 'Nunito', fontSize: '20px', }}>Have questions?</h3>
                              <h3 style={{ fontWeight: '700', color: 'gray', fontFamily: 'Nunito', fontSize: '15px', marginTop: '10px' }}>Our experts can answer all your question over a phone call</h3>
                              <h3 style={{ fontWeight: '700', color: 'gray', fontFamily: 'Nunito', fontSize: '15px', marginTop: '10px' }}>"How don the subscription work?"</h3>
                              <button type="button" style={{ marginTop: '20px', fontFamily: 'Nunito', color: '#000000', fontWeight: '700', }} className="btn btn-outline-secondary btn-sm" onClick={(e) => GetInTouch(e)}>Get in touch</button>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img style={{ width: '30%' }} src="https://static.uacdn.net/production/_next/static/images/ttu_illustration.svg?q=75&w=1920" alt="" />
                           <br />
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </div >
         <br />
         <br />
         <br />
         <br />
      </>
   );
};

export default Home
