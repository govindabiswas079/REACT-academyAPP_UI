import React from 'react';
import Navigation from '../Navogation/Navigation';
import { useNavigate, Link } from 'react-router-dom';

const SelfStudy = () => {
   let navigation = useNavigate();
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const Practice = () => {
      navigation("/practice")
   };

   const Syllabus = () => {
      navigation("/syllabus")
   };

   const Tests = () => {
      navigation("/tests")
   };

   const coursesbatches = () => {
      navigation('/courses-batches')
   };

   const AllFreeClasses = () => {
      navigation('/all-free-classes')
   };

   const GetInTouch = () => {
      navigation('/get-in-touch')
   };

   return (
      <>
         <Navigation />
         <div>
            <header className={nav ? "header active" : "header"}>
               <br />
               <div className="container">
                  <div className="row height d-flex justify-content-center align-items-center">
                     <div className="col-md-6">
                        <div className="form"> <i className="fa fa-search"></i> <input type="text" className="form-control form-input" placeholder="Search anything..." /> <span style={{position: 'absolute'}} className="left-pan"><i className="fa fa-microphone"></i></span> </div>
                     </div>
                  </div>
               </div>
               <br />
            </header>
            <br />
            <br />
            <br />
            <br />
            <br />
            <section style={{ backgroundColor: 'rgb(171 219 226 / 45%)', }} id="features" className="features">
               <div data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div className="icon-box">
                           <br />
                           <div>
                              <h3 style={{ fontWeight: '700', color: '#000000', fontSize: '20px', fontFamily: 'Nunito', }}>Ace your preparation</h3>
                              <p style={{ fontWeight: '300', color: 'gray', fontSize: '13px', fontFamily: 'Nunito', }}>Learn with live classes from top educators, get personalised guidance through 1:1 live mentorship and a lot</p>{/*  get personalised guidance trhough 1:1 live mentorship and a lot */}
                              <Link to="/subscription" type="button" style={{ marginTop: '3px', backgroundColor: '#08bd80', color: '#FFFFFF', fontWeight: '500', fontFamily: 'Nunito', }} className="btn btn-sm">Get subscription</Link>
                              <p style={{ marginTop: '10px', color: 'gray', fontFamily: 'Nunito', }}>Starts from ₹2,500/mo</p>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img style={{ width: '30%' }} src="https://static.uacdn.net/production/_next/static/images/goal/iconic_1.png?q=75&w=256" alt="" />
                           <br />
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <br />
            <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
               <br />
               <div className="container" data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div style={{ borderRadius: '10px', backgroundColor: 'rgb(60 69 70 / 11%)' }} className="icon-box" onClick={(e) => coursesbatches(e)}>
                           <br />
                           <div>
                              <h6 style={{ fontWeight: '900', color: '#000000', fontFamily: 'Nunito', }}>Courses & batches</h6>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img style={{ width: '20%' }} src="https://static.uacdn.net/production/_next/static/images/goal/iconic_1.png?q=75&w=256" alt="" />
                           <br />
                        </div>
                        <br />
                        <div style={{ display: 'flex' }}>
                           <div style={{ borderRadius: '10px', flexDirection: 'column', width: '100px', height: '100px', justifyItems: 'center', backgroundColor: 'rgb(60 69 70 / 11%)' }} className="icon-box" onClick={(e) => Tests(e)}>
                              <i style={{ color: '#00d0ff' }} className="bi bi-window-dash"></i>
                              <h3 style={{ margin: 'revert', fontFamily: 'Nunito', fontSize: '15px' }}>Tests</h3>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div style={{ borderRadius: '10px', flexDirection: 'column', width: '100px', height: '100px', justifyItems: 'center', backgroundColor: 'rgb(60 69 70 / 11%)' }} className="icon-box" onClick={(e) => Practice(e)}>
                              <i style={{ color: '#1f0080' }} className="bi bi-window-dash"></i>
                              <h3 style={{ margin: 'revert', fontFamily: 'Nunito', fontSize: '15px' }}>Practice</h3>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <div style={{ borderRadius: '10px', flexDirection: 'column', width: '100px', height: '100px', justifyItems: 'center', backgroundColor: 'rgb(60 69 70 / 11%)' }} className="icon-box" onClick={(e) => Syllabus(e)}>
                              <i style={{ color: 'rgb(8 145 14)' }} className="bi bi-window-dash"></i>
                              <h3 style={{ margin: 'revert', fontFamily: 'Nunito', fontSize: '15px' }}>Syllabus</h3>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <br />
            </section>
            <header style={{ width: '100%', zIndex: '9', justifyContent: 'space-around', alignItems: 'center', boxSizing: 'border-box', backgroundColor: '#FFFFFF', }}>
               <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
                  <div data-aos="fade-up">
                     <div className="row" data-aos="zoom-in" data-aos-delay="100">
                        <div className="col-lg-3 col-md-4">
                           <div className="icon-box">
                              <br />
                              {/* <i className="bi bi-pencil-square" style={{ color: '#ffbb2c', }}></i> */}
                              <i className="bi bi-collection-play-fill" style={{ color: '#ffbb2c', }}></i>
                              {/* <img src="https://static.uacdn.net/web-cms/benefitcourses_cceb8214b5.svg?q=75&w=256&fm=webp" alt="" /> */}
                              <div>
                                 <h3 style={{ fontSize: '14px', fontFamily: 'Nunito' }}>Other Courses</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i className="bi bi-arrow-right-short" style={{ color: '#ffbb2c', }}></i>
                              <br />
                           </div>
                        </div>
                        <div className="col-lg-3 col-md-4">
                           <div className="icon-box" onClick={(e) => AllFreeClasses(e)}>
                              <br />
                              {/* <i className="ri-store-line" style={{ color: '#ffbb2c', }}></i> */}
                              {/* <img src="https://static.uacdn.net/web-cms/benefitcourses_cceb8214b5.svg?q=75&w=256&fm=webp" alt="" /> */}
                              <i className="bi bi-collection-play-fill" style={{ color: '#ffbb2c', }}></i>
                              <div>
                                 <h3 style={{ fontSize: '14px', fontFamily: 'Nunito' }}>Free live classes</h3>
                              </div>
                              <div style={{ flex: '1' }}></div>
                              <i className="bi bi-arrow-right-short" style={{ color: '#ffbb2c', }}></i>
                              <br />
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
            </header>
            <br />
            <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
               <div data-aos="fade-up">
                  <div className="row" data-aos="zoom-in" data-aos-delay="100">
                     <div className="col-lg-3 col-md-4">
                        <div className="icon-box">
                           <br />
                           <div>
                              <h3 style={{ fontWeight: '700', color: '#000000', fontFamily: 'Nunito', fontSize: '22px', }}>Have questions?</h3>
                              <h3 style={{ fontWeight: '700', color: 'gray', fontFamily: 'Nunito', fontSize: '15px', marginTop: '10px' }}>Our experts can answer all your question over a phone call</h3>
                              <h3 style={{ fontWeight: '700', color: 'gray', marginTop: '15px', fontFamily: 'Nunito', fontSize: '15px', }}>"How don the subscription work?"</h3>
                              <button type="button" style={{ marginTop: '20px', fontFamily: 'Nunito', color: '#000000', fontWeight: '700', }} className="btn btn-outline-secondary btn-sm" onClick={(e) => GetInTouch(e)}>Get in touch</button>
                           </div>
                           <div style={{ flex: '1' }}></div>
                           <img style={{ width: '30%' }} src="https://static.uacdn.net/production/_next/static/images/combat/listing-banner.svg?q=75&w=828" alt="" />
                           <br />
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         </div>
         <br />
         <br />
         <br />
      </>
   );
};

export default SelfStudy
