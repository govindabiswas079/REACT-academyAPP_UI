import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navigation from '../Navogation/Navigation';

const Account = () => {
  let navigate = useNavigate();
  const [nav, setNav] = React.useState(false)

  const changeBackground = () => {
    if (window.scrollY >= 50) {
      setNav(true);
    } else {
      setNav(false);
    }
  }
  window.addEventListener('scroll', changeBackground);

  const Enrollments = () => {
    navigate('/enrollments')
  };

  const Updates = () => {
    navigate('/updates')
  };

  const Downloads = () => {
    navigate('/downloads')
  };

  const Myeducators = () => {
    navigate('/my-educators')
  };

  const Settings = () => {
    navigate('/settings')
  };

  const FAQs = () => {
    navigate('/faqs')
  };

  return (
    <>
      <Navigation />
      <div>
        <header className={nav ? "header active" : "header"}>
          <div style={{ marginTop: '10px' }} className="container">
            <div style={{ display: 'flex' }} className="header-main">
              <div className="logo">
                <Link to="/">UPSC - GS</Link>
                {/* <p>Free plan</p> */}
              </div>
              <div style={{ flex: '1' }}></div>
              {/* <div>
                <button type="button" className="btn btn-outline-dark">Manage</button>
              </div> */}
            </div>
          </div>
        </header>
        <br />
        <br />
        <br />
        <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
          <br />
          <div style={{ marginTop: '10px' }} className="container" data-aos="fade-up">
            <div className="row" data-aos="zoom-in" data-aos-delay="100">
              <div className="col-lg-3 col-md-4">
                <div style={{ display: 'flex' }}>
                  <div style={{ borderRadius: '10px', flexDirection: 'column', width: '165px', backgroundColor: '#80808036' }} className="icon-box" onClick={(e) => Enrollments(e)}>
                    <div style={{ display: 'flex', marginRight: 'auto' }}>
                      <i style={{ fontSize: '22px' }} className="bi bi-joystick"></i>
                      <div style={{ flex: '1' }}></div>
                      <h3 style={{ marginTop: '3px', fontSize: '13px' }}>Enrollments</h3>
                    </div>
                  </div>

                  <div style={{ flex: '1' }}></div>

                  <div style={{ borderRadius: '10px', flexDirection: 'column', width: '165px', backgroundColor: '#80808036' }} className="icon-box" onClick={(e) => Downloads(e)}>
                    <div style={{ display: 'flex', marginRight: 'auto' }}>
                      <i style={{ fontSize: '22px' }} className="bi bi-cloud-arrow-down-fill"></i>
                      <div style={{ flex: '1' }}></div>
                      <h3 style={{ marginTop: '3px', fontSize: '13px' }}>Downloads</h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div style={{ marginTop: '10px' }} className="container" data-aos="fade-up">
            <div className="row" data-aos="zoom-in" data-aos-delay="100">
              <div className="col-lg-3 col-md-4">
                <div style={{ display: 'flex' }}>
                  <div style={{ borderRadius: '10px', flexDirection: 'column', width: '165px', backgroundColor: '#80808036' }} className="icon-box" onClick={(e) => Updates(e)}>
                    <div style={{ display: 'flex', marginRight: 'auto' }}>
                      <i style={{ fontSize: '22px' }} className="bi bi-bell-fill"></i>
                      <div style={{ flex: '1' }}></div>
                      <h3 style={{ marginTop: '3px', fontSize: '13px' }}>Updates</h3>
                    </div>
                  </div>

                  <div style={{ flex: '1' }}></div>

                  <div style={{ borderRadius: '10px', flexDirection: 'column', width: '165px', backgroundColor: '#80808036' }} className="icon-box" onClick={(e) => Myeducators(e)}>
                    <div style={{ display: 'flex', marginRight: 'auto' }}>
                      <i style={{ fontSize: '22px' }} className="bi bi-person"></i>
                      <div style={{ flex: '1' }}></div>
                      <h3 style={{ marginTop: '3px', fontSize: '13px' }}>My educators</h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div style={{ marginTop: '10px' }} className="container" data-aos="fade-up">
            <div className="row" data-aos="zoom-in" data-aos-delay="100">
              <div className="col-lg-3 col-md-4">
                <div style={{ display: 'flex' }}>
                  <div style={{ borderRadius: '10px', flexDirection: 'column', width: '165px', backgroundColor: '#80808036' }} className="icon-box" onClick={(e) => FAQs(e)}>
                    <div style={{ display: 'flex', marginRight: 'auto' }}>
                      <i style={{ fontSize: '22px' }} className="bi bi-question-circle-fill"></i>
                      <div style={{ flex: '1' }}></div>
                      <h3 style={{ marginTop: '3px', fontSize: '13px' }}>FAQs</h3>
                    </div>
                  </div>

                  <div style={{ flex: '1' }}></div>

                  <div style={{ borderRadius: '10px', flexDirection: 'column', width: '165px', backgroundColor: '#80808036' }} className="icon-box" onClick={(e) => Settings(e)}>
                    <div style={{ display: 'flex', marginRight: 'auto' }}>
                      <i style={{ fontSize: '22px' }} className="bi bi-gear-fill"></i>
                      <div style={{ flex: '1' }}></div>
                      <h3 style={{ marginTop: '3px', fontSize: '13px' }}>Settings</h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <br />
        </section>
        <br />
        <div>
          <div style={{ margin: '10px' }}>
            <h3 style={{ fontFamily: 'Nunito', fontWeight: '800' }}>Activity</h3>
            <p style={{ fontFamily: 'Nunito', fontWeight: '600' }}>Daily stats on how much you learn & practice</p>
          </div>
          <div className="ActivityImg">
            <div className="ActivitybgImg">
              <div className="d-grid gap-2 col-6 mx-auto">
                <div style={{ display: 'flex', backgroundColor: 'rgb(8 189 128 / 15%)', justifyContent: 'center', borderRadius: '50px', padding: '3px', marginTop: '50px' }}>
                  <div style={{ backgroundColor: '#08bd80', width: '30px', height: '30px', borderRadius: '50px', marginTop: '2px', }}><i style={{ color: '#FFFFFF', fontSize: '20px', marginLeft: '5px' }} className="bi bi-lock-fill"></i></div>
                  <h3 style={{ fontSize: '11px', fontWeight: '900', marginLeft: '8px', marginTop: '10px', color: '#08bd80' }}>AVAILABLE WITH PLUS</h3>
                </div>
              </div>
            </div>
          </div>
          <br />
          <br />
          <br />
        </div>
      </div>
    </>
  );
};

export default Account
