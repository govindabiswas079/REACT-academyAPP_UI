import React from 'react';
import Avatar from '@mui/material/Avatar';
import Navigation from '../Navogation/Navigation';
import moment from 'moment'
import { Link, useNavigate } from 'react-router-dom';


export default function Notification() {
   let Navigate = useNavigate();
   const [nav, setNav] = React.useState(false)

   const changeBackground = () => {
      if (window.scrollY >= 50) {
         setNav(true);
      } else {
         setNav(false);
      }
   }
   window.addEventListener('scroll', changeBackground);

   const userData = sessionStorage.getItem('userData')
   let jsonObject = JSON.parse(userData);

   const Notify = () => {
      Navigate('/notify')
   }

   // const timedate = new Date().toLocaleString();
   const timedate = new Date('12/13/2021, 7:00:59 AM');
   const timedatee = new Date('12/15/2021, 12:36:32 PM');

   return (
      <div>
         <Navigation />
         <header className={nav ? "header active" : "header"}>
            <div style={{ marginTop: '10px' }} className="container">
               <div style={{ display: 'flex' }} className="header-main">
                  <div className="logo2">
                     {/* <Link to="/home"><i className="bi bi-arrow-left"></i></Link> */}
                     <Link style={{ marginLeft: '20px', fontSize: '20px' }} to="">Notification</Link>
                  </div>
                  <div style={{ flex: '1' }}></div>
               </div>
            </div>
         </header>
         <br />
         <br />
         <br />
         <section style={{ backgroundColor: "#FFFFFF" }} id="features" className="features">
            <div className="" data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box" onClick={(e) => Notify(e)}>
                        <Avatar alt="Profile Picture" src={'https://cdn.pixabay.com/photo/2015/03/04/22/35/head-659652_1280.png'} />
                        <div style={{ marginLeft: '20px' }}>
                           <h3 style={{ fontSize: '18px', fontWeight: '600', lineHeight: 'inherit' }}>{jsonObject.Name}</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '600', }}>modern history by nayak sir</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '500', lineHeight: 'inherit' }}>{moment(timedatee).fromNow()}</h3>
                        </div>
                     </div>
                  </div>
                  {/* <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <Avatar alt="Profile Picture" src={'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBkGJet9aJqR8PNuZV-ZI1JSiS0ToWXiO5VXumbH1GQHmT8eU-tYsPXYgPVNZWaqDbMV8&usqp=CAU'} />
                        <div style={{ marginLeft: '20px' }}>
                           <h3 style={{ fontSize: '18px', fontWeight: '600', lineHeight: 'inherit' }}>{jsonObject.Name}</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '600', }}>aniket flow your profile</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '500', lineHeight: 'inherit' }}>{moment(timedate).fromNow()}</h3>
                        </div>
                     </div>
                  </div> */}
                  {/* <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <Avatar alt="Profile Picture" src={'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtkrSfv3tfOKWqmyOyfvu7_Lhis_Q9FBS3Hg&usqp=CAU'} />
                        <div style={{ marginLeft: '20px' }}>
                           <h3 style={{ fontSize: '18px', fontWeight: '600' }}>Judiciary  and its working</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '500' }}>Judiciary  and its working</h3>
                        </div>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <Avatar alt="Profile Picture" src={'https://images.hindustantimes.com/img/2021/10/06/550x309/95eda336-26ed-11ec-9d0a-2107028cb826_1633556397901.jpg'} />
                        <div style={{ marginLeft: '20px' }}>
                           <h3 style={{ fontSize: '18px', fontWeight: '600' }}>Judiciary  and its working</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '500' }}>Judiciary  and its working</h3>
                        </div>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <Avatar alt="Profile Picture" src={'https://c8.alamy.com/comp/2A8JGWB/student-drawing-with-pencil-a-human-figure-be-inspired-by-a-wooden-model-boy-copying-a-dummy-for-school-art-tasks-kid-hold-a-pencil-and-draw-a-manga-2A8JGWB.jpg'} />
                        <div style={{ marginLeft: '20px' }}>
                           <h3 style={{ fontSize: '18px', fontWeight: '600' }}>Judiciary  and its working</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '500' }}>Judiciary  and its working</h3>
                        </div>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <Avatar alt="Profile Picture" src={'https://cdn.pixabay.com/photo/2015/03/04/22/35/head-659652_1280.png'} />
                        <div style={{ marginLeft: '20px' }}>
                           <h3 style={{ fontSize: '18px', fontWeight: '600' }}>Judiciary  and its working</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '500' }}>Judiciary  and its working</h3>
                        </div>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <Avatar alt="Profile Picture" src={'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtkrSfv3tfOKWqmyOyfvu7_Lhis_Q9FBS3Hg&usqp=CAU'} />
                        <div style={{ marginLeft: '20px' }}>
                           <h3 style={{ fontSize: '18px', fontWeight: '600' }}>Judiciary  and its working</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '500' }}>Judiciary  and its working</h3>
                        </div>
                     </div>
                  </div>
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <Avatar alt="Profile Picture" src={'https://news.aglasem.com/wp-content/uploads/2019/11/aglasem-min-750x375.jpg'} />
                        <div style={{ marginLeft: '20px' }}>
                           <h3 style={{ fontSize: '18px', fontWeight: '600' }}>Judiciary  and its working</h3>
                           <h3 style={{ fontSize: '14px', fontWeight: '500' }}>Judiciary  and its working</h3>
                        </div>
                     </div>
                  </div> */}
               </div>
            </div>
         </section>
         <br />
         <br />
         <br />
      </div>
   );
};