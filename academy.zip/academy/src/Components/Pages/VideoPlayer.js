/* import React from 'react'
import { Capacitor } from '@capacitor/core';
import { useState, useEffect, useRef } from 'react';
import { useVideoPlayer } from 'react-video-player-hook';
import { ExitStatus } from 'typescript';


const VideoPlayer = () => {
    const [url, setUrl] = useState(undefined);
    const platform = Capacitor.getPlatform();


    let apiTimer1 = useRef();
    let apiTimer2 = useRef();
    let apiCount = useRef(-1);
    const exit = useRef(false)

    const onPlay = async (fromPlayerId, currentTime) => {
        if (!exit.current) {
            const mIsPlaying = await isPlaying(fromPlayerId);
            console.log("==> mIsPlaying " + JSON.stringify(mIsPlaying));
            apiCount.current += 1;
            if (apiCount.current === 0) {
                const volume = await getVolume(fromPlayerId);
                if (volume.result) {
                    console.log("==> volume " + volume.value);
                } else {
                    console.log("==> volume " + volume.message);
                }
                apiTimer1.current = setTimeout(async () => {
                    const duration = await getDuration(fromPlayerId);
                    console.log("==> duration " +
                        JSON.stringify(duration));
                    if (duration.result) {
                        console.log("==> duration " + duration.value);
                    } else {
                        console.log("==> duration " + duration.message);
                    }
                    const volume = await setVolume(fromPlayerId, 0.2);
                    console.log("====> Volume ", volume.value);
                    const currentTime = await getCurrentTime(
                        fromPlayerId);
                    if (currentTime.result) {
                        console.log('==> currentTime ' +
                            currentTime.value);
                        const seektime = currentTime.value +
                            0.4 * duration.value;
                        console.log("seektime" + seektime)
                        const sCurrentTime = await setCurrentTime(
                            fromPlayerId, seektime);
                        console.log("==> setCurrentTime " +
                            sCurrentTime.value);
                    }
                    const mPause = await pause(fromPlayerId);
                    console.log('==> mPause ', mPause);
                }, 10000);
            }
        }
    };

    const onPause = async (fromPlayerId, currentTime) => {
        if (!exit.current) {
            if (apiCount.current === 0) {
                apiCount.current += 1;
                const mIsPlaying = await isPlaying(fromPlayerId);
                console.log("==> in Pause mIsPlaying " +
                    mIsPlaying.value);
                const volume = await getVolume(fromPlayerId);
                if (volume.result) {
                    console.log("==> volume " + volume.value);
                }
                const currentTime = await getCurrentTime(fromPlayerId);
                if (currentTime.result) {
                    console.log('==> currentTime ' + currentTime.value);
                }
                let muted = await getMuted(fromPlayerId);
                console.log("==> muted before setMuted " + muted.value);
                muted = await setMuted(fromPlayerId, !muted.value);
                console.log("==> setMuted " + muted.value);
                muted = await getMuted(fromPlayerId);
                console.log("==> muted after setMuted " + muted.value);
                apiTimer2.current = setTimeout(async () => {
                    const duration = await getDuration(fromPlayerId);
                    const rCurrentTime = await setCurrentTime(
                        fromPlayerId, duration.value - 4);
                    console.log('====> setCurrentTime ',
                        rCurrentTime.value);
                    await play(fromPlayerId);
                }, 4000);
            }
        }
    };

    const onReady = (fromPlayerId, currentTime) => {
        console.log("in OnReady playerId " + fromPlayerId +
            " currentTime " + currentTime);
    };

    const onEnded = (fromPlayerId, currentTime) => {
        console.log("in OnEnded playerId " + fromPlayerId +
            " currentTime " + currentTime);
        exitClear();
    };
    const onExit = (dismiss) => {
        console.log("in OnExit dismiss " + dismiss);
        exitClear();
    };

    const exitClear = () => {
        if (!ExitStatus.current) {
            console.log("%%%% in cleanup Timers %%%%")
            window.clearTimeout(apiTimer1.current);
            window.clearTimeout(apiTimer2.current);
            apiTimer1.current = 0;
            apiTimer2.current = 0;
            console.log("apiTimer1.current " + apiTimer1.current)
            console.log("apiTimer2.current " + apiTimer2.current)
            exit.current = true;
            console.log("exit.current " + exit.current)
            setUrl("");
            console.log("url " + url)
        }
    };

    const { initPlayer, isPlaying, pause, play, getDuration, setVolume,
        getVolume, setMuted, getMuted, setCurrentTime, getCurrentTime,
        stopAllPlayers } = useVideoPlayer({
            onReady,
            onPlay,
            onPause,
            onEnded,
            onExit,
        });

    useEffect(() => {
        if (platform === "ios" || platform === "android") {
            setUrl('http://distribution.bbb3d.renderfarming.net/video/mp4/bbb_sunflower_1080p_60fps_normal.mp4')
        } else {
            setUrl('http://distribution.bbb3d.renderfarming.net/video/mp4/bbb_sunflower_1080p_60fps_normal.mp4')
        }
    }, [platform, url])


    useEffect((res) => {

        if (url && !exit.current) {
            const playerWeb = async () => {
                await initPlayer("embedded", url,
                    "fullscreen-video", 'div', 1280, 720);

                if (res.result.result && res.result.value) {
                }
                res = await play("fullscreen-video");
            }

            const playerNative = async () => {
                try {
                    await initPlayer("fullscreen", url,
                        "fullscreen-video");

                } catch (error) {
                    console.log(error);
                }
            }
            if (platform === "ios" || platform === "android")
                playerNative();
            else
                playerWeb();

        }

    }, [initPlayer, play, isPlaying, pause, getDuration,
        getVolume, setVolume, getCurrentTime, setCurrentTime,
        getMuted, setMuted, stopAllPlayers,
        platform, url, exit]);

    return (
        <div className="main-container">
            {(!exit.current) &&
                <div id="fullscreen-video" slot="fixed">
                    
                </div>
            }
        </div>
    )
}

export default VideoPlayer */



import React, { Component } from 'react';
import VideoPlayer from 'react-video-js-player';
import { Link, useNavigate } from 'react-router-dom';
import Carousel from 'react-grid-carousel';
import modrenHistory from '../../Video/modrenHistory.mp4'


class VideoPlayerr extends Component {
    player = {}
    state = {
        video: {
            src: modrenHistory,
            poster: modrenHistory
        }
    }

    onPlayerReady(player) {
        console.log("Player is ready: ", player);
        this.player = player;
    }

    onVideoPlay(duration) {
        console.log("Video played at: ", duration);
    }

    onVideoPause(duration) {
        console.log("Video paused at: ", duration);
    }

    onVideoTimeUpdate(duration) {
        console.log("Time updated: ", duration);
    }

    onVideoSeeking(duration) {
        console.log("Video seeking: ", duration);
    }

    onVideoSeeked(from, to) {
        console.log(`Video seeked from ${from} to ${to}`);
    }

    onVideoEnd() {
        console.log("Video ended");
    }

    render() {
        return (
            <div>
                <header className="header active">
                    <div style={{ marginTop: '10px' }} className="container">
                        <div style={{ display: 'flex' }} className="header-main">
                            <div className="logo2">
                                <Link to="/live-calsses"><i style={{ fontSize: '20px' }} className="bi bi-arrow-left"></i></Link>
                            </div>
                            <div style={{ flex: '1' }}></div>
                            <Link to="/live-calsses"><i style={{ fontSize: '20px', color: '#000000' }} className="bi bi-share"></i></Link>
                        </div>
                    </div>
                </header>
                <br />
                <br />
                <br />
                <VideoPlayer
                    controls={true}
                    src={this.state.video.src}
                    poster={this.state.video.poster}
                    width="360px"
                    height="300px"
                    onReady={this.onPlayerReady.bind(this)}
                    onPlay={this.onVideoPlay.bind(this)}
                    onPause={this.onVideoPause.bind(this)}
                    onTimeUpdate={this.onVideoTimeUpdate.bind(this)}
                    onSeeking={this.onVideoSeeking.bind(this)}
                    onSeeked={this.onVideoSeeked.bind(this)}
                    onEnd={this.onVideoEnd.bind(this)}
                />
                <br />
                <br />
                <br />
                <div style={{ backgroundColor: '#FFFFFF' }}>
                    {/* <a href={HistoryofIndia}>HistoryofIndia</a> */}
                    <section id="about" className="about">
                        <div className="container" data-aos="fade-up">
                            <div style={{ marginTop: '10px' }}>
                                <h5 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Courses on all subjects</h5>
                            </div>
                            <div className="row">
                                <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                                    <div style={{ display: 'flex' }}>
                                        <div>
                                            <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Upcoming</h6>
                                        </div>
                                        <div style={{ flex: '1' }}></div>
                                        <div>
                                            <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                                            <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <Carousel cols={2} rows={1} gap={1} loop>
                        <Carousel.Item>
                            <div className="container py-4">
                                <div className="Upcoming">
                                    <div>
                                        <div>
                                            <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                                <div style={{ display: 'flex', }}>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>STARTS 8 DEC, 2:00 PM</p>
                                                    </div>
                                                    <div style={{ flex: '1' }}></div>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                                <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                                <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                                <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
                            </div>
                        </Carousel.Item>
                        <Carousel.Item>
                            <div className="container py-4">
                                <div className="Upcoming">
                                    <div>
                                        <div>
                                            <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                                <div style={{ display: 'flex', }}>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>STARTS 8 DEC, 2:00 PM</p>
                                                    </div>
                                                    <div style={{ flex: '1' }}></div>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                                <p style={{ color: 'blue', fontWeight: '600', fontFamily: 'Nunito', fontSize: '15px', }}>HISTORY</p>
                                <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Course on Ancient History for SCE Prelims & Mains</h4>
                                <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', color: 'gray', lineHeight: '1rem' }}>Tarun Goyal</h6>
                            </div>
                        </Carousel.Item>
                    </Carousel>

                    <section style={{ marginTop: '30px' }} id="about" className="about">
                        <div className="container" data-aos="fade-up">
                            <div className="row">
                                <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                                    <div style={{ display: 'flex' }}>
                                        <div>
                                            <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Recently started</h6>
                                        </div>
                                        <div style={{ flex: '1' }}></div>
                                        <div>
                                            <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                                            <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <Carousel cols={2} rows={1} gap={1} loop>
                        <Carousel.Item>
                            <div className="container py-1">
                                <div className="Upcoming">
                                    <div>
                                        <div>
                                            <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                                <div style={{ display: 'flex', }}>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>5 DEC, 5:30 PM</p>
                                                    </div>
                                                    <div style={{ flex: '1' }}></div>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                                <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                                <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                                <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                            </div>
                        </Carousel.Item>
                        <Carousel.Item>
                            <div className="container py-1">
                                <div className="Upcoming">
                                    <div>
                                        <div>
                                            <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                                <div style={{ display: 'flex', }}>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>5 DEC, 5:30 PM</p>
                                                    </div>
                                                    <div style={{ flex: '1' }}></div>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style={{ margin: '10px 10px', lineHeight: '2px' }}>
                                <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                                <h4 style={{ fontWeight: '900', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                                <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                            </div>
                        </Carousel.Item>
                    </Carousel>


                    <section style={{ marginTop: '30px' }} id="about" className="about">
                        <div className="container" data-aos="fade-up">
                            <div className="row">
                                <div className="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                                    <div style={{ display: 'flex' }}>
                                        <div>
                                            <h6 style={{ color: 'black', fontWeight: 'bold', fontFamily: 'Nunito' }}>Completed</h6>
                                        </div>
                                        <div style={{ flex: '1' }}></div>
                                        <div>
                                            <Link style={{ color: 'blue', fontWeight: 'bold', fontFamily: 'Nunito', fontSize: '14px' }} to="">SEE ALL</Link>
                                            <i style={{ marginLeft: '10px', fontSize: '14px' }} className="bi bi-chevron-compact-right"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <Carousel cols={2} rows={1} gap={1} loop>
                        <Carousel.Item>
                            <div className="container py-4">
                                <div className="Upcoming">
                                    <div>
                                        <div>
                                            <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                                <div style={{ display: 'flex', }}>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>Completed 8 DEC, 2:00 PM</p>
                                                    </div>
                                                    <div style={{ flex: '1' }}></div>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                                <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                                <h4 style={{ fontWeight: '500', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                                <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                            </div>
                        </Carousel.Item>
                        <Carousel.Item>
                            <div className="container py-4">
                                <div className="Upcoming">
                                    <div>
                                        <div>
                                            <div style={{ marginTop: '5px' }} className="h-100 p-1">
                                                <div style={{ display: 'flex', }}>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9' }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>Completed 8 DEC, 2:00 PM</p>
                                                    </div>
                                                    <div style={{ flex: '1' }}></div>
                                                    <div style={{ backgroundColor: '#FFFFFF90', borderRadius: '5px', zIndex: '9', }}>
                                                        <p style={{ margin: '4px', fontWeight: '700', color: '#000000', fontSize: '10px', fontFamily: 'Nunito' }}>EN</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style={{ margin: '0 10px', lineHeight: '2px' }}>
                                <p style={{ color: '#14D171', fontWeight: '600', fontFamily: 'Nunito' }}>CURRENT AFFAIRS</p>
                                <h4 style={{ fontWeight: '500', fontFamily: 'Nunito', fontSize: '18px' }}>Comprehensive Course on Current Affairs for December 2021</h4>
                                <h6 style={{ fontWeight: '500', color: 'grey', display: 'flex', fontFamily: 'Nunito' }}>Ajay Kumar Muchakurthi 17 session</h6>
                            </div>
                        </Carousel.Item>
                    </Carousel>
                    <br />
                </div>
            </div>
        );
    }
}
export default VideoPlayerr;

