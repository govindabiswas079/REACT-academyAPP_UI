import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserInfo } from './index';
import CircularProgress from '@mui/material/CircularProgress';

const LandPage = () => {
   let navigate = useNavigate();

   const [open, setOpen] = React.useState(false);

   const handleClickOpen = () => {
      setOpen(true);
   };

   const handleClose = () => {
      setOpen(false);
   };

   const subscription = () => {
      navigate('/subscription')
   }

   return (
      <div>
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <div className="landImg">
               <div >
                  <div>
                     <div>
                        <div style={{ marginTop: '0px' }} className="h-100 p-1">
                           <div style={{ display: 'flex', }}>
                              <div style={{ zIndex: '9', margin: '25px' }}>
                                 <Link to="/sign-in"><i style={{ fontWeight: '900', color: '#000000' }} className="bi bi-x-lg"></i></Link>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <div style={{ justifyItems: 'center', marginTop: '0px', paddingTop: '25px' }} className="d-grid gap-2 mx-auto">
               {/* <div style={{ marginTop: '20px' }}> */}
               <h1 style={{ color: 'black', fontWeight: '900', fontFamily: 'Nunito', lineHeight: '12px' }}>Ace your preparation</h1>
               <h1 style={{ color: 'black', fontWeight: '900', fontFamily: 'Nunito', lineHeight: '12px' }}>with the UPSC CSE - GS</h1>
               <h1 style={{ color: 'black', fontWeight: '900', fontFamily: 'Nunito', lineHeight: '12px' }}>subscription</h1>
               {/* </div> */}
               <div style={{ marginTop: '15px' }}>
                  <h6 style={{ fontWeight: '500', fontFamily: 'Nunito', lineHeight: '12px', color: 'gray' }}>Trusted by over 6,00,00 learners</h6>
               </div>

               <ul>
                  <li style={{ fontFamily: 'Nunito', fontWeight: '500', fontSize: '15px', lineHeight: '40px' }}><i style={{ color: 'blue', marginRight: '10px' }} className="bi bi-mortarboard-fill"></i> Exceptional educators to learn from</li>
                  <li style={{ fontFamily: 'Nunito', fontWeight: '500', fontSize: '15px', lineHeight: '40px' }}><i style={{ color: 'yellow', marginRight: '10px' }} className="bi bi-calendar-check-fill"></i> Fully organized study planner</li>
                  <li style={{ fontFamily: 'Nunito', fontWeight: '500', fontSize: '15px', lineHeight: '40px' }}><i style={{ color: 'yellowgreen', marginRight: '10px' }} className="bi bi-newspaper"></i> Mock test, live quizzes & practice</li>
               </ul>

            </div>
            <div style={{ margin: '15px' }} className="d-grid gap-2">
               <button style={{ color: '#FFFFFF', fontWeight: '900', backgroundColor: '#08bd80', fontSize: '13px' }} className="btn btn-lg" type="button" /* onClick={(e) => subscription(e)} */>Get Subscription</button>
               <div style={{ justifyItems: 'center', }} className="d-grid gap-2 mx-auto">
                  <div style={{ display: 'flex' }}>
                     <Link style={{ color: 'black', fontFamily: 'Nunito', fontWeight: '700', fontSize: '12px' }} to="">Start ₹2,500/mo</Link>
                  </div>
               </div>
            </div>
            <div >
               <UserInfo handleClickOpen={handleClickOpen} handleClose={handleClose} open={open} />
            </div>
            <br />
         </div>
         {/* <UserInfo /> */}
         <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <br />
                        <img style={{ width: '15%' }} src="https://static.uacdn.net/production/_next/static/images/goal/iconic_1.png?q=75&w=256" alt="" />
                        <div>
                           <h2 style={{ fontWeight: '700', color: '#000000', fontFamily: 'Nunito', fontSize: '15px' }}>Offers only for you</h2>
                           <h3 style={{ color: 'gray', fontFamily: 'Nunito', fontSize: '10px' }}>Get upto 3 months free with<br /> your subscription</h3>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <i style={{ fontSize: '15px' }} className="bi bi-chevron-right"></i>
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <br />
         <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <br />
                        <div>
                           <h2 style={{ fontWeight: '700', color: '#000000', fontFamily: 'Nunito', fontSize: '25px', textAlign: 'center' }}>What you get with the subscription</h2>
                        </div>
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <br />
         <div className="container">
            <div className="row align-items-md-stretch">
               <div className="col-md-6">
                  <div style={{ backgroundColor: 'rgb(210 212 234 / 20%)', }} className="h-100  border rounded-3">
                     <section id="about" className="about">
                        <div className="" data-aos="fade-up">
                           <div className="row p-3">
                              <h5 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Exceptional educators</h5>
                              <div className="col-lg-6 pt-lg-0 order-2 order-lg-1 content">
                                 <ul style={{ textAlign: 'initial' }}>
                                    <li style={{ fontFamily: 'Nunito', fontSize: '14px' }}><i style={{ color: 'black', fontSize: '14px' }} className="bi bi-check-circle"></i>Provin history of aoaching all india rankers</li>
                                    <li style={{ fontFamily: 'Nunito', fontSize: '14px' }}><i style={{ color: 'black', fontSize: '14px' }} className="bi bi-check-circle"></i>Decades of teaching experience</li>
                                    <li style={{ fontFamily: 'Nunito', fontSize: '14px' }}><i style={{ color: 'black', fontSize: '14px' }} className="bi bi-check-circle"></i>Subject matter experts on each topic</li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </section>
                     <img style={{ width: '100%' }} src="https://uk.rs-cdn.com/site_files/cache/9559/images/feature/9a967024cac20554d42f8e611313a3b7_4bd07e3c55a996b45bacfc40df329e9e.jpg" alt="" />
                     <br />
                  </div>
               </div>
            </div>
         </div>
         <br />
         <div className="container">
            <div className="row align-items-md-stretch">
               <div className="col-md-6">
                  <div style={{ backgroundColor: 'rgb(210 212 234 / 29%)', }} className="h-100  border rounded-3">
                     <section id="about" className="about">
                        <div className="" data-aos="fade-up">
                           <div className="row p-3">
                              <h5 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>Self-study at your<br /> own pace</h5>
                              <div className="col-lg-6 order-2 order-lg-1 content">
                                 <div style={{ display: 'flex' }}>
                                    <div>
                                       <img style={{ width: '50px' }} src="https://static.uacdn.net/web-cms/syllabus_710041a346.svg" alt="" />
                                       <div style={{ width: '3px', height: '100px', backgroundColor: 'gray', marginLeft: '25px', borderRadius: '10px' }}></div>
                                    </div>
                                    <div style={{ flexDirection: 'column', marginLeft: '15px' }}>
                                       <h6 style={{ fontWeight: '700', marginTop: '20px' }}>In-depth notes</h6>
                                       <p style={{ color: 'gray' }}>High quality PDF notes on demand to revise anytime anywhere</p>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-lg-6 order-2 order-lg-1 content">
                                 <div style={{ display: 'flex' }}>
                                    <div>
                                       <img style={{ width: '50px' }} src="https://static.uacdn.net/web-cms/plan_1e391d0188.svg" alt="" />
                                       <div style={{ width: '3px', height: '100px', backgroundColor: 'gray', marginLeft: '25px', borderRadius: '10px' }}></div>
                                    </div>
                                    <div style={{ flexDirection: 'column', marginLeft: '15px' }}>
                                       <h6 style={{ fontWeight: '700', marginTop: '20px' }}>Live mock tests & quizzes</h6>
                                       <p style={{ color: 'gray' }}>Measure your progress and stay on track eith detailed performance analysis & competitive stats</p>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-lg-6 order-2 order-lg-1 content">
                                 <div style={{ display: 'flex' }}>
                                    <div>
                                       <img style={{ width: '50px' }} src="https://icons.iconarchive.com/icons/johanchalibert/mac-osx-yosemite/1024/messages-icon.png" alt="" />
                                       <div style={{ width: '3px', height: '140px', backgroundColor: 'gray', marginLeft: '25px', borderRadius: '10px' }}></div>
                                    </div>
                                    <div style={{ flexDirection: 'column', marginLeft: '15px' }}>
                                       <h6 style={{ fontWeight: '700', marginTop: '20px' }}>Instant doubt solutions</h6>
                                       <p style={{ color: 'gray' }}>Get video solution by top educators for all your doubts instantly</p>
                                       <p style={{ color: 'gray' }}>Also, access textbook exercises & previous year questions</p>
                                    </div>
                                 </div>
                              </div>
                              {/*  */}
                              <div className="col-lg-6 order-2 order-lg-1 content">
                                 <div style={{ display: 'flex' }}>
                                    <div>
                                       <img style={{ width: '50px' }} src="https://icon-library.com/images/explore-icon/explore-icon-11.jpg" alt="" />
                                       {/* <div style={{ width: '3px', height: '100px', backgroundColor: 'gray', marginLeft: '25px', borderRadius: '10px' }}></div> */}
                                    </div>
                                    <div style={{ flexDirection: 'column', marginLeft: '15px' }}>
                                       {/* <h6 style={{ fontWeight: '700', marginTop: '20px' }}>Instant doubt solutions</h6>
                                       <p style={{ color: 'gray' }}>Get video solution by top educators for all your doubts instantly</p>
                                       <p style={{ color: 'gray' }}>Also, access textbook exercises & previous year questions</p> */}
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                     <br />
                  </div>
               </div>
            </div>
         </div>
         <br />
         <div className="container">
            <div className="row align-items-md-stretch">
               <div className="col-md-6">
                  <div style={{ backgroundColor: 'rgb(210 212 234 / 29%)', }} className="h-100  border rounded-3">
                     <section id="about" className="about">
                        <div className="" data-aos="fade-up">
                           <div style={{ backgroundColor: 'blue', width: '30%', borderRadius: '5px', marginTop: '10px', marginLeft: '10px' }}>
                              <h6 style={{ fontFamily: 'Nunito', fontWeight: '700', backgroundColor: 'blue', color: '#FFFFFF', fontSize: '12px', textAlign: 'center', margin: '3px' }}>INTRODUCING</h6>
                           </div>
                           <div className="row p-3">
                              <h5 style={{ fontFamily: 'Nunito', fontWeight: '700' }}>The Ultimate Planner</h5>
                              <div className="col-lg-6 pt-lg-0 order-2 order-lg-1 content">
                                 <p style={{ fontWeight: '500', color: 'gray' }}>Follow all your classes, practice & mock tests on a single unified planner</p>
                              </div>
                           </div>
                        </div>
                     </section>
                     <img style={{ width: '100%' }} src="https://static.uacdn.net/production/_next/static/images/newApp.png?q=75&w=1080" alt="" />
                     <br />
                     <div style={{ marginLeft: '10px' }} className="col-lg-6 pt-lg-0 order-2 py-4 order-lg-1 content">
                        <ul style={{ textAlign: 'initial' }}>
                           <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: '#000000', fontWeight: '600', lineHeight: '32px' }}><i style={{ color: 'black', fontSize: '14px', marginRight: '10px', marginLeft: '10px' }} className="bi bi-check-circle"></i>A shedule that work gor you</li>
                           <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: '#000000', fontWeight: '600', lineHeight: '32px' }}><i style={{ color: 'black', fontSize: '14px', marginRight: '10px', marginLeft: '10px' }} className="bi bi-check-circle"></i>Regular practice after every class</li>
                           <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: '#000000', fontWeight: '600', lineHeight: '32px' }}><i style={{ color: 'black', fontSize: '14px', marginRight: '10px', marginLeft: '10px' }} className="bi bi-check-circle"></i>Revise past classes & tests quockly</li>
                           <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: '#000000', fontWeight: '600', lineHeight: '32px' }}><i style={{ color: 'black', fontSize: '14px', marginRight: '10px', marginLeft: '10px' }} className="bi bi-check-circle"></i>Get closer to syllabus completion</li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <br />
         <div style={{ backgroundColor: '#FFFFFF' }}>
            <div style={{ margin: '15px' }}>
               <h5 style={{ fontWeight: '900', fontSize: '22px', margin: '20px 0px' }}>Subscriptions for you</h5>
            </div>
            <div className="container">
               <div className="row align-items-md-stretch">
                  <div className="col-md-6">
                     <div style={{ backgroundColor: 'rgb(210 212 234 / 29%)', }} className="h-100  border rounded-3">
                        <div className="PlusSub">
                           <section id="about" className="about">
                              <div className="" data-aos="fade-up">
                                 <div className="row p-3">
                                    <h5 style={{ fontFamily: 'Nunito', fontWeight: '700', color: '#08bd80' }}>Plus</h5>
                                    <h6 style={{ fontFamily: 'Nunito', fontWeight: '700', color: '#08bd80' }}>Learn from top educators</h6>
                                    <div style={{ marginTop: '20px' }} className="col-lg-6 pt-lg-0 order-2 order-lg-1 content">
                                       <ul style={{ textAlign: 'initial' }}>
                                          <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: 'gray' }}><i style={{ color: '#08bd80', fontSize: '18px', fontWeight: '900' }} className="bi bi-check-lg"></i>Daily live classes</li>
                                          <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: 'gray' }}><i style={{ color: '#08bd80', fontSize: '18px', fontWeight: '900' }} className="bi bi-check-lg"></i>Live tests & quizzes</li>
                                          <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: 'gray' }}><i style={{ color: '#08bd80', fontSize: '18px', fontWeight: '900' }} className="bi bi-check-lg"></i>Structured courses</li>
                                          <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: 'gray' }}><i style={{ color: '#08bd80', fontSize: '18px', fontWeight: '900' }} className="bi bi-check-lg"></i>Ultimated access</li>
                                       </ul>
                                    </div>
                                 </div>
                                 <div style={{ margin: "15px", display: 'flex' }} >
                                    <h6 style={{ fontFamily: 'Nunito', fontWeight: '700', color: '#000000' }}>Strts ₹2,500/mo</h6>
                                    <div style={{ flex: '1' }}></div>
                                    {/* <img style={{ width: '15%' }} src="https://static.uacdn.net/production/_next/static/images/goal/plus_1.png" alt="" /> */}
                                    {/* <div className="PlusSub"></div> */}
                                 </div>
                              </div>
                           </section>
                        </div>

                     </div>
                  </div>
               </div>
            </div>
            <br />
            <div className="container">
               <div className="row align-items-md-stretch">
                  <div className="col-md-6">
                     <div style={{ backgroundColor: 'rgb(210 212 234 / 29%)', }} className="h-100  border rounded-3">
                        <div className="IonicSub">
                           <section id="about" className="about">
                              <div className="" data-aos="fade-up">
                                 <div className="row p-3">
                                    <h5 style={{ fontFamily: 'Nunito', fontWeight: '700', color: 'rgb(189 133 8)' }}>Iconic</h5>
                                    <h6 style={{ fontFamily: 'Nunito', fontWeight: '700', color: 'rgb(189 133 8)' }}>Learn with live mentorship</h6>
                                    <div style={{ marginTop: '20px' }} className="col-lg-6 pt-lg-0 order-2 order-lg-1 content">
                                       <ul style={{ textAlign: 'initial' }}>
                                          <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: 'gray' }}><i style={{ color: 'rgb(189 133 8)', fontSize: '18px', fontWeight: '900' }} className="bi bi-check-lg"></i>All plus benefits</li>
                                          <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: 'gray' }}><i style={{ color: 'rgb(189 133 8)', fontSize: '18px', fontWeight: '900' }} className="bi bi-check-lg"></i>Personal coach</li>
                                          <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: 'gray' }}><i style={{ color: 'rgb(189 133 8)', fontSize: '18px', fontWeight: '900' }} className="bi bi-check-lg"></i>Mains Q&A practice</li>
                                          <li style={{ fontFamily: 'Nunito', fontSize: '14px', color: 'gray' }}><i style={{ color: 'rgb(189 133 8)', fontSize: '18px', fontWeight: '900' }} className="bi bi-check-lg"></i>Study Planner</li>
                                       </ul>
                                       {/* <div className="PlusSub"></div> */}
                                    </div>
                                 </div>
                                 <div style={{ margin: "15px", display: 'flex' }} >
                                    <h6 style={{ fontFamily: 'Nunito', fontWeight: '700', color: '#000000' }}>Strts ₹4,270/mo</h6>
                                    <div style={{ flex: '1' }}></div>
                                    {/* <img style={{ width: '15%' }} src="https://static.uacdn.net/production/_next/static/images/goal/iconic_1.png" alt="" /> */}
                                    {/* <div className="PlusSub"></div> */}
                                 </div>
                              </div>
                           </section>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <br />
         <div style={{ margin: '0 10px' }} className="d-grid gap-2 d-md-block">
            <button style={{ fontWeight: '700', backgroundColor: '#08bd80', fontFamily: 'Nunito', color: '#FFFFFF', fontSize: '13px' }} className="btn btn-lg" type="button" /* onClick={(e) => subscription(e)} */>Get subscription</button>
         </div>
         <br />
         <section style={{ backgroundColor: '#FFFFFF', }} id="features" className="features">
            <div data-aos="fade-up">
               <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                     <div className="icon-box">
                        <br />
                        <div>
                           <h3 style={{ fontWeight: '700', color: '#000000', fontFamily: 'Nunito', fontSize: '15px', }}>Have questions?</h3>
                           <h3 style={{ fontWeight: '600', color: 'gray', fontFamily: 'Nunito', fontSize: '12px', marginTop: '10px' }}>Our experts can answer all your question over a phone call</h3>
                           <h3 style={{ fontWeight: '600', color: 'gray', marginTop: '15px', fontFamily: 'Nunito', fontSize: '12px', fontStyle: 'italic' }}>"How don the subscription work?"</h3>
                           <button type="button" style={{ marginTop: '20px', fontFamily: 'Nunito', color: '#000000', fontWeight: '700', }} className="btn btn-outline-secondary btn-sm">Get a call from us</button>
                        </div>
                        <div style={{ flex: '1' }}></div>
                        <img style={{ width: '30%' }} src="https://static.uacdn.net/production/_next/static/images/ttu_illustration.svg?q=75&w=1920" alt="" />
                        <br />
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   );
};

export default LandPage;
