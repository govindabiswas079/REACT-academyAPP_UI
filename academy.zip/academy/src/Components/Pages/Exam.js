import React from 'react'
import Navigation from '../Navogation/Navigation';

const Exam = () => {
   return (
      <div>
         <Navigation />
         Exam
      </div>
   );
};

export default Exam
