/* import React, { useState } from 'react';
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import CloseIcon from '@mui/icons-material/Close';
import Slide from '@mui/material/Slide';
import { Link, useNavigate } from 'react-router-dom';

const Transition = React.forwardRef(function Transition(props, ref) {
   return <Slide direction="up" ref={ref} {...props} />;
});

export default function UserInfo({ handleClickOpen, handleClose, open }) {
   const navigate = useNavigate();
   const [backDisable, setBackDisable] = useState(false)
   const [disable, setDisable] = useState(false);
   const [loadings, setLoadings] = useState(false)
   const [name, setName] = useState(false);
   const [email, setEmail] = useState(false);
   const [country, setCountry] = useState(false);
   const [mobile, setMobile] = useState(false);
   const [radio, setRadio] = useState(false);

   const [value, setValue] = useState({
      Name: '',
      Email: '',
      Country: '',
      Mobile: '',
      Radio: ''
   })

   const onChangeName = (e) => {
      if (e.target.value.trim().length >= 0) {
         setValue({ ...value, Name: e.target.value });
         setName(false);
      } else {
         setValue({ ...value, Name: e.target.value });
      };
   };

   const onChangeEmail = (e) => {
      if (e.target.value.trim().length >= 0) {
         setValue({ ...value, Email: e.target.value });
         setEmail(false);
         setDisable(false)
      } else {
         setValue({ ...value, Email: e.target.value });
         setDisable(false)
      };
   };

   const onChangeCountry = (e) => {
      if (e.target.value.trim().length >= 0) {
         setValue({ ...value, Country: e.target.value });
         setCountry(false);
      } else {
         setValue({ ...value, Country: e.target.value });
      };
   };

   const onChangeMobile = (e) => {
      const re = /^[0-9\b]/;
      if (e.target.value.trim().length >= 0) {
         if (e.target.value === '' || re.test(e.target.value)) {
            setValue({ ...value, Mobile: e.target.value });
         }
         setMobile(false);
      } else {
         if (e.target.value === '' || re.test(e.target.value)) {
            setValue({ ...value, Mobile: e.target.value });
         }
      };
   };

   const radioData = () => {
      setValue({ ...value, Radio: ' I have read all exam instructions.' });
      setRadio(false);
      setDisable(false)
   }

   const ccode = value.Country;
   const price = typeof ccode === "string" ? ccode.split(",")[0] : "";
   const price1 = typeof ccode === "string" ? ccode.split(",")[1] : "";
   const data = JSON.stringify({
      Name: value.Name,
      Email: value.Email,
      County: `${price}`,
      Mobile: `${price1}${value.Mobile}`,
      Radio: value.Radio,
      currentDate: new Date(),
      examMode: 'online'
   });

   const checkStringNullEmpty = (str) => {
      if (str != null && str !== '') {
         return false;
      } else {
         return true;
      };
   };

   var validation = '';
   const validatee = () => {
      if (checkStringNullEmpty(value.Name)) {
         validation += '<li>Enter Your Confrim Password</li>';
         setName(true)
      }
      if (checkStringNullEmpty(value.Email)) {
         validation += '<li>Enter Your Confrim Password</li>';
         setEmail(true)
      }
      if (checkStringNullEmpty(value.Country)) {
         validation += '<li>Enter Your Confrim Password</li>';
         setCountry(true)
      }
      if (checkStringNullEmpty(value.Mobile)) {
         validation += '<li>Enter Your Confrim Password</li>';
         setMobile(true)
      }
      if (checkStringNullEmpty(value.Radio)) {
         validation += '<li>Enter Your Confrim Password</li>';
         setRadio(true)
      }
      if (validation !== '') {
         return null;
      }
      else {

      };
   };

   const click = () => {
      validatee()
      if (validation === "") {
         setDisable(false)
      } else {
         setDisable(true)
      }
   }

   const onSubmit = (e) => {
      e.preventDefault();
      setBackDisable(true)
      validatee();
      if (validation === '') {
         setLoadings(true)
         sessionStorage.setItem("userData", data);
         navigate('/exam')
      } else {
         return null;
      }
   };

   const back = () => {
      navigate('/exam-info')
   }

   return (
      <div>
         <div style={{ margin: '25px 15px' }} className="d-grid gap-2">
            <Link onClick={handleClickOpen} style={{ color: '#000000', fontWeight: '600', fontSize: '14px' }} className="btn btn-outline-secondary btn-lg" to="">Try vedaacademy for free</Link>
         </div>
         <Dialog
            fullScreen
            open={open}
            onClose={handleClose}
            TransitionComponent={Transition}
         >
            <AppBar color="inherit" sx={{ position: 'relative' }}>
               <Toolbar>
                  <IconButton
                     edge="start"
                     color="inherit"
                     onClick={handleClose}
                     aria-label="close"
                  >
                     <CloseIcon />
                  </IconButton>
                  <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                     Veda Academy
                  </Typography>
               </Toolbar>
            </AppBar>
            <div>
               <br />
               {loadings && <div className="loader"></div>}
               <div className="card m-3">
                  <div className="card-body">
                     <form onSubmit={(e) => onSubmit(e)} autoComplete="off">
                        <div className="form-row">
                           <div style={{ margin: '0 5px' }} className="form-group col">
                              <label>First Name: </label>
                              <input type="text" name="Name" value={value.Name} onChange={(e) => onChangeName(e)} className={name ? "form-control is-invalid" : "form-control"} />
                              <div className="invalid-feedback">
                                 {name ? <div >Name is required</div> : ''}
                              </div>
                           </div>
                        </div>
                        <div className="form-row">
                           <div className="form-group col">
                              <label>Email: </label>
                              <input type="text" name="Email" value={value.Email} onChange={(e) => onChangeEmail(e)} className={email ? "form-control is-invalid" : "form-control"} />
                              <div className="invalid-feedback">
                                 {email ? <div>Email is required</div> : ''}
                              </div>
                           </div>
                        </div>
                        <br />
                        <div className="col-12">
                           <div className="form-check">
                              <input className={radio ? "form-check-input is-invalid" : "form-check-input"} value={value.Radio} onChange={(e) => radioData(e)} type="checkbox" id="gridCheck" />
                              <label className="form-check-label" htmlFor="gridCheck">
                                 I have accept all privacy..
                              </label>
                           </div>
                           <div className="invalid-feedback">
                              {radio ? <div>required</div> : ''}
                           </div>
                        </div>
                        <br />
                        <div className="text-center d-grid gap-2">
                           <button className="btn mr-1" disabled={disable} onClick={click} style={{ color: '#FFFFFF', fontWeight: '900', backgroundColor: '#302d2d', fontSize: '15px' }}>Continue</button>
                        </div>
                        </form >
                  </div >
               </div >
               <br />
            </div >
         </Dialog>
      </div>
   );
} */






import React, { useState } from 'react';
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import CloseIcon from '@mui/icons-material/Close';
import Slide from '@mui/material/Slide';
import { Link, useNavigate } from 'react-router-dom';
import CircularProgress from '@mui/material/CircularProgress';

const Transition = React.forwardRef(function Transition(props, ref) {
   return <Slide direction="up" ref={ref} {...props} />;
});

export default function UserInfo({ handleClickOpen, handleClose, open }) {
   const navigate = useNavigate();
   const [disable, setDisable] = useState(false);
   const [loadings, setLoadings] = useState(false)
   const [name, setName] = useState(false);
   const [email, setEmail] = useState(false);

   const [isValidEmail, setIsValidEmail] = useState(false);

   const [value, setValue] = useState({
      Name: '',
      Email: '',
   })

   const number = sessionStorage.getItem('Mobile')

   const onChangeName = (e) => {
      if (e.target.value.trim().length >= 0) {
         setValue({ ...value, Name: e.target.value });
         setName(false);
      } else {
         setValue({ ...value, Name: e.target.value });
      };
   };

   let handleOnChange = () => {
      let re = /^(([^<>()\]\\.,;:\s@"]+(\.[^<>()\]\\.,;:\s@"]+)*)|(".+"))@(([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      // let re = /^[ ]*([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})[ ]*$/i;

      if (re.test(value.Email)) {
         setIsValidEmail(false);
         setDisable(false)
      } else {
         setIsValidEmail(true);
         setDisable(true)
      };
   };

   const onChangeEmail = (e) => {
      if (e.target.value.trim().length >= 0) {
         setValue({ ...value, Email: e.target.value });
         setEmail(false);
         /* setDisable(false) */
         handleOnChange();
      } else {
         setValue({ ...value, Email: e.target.value });
         /* setDisable(false) */
      };
   };

   const mobileNumber = number;
   const countryCode = mobileNumber.length - 10;
   const IDDCC = mobileNumber.substr(0, countryCode);
   const NN = mobileNumber.substr(countryCode, mobileNumber.length);

   const data = JSON.stringify({
      Name: value.Name,
      Email: value.Email,
      Mobile: number,
      currentDate: new Date(),
      examMode: 'online',
      username: `Vacademy@${NN}.com`,
   });

   const checkStringNullEmpty = (str) => {
      if (str != null && str !== '') {
         return false;
      } else {
         return true;
      };
   };

   var validation = '';
   const validatee = () => {
      if (checkStringNullEmpty(value.Name)) {
         validation += '<li>Enter Your Confrim Password</li>';
         setName(true)
      }
      if (checkStringNullEmpty(value.Email)) {
         validation += '<li>Enter Your Confrim Password</li>';
         setEmail(true)
      }
      if (validation !== '') {
         return null;
      }
      else {

      };
   };

   const onSubmit = (e) => {
      e.preventDefault();
      validatee();
      if (validation === '') {
         setLoadings(true)
         sessionStorage.setItem("userData", data);
         setTimeout(() => {
            window.location.replace('/home')
         }, 500)
      } else {
         return null;
      }
   };

   return (
      <div>
         <div style={{ margin: '25px 15px' }} className="d-grid gap-2">
            <Link onClick={handleClickOpen} style={{ color: '#000000', fontWeight: '600', fontSize: '14px' }} className="btn btn-outline-secondary btn-lg" to="">Try vedaacademy for free</Link>
         </div>
         <Dialog
            fullScreen
            open={open}
            onClose={handleClose}
            TransitionComponent={Transition}
         >
            <AppBar color="inherit" sx={{ position: 'relative' }}>
               <Toolbar>
                  <IconButton
                     edge="start"
                     color="inherit"
                     onClick={handleClose}
                     aria-label="close"
                  >
                     <CloseIcon />
                  </IconButton>
                  <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                     Veda Academy
                  </Typography>
               </Toolbar>
            </AppBar>
            <div>
               <br />

               <header className="header">
                  <div style={{ marginTop: '10px' }} className="container">
                     <div style={{ display: 'flex' }} className="header-main">
                        <div className="logo">
                           <Link to="/satrt-up"><i className="bi bi-arrow-left"></i></Link>
                        </div>
                     </div>
                  </div>
                  <div style={{ margin: '20px' }}>
                     <div style={{ marginTop: '0px' }}>
                        <div>
                           <h4 style={{ width: '100%', color: '#000000', fontWeight: 'bolder', fontFamily: 'Nunito', }}>Your Name And Email</h4>
                           <h6 style={{ width: '100%', color: 'gray', fontWeight: '700', fontFamily: 'Nunito', fontSize: '13px' }}>We'll send an OTP for verification</h6>
                        </div>
                        <br />


                        <div className="">
                           <div className="row height d-flex justify-content-center align-items-center">
                              <div className="col-md-6">
                                 <form className="form" autoComplete='off'>
                                    <div className="row height d-flex justify-content-center align-items-center">
                                       <div className="col-md-6">
                                          <div className="form"><input type="text" name="Name" value={value.Name} onChange={(e) => onChangeName(e)} className={name ? "form-control is-invalid" : "form-control"} placeholder="Enter Your Name..." style={{ fontWeight: '600', fontFamily: 'Nunito' }} /></div>
                                       </div>
                                       <div className="invalid-feedback">
                                       </div>
                                       {name ? <div style={{ color: 'red', fontWeight: '600', fontFamily: 'Nunito', marginTop: '8px', fontSize: '11px' }}>Name is required</div> : ''}
                                    </div>
                                    <br />
                                    <div className="row height d-flex justify-content-center align-items-center">
                                       <div className="col-md-6">
                                          <div className="form"><input type="text" name="Email" value={value.Email} onChange={(e) => onChangeEmail(e)} className={email ? "form-control is-invalid" : "form-control"} placeholder="Enter Valid Email..." style={{ fontWeight: '600', fontFamily: 'Nunito' }} /></div>
                                       </div>
                                       <div className="invalid-feedback">
                                       </div>
                                       {email ? <div style={{ color: 'red', fontWeight: '600', fontFamily: 'Nunito', marginTop: '8px', fontSize: '11px' }}>Email is required</div> : ''}
                                       {isValidEmail ? <p style={{ color: 'red', fontWeight: '600', fontFamily: 'Nunito', marginTop: '8px', fontSize: '11px' }}>Enter Valide Email.</p> : null}
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                        <br />
                     </div>
                  </div>
               </header>
               <div style={{ bottom: '0', position: 'absolute', width: '100%' }}>
                  {loadings && <div className="loader"></div>}
                  <div style={{ margin: '20px' }} className="d-grid gap-2">
                     <div style={{ justifyItems: 'center', }} className="d-grid gap-2 mx-auto">
                        <div style={{ display: 'flex' }}>
                           {/* <Link style={{ color: 'black', fontFamily: 'Nunito', fontWeight: '700', fontSize: '12px' }} to="">LOGIN WITH EMAIL</Link>
                           <i style={{ marginLeft: '10px', marginBottom: '3px', fontSize: '12px' }} className="bi bi-arrow-right"></i> */}
                        </div>
                     </div>
                     <button disabled={disable} onClick={(e) => onSubmit(e)} style={{ color: '#FFFFFF', fontWeight: '900', backgroundColor: '#302d2d', fontSize: '15px' }} className="btn btn-lg" type="button"> Continue</button>
                  </div>
               </div>
               <br />
            </div >
         </Dialog>
      </div>
   );
}
