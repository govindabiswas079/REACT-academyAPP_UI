import React from 'react';
import './PaymentPage.css';
import { useNavigate } from 'react-router-dom';

const PaymentPage = () => {
   let navigate = useNavigate();

   const Subscription = sessionStorage.getItem('Subscription');
   let jsonObject = JSON.parse(Subscription);

   const subscription = () => {
      navigate('/subscription')
   }
   return (
      <div className="PaymentPageDiv">
         <div style={{ padding: '20px' }}>
            <div style={{ backgroundColor: 'gray', borderRadius: '5px', width: '40px', height: '40px' }}>{/* width: '40px', height: '40px'  */}
               <i onClick={(e) => subscription(e)} style={{ color: '#000000', fontWeight: '900', fontSize: '25px', marginLeft: '7px' }} className="bi bi-arrow-left"></i>
            </div>
         </div>
         <div style={{ margin: '0px 10px' }}>
            <div style={{ marginTop: '0px', }}>
               <div>
                  <h3 style={{ width: '100%', color: '#FFFFFF', fontWeight: 'bolder', fontFamily: 'Nunito', fontSize: '22px' }}>Upgrade to a combo and save more</h3>
                  <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontSize: '15px', fontFamily: 'Nunito' }}>Subscription gor 36 months</h6>
               </div>
            </div>
            <div style={{ justifyItems: 'center', width: '100%', backgroundColor: '#FFFFFF', borderRadius: '5px' }}>
               <div style={{ margin: '10px' }} className="d-grid gap-2">
                  <button style={{ margin: '10px 0px' }} className="btnPaymentPage" type="button">
                     <i style={{ color: 'yellow', marginRight: '10px', marginLeft: '5px', fontFamily: 'Nunito' }} className="bi bi-star-fill"></i>UPSC CSE - GS
                     <div style={{ flex: '1' }}></div>
                     <span style={{ color: 'gray', fontFamily: 'Nunito' }}> • {jsonObject.subscription}</span>
                  </button>
               </div>
               <div style={{ display: 'flex', margin: '0px 10px' }}>
                  <p style={{ fontFamily: 'Nunito' }}>Subcription price</p>
                  <div style={{ flex: '1' }}></div>
                  <p style={{ fontWeight: '700', fontFamily: 'Nunito' }}>{jsonObject.price}</p>
               </div>
            </div>
         </div>
         <br />
         <div style={{ margin: '0px 20px' }}>
            <div style={{ marginTop: '0px', }}>
               <div>
                  <h3 style={{ width: '100%', color: '#FFFFFF', fontWeight: 'bolder', fontFamily: 'Nunito', fontSize: '20px' }}>Learners also prepare for</h3>
                  <h6 style={{ width: '100%', color: 'gray', fontWeight: '500', fontFamily: 'Nunito', fontSize: '15px' }}>Add-one for 36 months</h6>
               </div>
            </div>
            <div style={{ justifyItems: 'center', width: '100%', backgroundColor: 'rgb(33 33 33 / 83%)', borderRadius: '5px' }}>
               <div style={{ margin: '15px' }} className="d-grid gap-2">
                  <button style={{ margin: '10px 0px' }} className="btnPaymentPage1" type="button">
                     <i style={{ color: 'yellow', marginRight: '10px', marginLeft: '5px', fontFamily: 'Nunito' }} className="bi bi-star-fill"></i>UPSC CSE - GS
                     <div style={{ flex: '1' }}></div>
                     <span style={{ color: 'gray', fontFamily: 'Nunito' }}> • {jsonObject.subscription}</span>
                  </button>
               </div>
               <div style={{ display: 'flex', margin: '0px 10px' }}>
                  <p style={{ color: 'gray', fontFamily: 'Nunito' }}>Price ₹50,000</p>
                  <div style={{ flex: '1' }}></div>
                  <p style={{ fontWeight: '700', color: '#08bd80', fontFamily: 'Nunito' }}>+ Add for ₹49,500</p>
               </div>
            </div>

         </div>
         <div className='bottom-PaymentPage'>
            <div style={{ justifyItems: 'center', width: '100%', margin: '5px 5px 5px 5px', }}>
               <div className="d-grid gap-2">
                  <button className="btnSubscription" type="button">
                     <i style={{ color: 'yellowgreen', marginRight: '10px', marginLeft: '5px' }} className="bi bi-gift"></i>Add a referral code
                     <div style={{ flex: '1' }}></div>
                     <span style={{ fontWeight: '700', color: 'gray' }}>APPLY</span>
                  </button>
               </div>
               <br />
               <div style={{ display: 'flex' }}>
                  <div>
                     <h4 style={{ color: "#FFFFFF", fontFamily: 'Nunito' }}>{jsonObject.price}</h4>
                     <p style={{ color: 'gray', fontFamily: 'Nunito' }}>Incl. of all taxes</p>
                  </div>
                  <div style={{ flex: '1' }}></div>
                  <div>
                     <button style={{ backgroundColor: '#08bd80', color: '#FFFFFF', fontWeight: '900', fontFamily: 'Nunito' }} className="btn btn-lg" type="button">Proceed to pay</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
};

export default PaymentPage
