import React from 'react';
import './Subscription.css';
import { Link, useNavigate } from 'react-router-dom'

const Subscription = () => {
  let navigate = useNavigate();
  const [nav, setNav] = React.useState(false)
  const [show, setShow] = React.useState(true);

  const changeBackground = () => {
    if (window.scrollY >= 50) {
      setNav(true);
    } else {
      setNav(false);
    }
  }
  window.addEventListener('scroll', changeBackground);

  const Ionic = () => {
    setShow(true)
  };

  const Plus = () => {
    setShow(false)
  }

  const payment = (e) => {
    // const ccode = JSON.stringify(e)
    // const price = typeof ccode === "string" ? ccode.split(",")[0] : "";
    // const price1 = typeof ccode === "string" ? ccode.split(",")[1] : "";
    // const price2 = typeof ccode === "string" ? ccode.split(",")[2] : "";
    // const price3 = typeof ccode === "string" ? ccode.split(",")[3] : "";
    // console.log(JSON.parse(ccode))
    // const obj = JSON.stringify({
    //   price: `${price},${price1},${price2}`,
    //   subscription: price3
    // });
    sessionStorage.setItem('Subscription', JSON.stringify(e));
    navigate('/payment');
  }

  return (
    <div className="MainDiv">
      <div className="bgColo">
        <header className={nav ? "headerSubscription active" : "headerSubscription"}>
          <div style={{ marginTop: '10px' }} className="container">
            <div style={{ display: 'flex' }} className="header-main">
              <div className="logo2">
                <Link to="/home"><i style={{ fontSize: '25px', }} className="bi bi-x-lg"></i></Link>
                <Link style={{ marginLeft: '20px', fontSize: '20px', }} to="">UPSC CSE - GS subscription</Link>{/*  color: '#FFFFFF'  */}
              </div>
              <div style={{ flex: '1' }}></div>
            </div>
          </div>
        </header>
        <br />
        <br />
        <br />
        <br />
        <div style={{ justifyItems: 'center' }} className="d-grid gap-2 col-6 mx-auto">
          <div style={{ display: 'flex' }}>
            <button type="button" className={show ? "btnn1 active" : "btnn1"} onClick={(e) => Ionic(e)}>ICONIC</button>
            <button type="button" className={show ? "btnn2" : "btnn2 active2"} onClick={(e) => Plus(e)}>PLUS</button>
          </div>
        </div>
        <br />
        {show ?
          <>
            <div style={{ justifyItems: 'center', marginTop: '0px', }} className="d-grid gap-2 mx-auto">
              <ul>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: '#FFFFFF' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-check-circle"></i>India's best deucators</li>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: '#FFFFFF' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-check-circle"></i>Interactive live classes</li>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: '#FFFFFF' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-check-circle"></i>Structure course & PDF</li>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: '#FFFFFF' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-check-circle"></i>Live test & quizzes</li>
              </ul>
            </div>
            <section id="features" className="features">
              <div className="container" data-aos="fade-up">
                <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                    <div className="icon-box" style={{ borderRadius: '10px', backgroundColor: '#FFFFFF', marginTop: "10px" }} onClick={() => payment({ price: '₹1,53,750', subscription: 'Iconic' })}>
                      <div>
                        <h3 style={{ fontSize: '20px' }}><Link to="">36 months</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>No cost EMI</h4>
                      </div>
                      <div style={{ flex: '1' }}></div>
                      <div>
                        <h3 style={{ fontSize: '18px', fontWeight: '700' }}><Link to="">₹4,271/mo</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>₹1,53,750</h4>
                      </div>
                      <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                    </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-2 mt-md-0">
                    <div className="icon-box" style={{ borderRadius: '10px', backgroundColor: '#FFFFFF' }} onClick={() => payment({ price: '₹1,15,750', subscription: 'Iconic' })}>
                      <div>
                        <h3 style={{ fontSize: '20px', fontWeight: '700' }}><Link to="">24 months</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>No cost EMI</h4>
                      </div>
                      <div style={{ flex: '1' }}></div>
                      <div>
                        <h3 style={{ fontSize: '18px', fontWeight: '700' }}><Link to="">₹4,823/mo</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>₹1,15,750</h4>
                      </div>
                      <i className="bi bi-chevron-right" style={{ color: '#000000' }}></i>
                    </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-2 mt-md-0">
                    <div className="icon-box" style={{ borderRadius: '10px', backgroundColor: '#FFFFFF' }} onClick={() => payment({ price: '₹74,500', subscription: 'Iconic' })}>
                      <div>
                        <h3 style={{ fontSize: '20px' }}><Link to="">12 months</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>No cost EMI</h4>
                      </div>
                      <div style={{ flex: '1' }}></div>
                      <div>
                        <h3 style={{ fontSize: '18px', fontWeight: '700' }}><Link to="">₹6,208/mo</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>₹74,500</h4>
                      </div>
                      <i className="bi bi-chevron-right" style={{ color: '#000000' }}></i>
                    </div>
                  </div>
                </div>
                <div>
                  <p style={{ textAlign: 'center', marginTop: '10px', fontWeight: '500', color: 'gray', fontSize: '17px' }}>To be paid as a one-time payment</p>
                </div>
              </div>
            </section>
          </>
          :
          <>
            <div style={{ justifyItems: 'center', marginTop: '0px', }} className="d-grid gap-2 mx-auto">
              <ul>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: '#FFFFFF' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-check-circle"></i>India's best deucators</li>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: '#FFFFFF' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-check-circle"></i>Interactive live classes</li>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: '#FFFFFF' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-check-circle"></i>Structure course & PDF</li>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: '#FFFFFF' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-check-circle"></i>Live test & quizzes</li>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: 'gray' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-x"></i>Personal coach</li>
                <li style={{ fontFamily: 'Nunito', fontWeight: '700', fontSize: '15px', lineHeight: '25px', color: 'gray' }}><i style={{ color: '#FFFFFF', marginRight: '10px' }} className="bi bi-x"></i>Mains Q&A practice</li>
              </ul>

            </div>
            <section id="features" className="features">
              <div className="container" data-aos="fade-up">

                <div className="row" data-aos="zoom-in" data-aos-delay="100">
                  <div className="col-lg-3 col-md-4">
                    <div className="icon-box" style={{ borderRadius: '10px', backgroundColor: '#FFFFFF', marginTop: "10px" }} onClick={() => payment({ price: '₹90,000', subscription: 'Plus' })}>
                      <div>
                        <h3 style={{ fontSize: '20px' }}><Link to="">36 months</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>No cost EMI</h4>
                      </div>
                      <div style={{ flex: '1' }}></div>
                      <div>
                        <h3 style={{ fontSize: '18px', fontWeight: '700' }}><Link to="">₹2,500/mo</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>₹90,000</h4>
                      </div>
                      <i className="bi bi-chevron-right" style={{ color: '#000000', }}></i>
                    </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-2 mt-md-0">
                    <div className="icon-box" style={{ borderRadius: '10px', backgroundColor: '#FFFFFF' }} onClick={() => payment({ price: '₹72,000', subscription: 'Plus' })}>
                      <div>
                        <h3 style={{ fontSize: '20px', fontWeight: '700' }}><Link to="">24 months</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>No cost EMI</h4>
                      </div>
                      <div style={{ flex: '1' }}></div>
                      <div>
                        <h3 style={{ fontSize: '18px', fontWeight: '700' }}><Link to="">₹3,000/mo</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>₹72,000</h4>
                      </div>
                      <i className="bi bi-chevron-right" style={{ color: '#000000' }}></i>
                    </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-2 mt-md-0">
                    <div className="icon-box" style={{ borderRadius: '10px', backgroundColor: '#FFFFFF' }} onClick={() => payment({ price: '₹49,500', subscription: 'Plus' })}>
                      <div>
                        <h3 style={{ fontSize: '20px' }}><Link to="">12 months</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>No cost EMI</h4>
                      </div>
                      <div style={{ flex: '1' }}></div>
                      <div>
                        <h3 style={{ fontSize: '18px', fontWeight: '700' }}><Link to="">₹4,125/mo</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>₹49,500</h4>
                      </div>
                      <i className="bi bi-chevron-right" style={{ color: '#000000' }}></i>
                    </div>
                  </div>
                  <div className="col-lg-3 col-md-4 mt-2 mt-md-0">
                    <div className="icon-box" style={{ borderRadius: '10px', backgroundColor: '#FFFFFF' }} onClick={() => payment({ price: '₹40,500', subscription: 'Plus' })}>
                      <div>
                        <h3 style={{ fontSize: '20px' }}><Link to="">6 months</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>No cost EMI</h4>
                      </div>
                      <div style={{ flex: '1' }}></div>
                      <div>
                        <h3 style={{ fontSize: '18px', fontWeight: '700' }}><Link to="">₹6,750/mo</Link></h3>
                        <h4 style={{ fontSize: '13px', fontWeight: '900', marginTop: '12px', color: 'coral' }}>₹40,500</h4>
                      </div>
                      <i className="bi bi-chevron-right" style={{ color: '#000000' }}></i>
                    </div>
                  </div>
                </div>
                <div>
                  <p style={{ textAlign: 'center', marginTop: '10px', fontWeight: '500', color: 'gray', fontSize: '17px' }}>To be paid as a one-time payment</p>
                </div>
              </div>
            </section>
          </>
        }
        <br />
        <br />
        <br />
        <div className='bottom-Subscription'>
          <div style={{ justifyItems: 'center', width: '100%', margin: '15px' }}>
            <div className="d-grid gap-2">
              <button className="btnSubscription" type="button">
                <i style={{ color: 'yellowgreen', marginRight: '10px', marginLeft: '5px' }} className="bi bi-gift"></i>Add a referral code
                <div style={{ flex: '1' }}></div>
                <span style={{ fontWeight: '700', color: 'gray' }}>APPLY</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Subscription