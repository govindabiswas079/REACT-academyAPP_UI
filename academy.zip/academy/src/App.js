import './App.css';
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import { Home, SelfStudy, Account, SatrtUp, SignIn, OtpVerify, LandPage, VideoPlayerr, Notification, Exam } from './Components/Pages/index';
import { Practice, Syllabus, Tests, LiveQuiz, HostQuiz, AllFreeClasses, Subject, CoursesBatches, LiveCalsses, GetInTouch, Notify, NotifyLiveClasses, Doubt, PrepareSyllabus, } from './Components/InnerPages/Index';
import { ExamPage, ResultPage, ExamPreview } from './Components/TestExam/components/Index';
import Subscription from './Components/subscription/Subscription';
import PaymentPage from './Components/subscription/PaymentPage';
import SubscriptionWork from './Components/subscription/SubscriptionWork';
import { Enrollments, Downloads, Faqs, MyEducators, Settings, Updates, Profile, Bio } from './Components/Account/Index';
import { NameUpdate, EmailUpdate, NumberUpdate, UserUpdate, UpdateOtpVerify } from './Components/Account/InfoUpdate/Index';
/* import { Schedule, Educators, PrepareNewSyllabus, About } from './Components/PrepareSyllabus/Index'; */
import { EducatorProfile } from './InnerComponents/Index';

function App() {
  const user = JSON.parse(sessionStorage.getItem('userData'));

  return (
    <>
      <div>
        <BrowserRouter>
          {/* <Navigation /> */}
          <Routes>
            <Route exact path="/subscription" element={<Subscription />} />
            <Route exact path="/payment" element={<PaymentPage />} />
            <Route exact path="/subscription-work" element={<SubscriptionWork />} />

            <Route exact path="/home" element={<Home />} />
            <Route exact path="/self-study" element={<SelfStudy />} />
            <Route exact path="/account" element={<Account />} />
            <Route exact path="/satrt-up" element={<SatrtUp />} />
            <Route exact path="/sign-in" element={<SignIn />} />
            <Route exact path="/otp-verify" element={<OtpVerify />} />
            <Route exact path="/land-page" element={<LandPage />} />
            <Route exact path="/notification" element={<Notification />} />
            <Route exact path="/exam" element={<Exam />} />

            <Route exact path="/practice" element={<Practice />} />
            <Route exact path="/syllabus" element={<Syllabus />} />
            <Route exact path="/tests" element={<Tests />} />
            <Route exact path="/live-quiz" element={<LiveQuiz />} />
            <Route exact path="/host-quiz" element={<HostQuiz />} />
            <Route exact path="/all-free-classes" element={<AllFreeClasses />} />
            <Route exact path="/subject" element={<Subject />} />
            <Route exact path="/courses-batches" element={<CoursesBatches />} />
            <Route exact path="/live-calsses" element={<LiveCalsses />} />
            <Route exact path="/get-in-touch" element={<GetInTouch />} />
            <Route exact path="/notify" element={<Notify />} />
            <Route exact path="/notify-live-classes" element={<NotifyLiveClasses />} />
            <Route exact path="/doubt" element={<Doubt />} />
            <Route exact path="/prepare-syllabus" element={<PrepareSyllabus />} />

            <Route exact path="/exam-page" element={<ExamPage />} />
            <Route exact path="/exam-preview" element={<ExamPreview />} />
            <Route exact path="/result" element={<ResultPage />} />

            <Route exact path="/enrollments" element={<Enrollments />} />
            <Route exact path="/downloads" element={<Downloads />} />
            <Route exact path="/faqs" element={<Faqs />} />
            <Route exact path="/my-educators" element={<MyEducators />} />
            <Route exact path="/settings" element={<Settings />} />
            <Route exact path="/updates" element={<Updates />} />
            <Route exact path="/profile" element={<Profile />} />
            <Route exact path="/bio" element={<Bio />} />

            <Route exact path="/VideoPlayer" element={<VideoPlayerr />} />

            <Route exact path="/name-update" element={<NameUpdate />} />
            <Route exact path="/email-update" element={<EmailUpdate />} />
            <Route exact path="/number-update" element={<NumberUpdate />} />
            <Route exact path="/user-update" element={<UserUpdate />} />
            <Route exact path="/update-otp-verify" element={<UpdateOtpVerify />} />

            <Route exact path="/educator-profile" element={<EducatorProfile />} />         

            {/* <Route exact path='/' element={<Navigate to="/satrt-up" />} /> */}
            <Route exact path='/' element={user ? <Navigate to="/home" /> : <Navigate to="/satrt-up" />} />
          </Routes>
        </BrowserRouter>
      </div>
    </>
  );
}

export default App;
